/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "../../node_modules/base64-js/index.js":
/*!*********************************************!*\
  !*** ../../node_modules/base64-js/index.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function getLens (b64) {
  var len = b64.length

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=')
  if (validLen === -1) validLen = len

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4)

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp
  var lens = getLens(b64)
  var validLen = lens[0]
  var placeHoldersLen = lens[1]

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))

  var curByte = 0

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen

  var i
  for (i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)]
    arr[curByte++] = (tmp >> 16) & 0xFF
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[curByte++] = tmp & 0xFF
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[curByte++] = (tmp >> 8) & 0xFF
    arr[curByte++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF)
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    )
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1]
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    )
  }

  return parts.join('')
}


/***/ }),

/***/ "../../node_modules/buffer/index.js":
/*!******************************************!*\
  !*** ../../node_modules/buffer/index.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */



const base64 = __webpack_require__(/*! base64-js */ "../../node_modules/base64-js/index.js")
const ieee754 = __webpack_require__(/*! ieee754 */ "../../node_modules/ieee754/index.js")
const customInspectSymbol =
  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function') // eslint-disable-line dot-notation
    ? Symbol['for']('nodejs.util.inspect.custom') // eslint-disable-line dot-notation
    : null

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50

const K_MAX_LENGTH = 0x7fffffff
exports.kMaxLength = K_MAX_LENGTH

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */
Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()

if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
    typeof console.error === 'function') {
  console.error(
    'This browser lacks typed array (Uint8Array) support which is required by ' +
    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
  )
}

function typedArraySupport () {
  // Can typed array instances can be augmented?
  try {
    const arr = new Uint8Array(1)
    const proto = { foo: function () { return 42 } }
    Object.setPrototypeOf(proto, Uint8Array.prototype)
    Object.setPrototypeOf(arr, proto)
    return arr.foo() === 42
  } catch (e) {
    return false
  }
}

Object.defineProperty(Buffer.prototype, 'parent', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.buffer
  }
})

Object.defineProperty(Buffer.prototype, 'offset', {
  enumerable: true,
  get: function () {
    if (!Buffer.isBuffer(this)) return undefined
    return this.byteOffset
  }
})

function createBuffer (length) {
  if (length > K_MAX_LENGTH) {
    throw new RangeError('The value "' + length + '" is invalid for option "size"')
  }
  // Return an augmented `Uint8Array` instance
  const buf = new Uint8Array(length)
  Object.setPrototypeOf(buf, Buffer.prototype)
  return buf
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new TypeError(
        'The "string" argument must be of type string. Received type number'
      )
    }
    return allocUnsafe(arg)
  }
  return from(arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

function from (value, encodingOrOffset, length) {
  if (typeof value === 'string') {
    return fromString(value, encodingOrOffset)
  }

  if (ArrayBuffer.isView(value)) {
    return fromArrayView(value)
  }

  if (value == null) {
    throw new TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }

  if (isInstance(value, ArrayBuffer) ||
      (value && isInstance(value.buffer, ArrayBuffer))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof SharedArrayBuffer !== 'undefined' &&
      (isInstance(value, SharedArrayBuffer) ||
      (value && isInstance(value.buffer, SharedArrayBuffer)))) {
    return fromArrayBuffer(value, encodingOrOffset, length)
  }

  if (typeof value === 'number') {
    throw new TypeError(
      'The "value" argument must not be of type number. Received type number'
    )
  }

  const valueOf = value.valueOf && value.valueOf()
  if (valueOf != null && valueOf !== value) {
    return Buffer.from(valueOf, encodingOrOffset, length)
  }

  const b = fromObject(value)
  if (b) return b

  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
      typeof value[Symbol.toPrimitive] === 'function') {
    return Buffer.from(value[Symbol.toPrimitive]('string'), encodingOrOffset, length)
  }

  throw new TypeError(
    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
    'or Array-like Object. Received type ' + (typeof value)
  )
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(value, encodingOrOffset, length)
}

// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype)
Object.setPrototypeOf(Buffer, Uint8Array)

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be of type number')
  } else if (size < 0) {
    throw new RangeError('The value "' + size + '" is invalid for option "size"')
  }
}

function alloc (size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpreted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(size).fill(fill, encoding)
      : createBuffer(size).fill(fill)
  }
  return createBuffer(size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(size, fill, encoding)
}

function allocUnsafe (size) {
  assertSize(size)
  return createBuffer(size < 0 ? 0 : checked(size) | 0)
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(size)
}

function fromString (string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('Unknown encoding: ' + encoding)
  }

  const length = byteLength(string, encoding) | 0
  let buf = createBuffer(length)

  const actual = buf.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual)
  }

  return buf
}

function fromArrayLike (array) {
  const length = array.length < 0 ? 0 : checked(array.length) | 0
  const buf = createBuffer(length)
  for (let i = 0; i < length; i += 1) {
    buf[i] = array[i] & 255
  }
  return buf
}

function fromArrayView (arrayView) {
  if (isInstance(arrayView, Uint8Array)) {
    const copy = new Uint8Array(arrayView)
    return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength)
  }
  return fromArrayLike(arrayView)
}

function fromArrayBuffer (array, byteOffset, length) {
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('"offset" is outside of buffer bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('"length" is outside of buffer bounds')
  }

  let buf
  if (byteOffset === undefined && length === undefined) {
    buf = new Uint8Array(array)
  } else if (length === undefined) {
    buf = new Uint8Array(array, byteOffset)
  } else {
    buf = new Uint8Array(array, byteOffset, length)
  }

  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(buf, Buffer.prototype)

  return buf
}

function fromObject (obj) {
  if (Buffer.isBuffer(obj)) {
    const len = checked(obj.length) | 0
    const buf = createBuffer(len)

    if (buf.length === 0) {
      return buf
    }

    obj.copy(buf, 0, 0, len)
    return buf
  }

  if (obj.length !== undefined) {
    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
      return createBuffer(0)
    }
    return fromArrayLike(obj)
  }

  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
    return fromArrayLike(obj.data)
  }
}

function checked (length) {
  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= K_MAX_LENGTH) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return b != null && b._isBuffer === true &&
    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
}

Buffer.compare = function compare (a, b) {
  if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
  if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError(
      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
    )
  }

  if (a === b) return 0

  let x = a.length
  let y = b.length

  for (let i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!Array.isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  let i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  const buffer = Buffer.allocUnsafe(length)
  let pos = 0
  for (i = 0; i < list.length; ++i) {
    let buf = list[i]
    if (isInstance(buf, Uint8Array)) {
      if (pos + buf.length > buffer.length) {
        if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf)
        buf.copy(buffer, pos)
      } else {
        Uint8Array.prototype.set.call(
          buffer,
          buf,
          pos
        )
      }
    } else if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    } else {
      buf.copy(buffer, pos)
    }
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    throw new TypeError(
      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
      'Received type ' + typeof string
    )
  }

  const len = string.length
  const mustMatch = (arguments.length > 2 && arguments[2] === true)
  if (!mustMatch && len === 0) return 0

  // Use a for loop to avoid recursion
  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) {
          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
        }
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  let loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  const i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  const len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (let i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  const len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (let i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  const len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (let i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  const length = this.length
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.toLocaleString = Buffer.prototype.toString

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  let str = ''
  const max = exports.INSPECT_MAX_BYTES
  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
  if (this.length > max) str += ' ... '
  return '<Buffer ' + str + '>'
}
if (customInspectSymbol) {
  Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (isInstance(target, Uint8Array)) {
    target = Buffer.from(target, target.offset, target.byteLength)
  }
  if (!Buffer.isBuffer(target)) {
    throw new TypeError(
      'The "target" argument must be one of type Buffer or Uint8Array. ' +
      'Received type ' + (typeof target)
    )
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  let x = thisEnd - thisStart
  let y = end - start
  const len = Math.min(x, y)

  const thisCopy = this.slice(thisStart, thisEnd)
  const targetCopy = target.slice(start, end)

  for (let i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset // Coerce to Number.
  if (numberIsNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  let indexSize = 1
  let arrLength = arr.length
  let valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  let i
  if (dir) {
    let foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      let found = true
      for (let j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  const remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  const strLen = string.length

  if (length > strLen / 2) {
    length = strLen / 2
  }
  let i
  for (i = 0; i < length; ++i) {
    const parsed = parseInt(string.substr(i * 2, 2), 16)
    if (numberIsNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset >>> 0
    if (isFinite(length)) {
      length = length >>> 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  const remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  let loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
      case 'latin1':
      case 'binary':
        return asciiWrite(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  const res = []

  let i = start
  while (i < end) {
    const firstByte = buf[i]
    let codePoint = null
    let bytesPerSequence = (firstByte > 0xEF)
      ? 4
      : (firstByte > 0xDF)
          ? 3
          : (firstByte > 0xBF)
              ? 2
              : 1

    if (i + bytesPerSequence <= end) {
      let secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
const MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  const len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  let res = ''
  let i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  let ret = ''
  end = Math.min(buf.length, end)

  for (let i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  const len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  let out = ''
  for (let i = start; i < end; ++i) {
    out += hexSliceLookupTable[buf[i]]
  }
  return out
}

function utf16leSlice (buf, start, end) {
  const bytes = buf.slice(start, end)
  let res = ''
  // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
  for (let i = 0; i < bytes.length - 1; i += 2) {
    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  const len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  const newBuf = this.subarray(start, end)
  // Return an augmented `Uint8Array` instance
  Object.setPrototypeOf(newBuf, Buffer.prototype)

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUintLE =
Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUintBE =
Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  let val = this[offset + --byteLength]
  let mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUint8 =
Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUint16LE =
Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUint16BE =
Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUint32LE =
Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUint32BE =
Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const lo = first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24

  const hi = this[++offset] +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    last * 2 ** 24

  return BigInt(lo) + (BigInt(hi) << BigInt(32))
})

Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const hi = first * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  const lo = this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last

  return (BigInt(hi) << BigInt(32)) + BigInt(lo)
})

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let val = this[offset]
  let mul = 1
  let i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  let i = byteLength
  let mul = 1
  let val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 2, this.length)
  const val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = this[offset + 4] +
    this[offset + 5] * 2 ** 8 +
    this[offset + 6] * 2 ** 16 +
    (last << 24) // Overflow

  return (BigInt(val) << BigInt(32)) +
    BigInt(first +
    this[++offset] * 2 ** 8 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 24)
})

Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE (offset) {
  offset = offset >>> 0
  validateNumber(offset, 'offset')
  const first = this[offset]
  const last = this[offset + 7]
  if (first === undefined || last === undefined) {
    boundsError(offset, this.length - 8)
  }

  const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    this[++offset]

  return (BigInt(val) << BigInt(32)) +
    BigInt(this[++offset] * 2 ** 24 +
    this[++offset] * 2 ** 16 +
    this[++offset] * 2 ** 8 +
    last)
})

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  offset = offset >>> 0
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUintLE =
Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let mul = 1
  let i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUintBE =
Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  byteLength = byteLength >>> 0
  if (!noAssert) {
    const maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  let i = byteLength - 1
  let mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUint8 =
Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeUint16LE =
Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeUint16BE =
Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeUint32LE =
Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset + 3] = (value >>> 24)
  this[offset + 2] = (value >>> 16)
  this[offset + 1] = (value >>> 8)
  this[offset] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeUint32BE =
Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

function wrtBigUInt64LE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  lo = lo >> 8
  buf[offset++] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  hi = hi >> 8
  buf[offset++] = hi
  return offset
}

function wrtBigUInt64BE (buf, value, offset, min, max) {
  checkIntBI(value, min, max, buf, offset, 7)

  let lo = Number(value & BigInt(0xffffffff))
  buf[offset + 7] = lo
  lo = lo >> 8
  buf[offset + 6] = lo
  lo = lo >> 8
  buf[offset + 5] = lo
  lo = lo >> 8
  buf[offset + 4] = lo
  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff))
  buf[offset + 3] = hi
  hi = hi >> 8
  buf[offset + 2] = hi
  hi = hi >> 8
  buf[offset + 1] = hi
  hi = hi >> 8
  buf[offset] = hi
  return offset + 8
}

Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
})

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = 0
  let mul = 1
  let sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    const limit = Math.pow(2, (8 * byteLength) - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  let i = byteLength - 1
  let mul = 1
  let sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  this[offset] = (value >>> 8)
  this[offset + 1] = (value & 0xff)
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  this[offset] = (value & 0xff)
  this[offset + 1] = (value >>> 8)
  this[offset + 2] = (value >>> 16)
  this[offset + 3] = (value >>> 24)
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  this[offset] = (value >>> 24)
  this[offset + 1] = (value >>> 16)
  this[offset + 2] = (value >>> 8)
  this[offset + 3] = (value & 0xff)
  return offset + 4
}

Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE (value, offset = 0) {
  return wrtBigUInt64LE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE (value, offset = 0) {
  return wrtBigUInt64BE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
})

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  value = +value
  offset = offset >>> 0
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  const len = end - start

  if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
    // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end)
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, end),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
    if (val.length === 1) {
      const code = val.charCodeAt(0)
      if ((encoding === 'utf8' && code < 128) ||
          encoding === 'latin1') {
        // Fast path: If `val` fits into a single byte, use that numeric value.
        val = code
      }
    }
  } else if (typeof val === 'number') {
    val = val & 255
  } else if (typeof val === 'boolean') {
    val = Number(val)
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  let i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    const bytes = Buffer.isBuffer(val)
      ? val
      : Buffer.from(val, encoding)
    const len = bytes.length
    if (len === 0) {
      throw new TypeError('The value "' + val +
        '" is invalid for argument "value"')
    }
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// CUSTOM ERRORS
// =============

// Simplified versions from Node, changed for Buffer-only usage
const errors = {}
function E (sym, getMessage, Base) {
  errors[sym] = class NodeError extends Base {
    constructor () {
      super()

      Object.defineProperty(this, 'message', {
        value: getMessage.apply(this, arguments),
        writable: true,
        configurable: true
      })

      // Add the error code to the name to include it in the stack trace.
      this.name = `${this.name} [${sym}]`
      // Access the stack to generate the error message including the error code
      // from the name.
      this.stack // eslint-disable-line no-unused-expressions
      // Reset the name to the actual name.
      delete this.name
    }

    get code () {
      return sym
    }

    set code (value) {
      Object.defineProperty(this, 'code', {
        configurable: true,
        enumerable: true,
        value,
        writable: true
      })
    }

    toString () {
      return `${this.name} [${sym}]: ${this.message}`
    }
  }
}

E('ERR_BUFFER_OUT_OF_BOUNDS',
  function (name) {
    if (name) {
      return `${name} is outside of buffer bounds`
    }

    return 'Attempt to access memory outside buffer bounds'
  }, RangeError)
E('ERR_INVALID_ARG_TYPE',
  function (name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`
  }, TypeError)
E('ERR_OUT_OF_RANGE',
  function (str, range, input) {
    let msg = `The value of "${str}" is out of range.`
    let received = input
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
      received = addNumericalSeparator(String(input))
    } else if (typeof input === 'bigint') {
      received = String(input)
      if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
        received = addNumericalSeparator(received)
      }
      received += 'n'
    }
    msg += ` It must be ${range}. Received ${received}`
    return msg
  }, RangeError)

function addNumericalSeparator (val) {
  let res = ''
  let i = val.length
  const start = val[0] === '-' ? 1 : 0
  for (; i >= start + 4; i -= 3) {
    res = `_${val.slice(i - 3, i)}${res}`
  }
  return `${val.slice(0, i)}${res}`
}

// CHECK FUNCTIONS
// ===============

function checkBounds (buf, offset, byteLength) {
  validateNumber(offset, 'offset')
  if (buf[offset] === undefined || buf[offset + byteLength] === undefined) {
    boundsError(offset, buf.length - (byteLength + 1))
  }
}

function checkIntBI (value, min, max, buf, offset, byteLength) {
  if (value > max || value < min) {
    const n = typeof min === 'bigint' ? 'n' : ''
    let range
    if (byteLength > 3) {
      if (min === 0 || min === BigInt(0)) {
        range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`
      } else {
        range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` +
                `${(byteLength + 1) * 8 - 1}${n}`
      }
    } else {
      range = `>= ${min}${n} and <= ${max}${n}`
    }
    throw new errors.ERR_OUT_OF_RANGE('value', range, value)
  }
  checkBounds(buf, offset, byteLength)
}

function validateNumber (value, name) {
  if (typeof value !== 'number') {
    throw new errors.ERR_INVALID_ARG_TYPE(name, 'number', value)
  }
}

function boundsError (value, length, type) {
  if (Math.floor(value) !== value) {
    validateNumber(value, type)
    throw new errors.ERR_OUT_OF_RANGE(type || 'offset', 'an integer', value)
  }

  if (length < 0) {
    throw new errors.ERR_BUFFER_OUT_OF_BOUNDS()
  }

  throw new errors.ERR_OUT_OF_RANGE(type || 'offset',
                                    `>= ${type ? 1 : 0} and <= ${length}`,
                                    value)
}

// HELPER FUNCTIONS
// ================

const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node takes equal signs as end of the Base64 encoding
  str = str.split('=')[0]
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = str.trim().replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  let codePoint
  const length = string.length
  let leadSurrogate = null
  const bytes = []

  for (let i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  let c, hi, lo
  const byteArray = []
  for (let i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  let i
  for (i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance (obj, type) {
  return obj instanceof type ||
    (obj != null && obj.constructor != null && obj.constructor.name != null &&
      obj.constructor.name === type.name)
}
function numberIsNaN (obj) {
  // For IE11 support
  return obj !== obj // eslint-disable-line no-self-compare
}

// Create lookup table for `toString('hex')`
// See: https://github.com/feross/buffer/issues/219
const hexSliceLookupTable = (function () {
  const alphabet = '0123456789abcdef'
  const table = new Array(256)
  for (let i = 0; i < 16; ++i) {
    const i16 = i * 16
    for (let j = 0; j < 16; ++j) {
      table[i16 + j] = alphabet[i] + alphabet[j]
    }
  }
  return table
})()

// Return not function with Error if BigInt not supported
function defineBigIntMethod (fn) {
  return typeof BigInt === 'undefined' ? BufferBigIntNotDefined : fn
}

function BufferBigIntNotDefined () {
  throw new Error('BigInt not supported')
}


/***/ }),

/***/ "../../node_modules/ieee754/index.js":
/*!*******************************************!*\
  !*** ../../node_modules/ieee754/index.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports) => {

/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = (nBytes * 8) - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}


/***/ }),

/***/ "../../node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*************************************************************************!*\
  !*** ../../node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*************************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!globalThis.chrome?.runtime?.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "../dom-snapshot/dist/pollResultCjs.js":
/*!*********************************************!*\
  !*** ../dom-snapshot/dist/pollResultCjs.js ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
/* @applitools/dom-snapshot@4.18.7 */
module.exports=function(...t){const n=function(t,n,e){return function(){var t={};function r(t,n=0){const e=t.charCodeAt(n);return e>=55296&&e<56320?1024*(e-55296)+(t.charCodeAt(n+1)-56320)+65536:56320<=e&&e<=57343?-1:e}var o=function(t,n){const e=[];let o=0;for(let c=0;c<t.length;++c){const i=r(t,c);let u=0;i>0&&(u=i<128?1:i<2048?2:i<65536?3:i<2097152?4:i<67108864?5:6),o+u>n?(e.push(c),o=u):o+=u}return e};const c=function(t){return t&&t.__esModule?t:{default:t}}(o),i="WIP",u="SUCCESS",s="SUCCESS_CHUNKED",a="ERROR";var l=function(t,e,r={}){const o=function(t,{chunkByteLength:e=0}={}){var r;if(t){if(t.value){if(e){if(!t.chunks)try{const o=void 0!==n?null===(r=n.__EYES__APPLITOOLS__)||void 0===r?void 0:r._stringify:void 0,i=(null!=o?o:JSON.stringify)(t.value);t.chunks=(0,c.default)(i,e),t.chunks.length>0&&(t.from=0,t.value=i)}catch(t){return{status:a,error:t.message}}if(t.from>=0)return{status:s,value:t.value.substring(t.from,t.from=t.chunks.shift()),done:!t.from}}return{status:u,value:t.value}}return t.error?{status:a,error:t.error}:{status:i}}return{status:a,error:"unexpected poll request received - cannot find state of current operation"}}((t=t||{})[e],r);return(o.status===u||o.status===a||o.status===s&&o.done)&&delete t[e],o};const f=l;var d=function(t){return t&&t.__esModule?t:{default:t}};Object.defineProperty(t,"__esModule",{value:!0}),t.isAccessibleFrame=t.isInlineFrame=t.absolutizeUrl=y=t.poll=t.pollify=t.chunkify=void 0;const _=d(o);t.chunkify=_.default;const h=d((function(t,n,e){return r=>function(...o){return n[e]||(n[e]={},Promise.resolve().then((()=>t(...o))).then((t=>n[e].value=t)).catch((t=>n[e].error=t.message+"\nStack:"+t.stack))),f(n,e,r)}}));t.pollify=h.default;const m=d(l);var y=t.poll=m.default;const p=d((function(t,n){if(function(t){try{return new URL(t),!0}catch(t){return!1}}(t))return t;let e=!0;try{e=t!==decodeURI(t)}catch(t){e=!0}try{const r=new URL(t,n).href;return e?r:decodeURI(r)}catch(n){return e?t:decodeURI(t)}}));t.absolutizeUrl=p.default;const w=d((function(t){return t.contentDocument&&t.contentDocument.location&&!/^https?:$/.test(t.contentDocument.location.protocol)}));t.isInlineFrame=w.default;const S=d((function(t){try{const n=t.contentDocument;return Boolean(n&&n.defaultView&&n.defaultView.frameElement)}catch(t){return!1}}));return t.isAccessibleFrame=S.default,function(t){var n;const r=e.__EYES__APPLITOOLS__,o=null!==(n=null==r?void 0:r._stringify)&&void 0!==n?n:JSON.stringify;try{return o(y(r,"domSnapshotResult",t))}catch(t){return o({status:"ERROR",error:t.message})}}}()};let e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(document,window,window)(...t);try{let r=window.__applitools_sandbox;r||(r=document.createElement("iframe"),r.setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);const o=Math.floor(4294967296*Math.random()),c=r.contentDocument.createElement("script");c.textContent="window['ctor-"+o+"'] = "+n.toString()+";",r.contentDocument.head.appendChild(c);const i=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof i)throw new Error("Sandbox failed to extract function");e=!1;const u=r.contentWindow,s=u.__EYES__APPLITOOLS__=u.__EYES__APPLITOOLS__||{};s._stringify||(s._stringify=u.JSON.stringify.bind(u.JSON));const a=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};function l(t){if(u.Array.isArray(t)){const n=new u.Array(t.length);for(let e=0;e<t.length;e++)n[e]=l(t[e]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){const n=new u.Object;for(const e in t)Object.prototype.hasOwnProperty.call(t,e)&&(n[e]=l(t[e]));return n}return t}a._stringify&&a._stringify!==JSON.stringify||(a._stringify=u.JSON.stringify.bind(u.JSON));const f=new u.Array(t.length);for(let d=0;d<t.length;d++)f[d]=l(t[d]);return i(document,window,u)(...f)}catch(_){try{return n(document,window,window)(...t)}catch(h){throw e?h:_}}};
//# sourceMappingURL=pollResultCjs.js.map


/***/ }),

/***/ "../dom-snapshot/dist/processPagePollCjs.js":
/*!**************************************************!*\
  !*** ../dom-snapshot/dist/processPagePollCjs.js ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
/* @applitools/dom-snapshot@4.18.7 */
module.exports=function(...e){const t=function(e,t,n){return function(){var r={};function o(e,t=0){const n=e.charCodeAt(t);return n>=55296&&n<56320?1024*(n-55296)+(e.charCodeAt(t+1)-56320)+65536:56320<=n&&n<=57343?-1:n}var i=function(e,t){const n=[];let r=0;for(let i=0;i<e.length;++i){const a=o(e,i);let s=0;a>0&&(s=a<128?1:a<2048?2:a<65536?3:a<2097152?4:a<67108864?5:6),r+s>t?(n.push(i),r=s):r+=s}return n};const a=function(e){return e&&e.__esModule?e:{default:e}}(i),s="WIP",l="SUCCESS",c="SUCCESS_CHUNKED",u="ERROR";var d=function(e,n,r={}){const o=function(e,{chunkByteLength:n=0}={}){var r;if(e){if(e.value){if(n){if(!e.chunks)try{const o=void 0!==t?null===(r=t.__EYES__APPLITOOLS__)||void 0===r?void 0:r._stringify:void 0,i=(null!=o?o:JSON.stringify)(e.value);e.chunks=(0,a.default)(i,n),e.chunks.length>0&&(e.from=0,e.value=i)}catch(e){return{status:u,error:e.message}}if(e.from>=0)return{status:c,value:e.value.substring(e.from,e.from=e.chunks.shift()),done:!e.from}}return{status:l,value:e.value}}return e.error?{status:u,error:e.error}:{status:s}}return{status:u,error:"unexpected poll request received - cannot find state of current operation"}}((e=e||{})[n],r);return(o.status===l||o.status===u||o.status===c&&o.done)&&delete e[n],o};const h=d;var p=function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(r,"__esModule",{value:!0});var f=r.isAccessibleFrame=k=r.isInlineFrame=v=r.absolutizeUrl=r.poll=y=r.pollify=r.chunkify=void 0;const m=p(i);r.chunkify=m.default;const g=p((function(e,t,n){return r=>function(...o){return t[n]||(t[n]={},Promise.resolve().then((()=>e(...o))).then((e=>t[n].value=e)).catch((e=>t[n].error=e.message+"\nStack:"+e.stack))),h(t,n,r)}}));var y=r.pollify=g.default;const b=p(d);r.poll=b.default;const _=p((function(e,t){if(function(e){try{return new URL(e),!0}catch(e){return!1}}(e))return e;let n=!0;try{n=e!==decodeURI(e)}catch(e){n=!0}try{const r=new URL(e,t).href;return n?r:decodeURI(r)}catch(t){return n?e:decodeURI(e)}}));var v=r.absolutizeUrl=_.default;const w=p((function(e){return e.contentDocument&&e.contentDocument.location&&!/^https?:$/.test(e.contentDocument.location.protocol)}));var k=r.isInlineFrame=w.default;const x=p((function(e){try{const t=e.contentDocument;return Boolean(t&&t.defaultView&&t.defaultView.frameElement)}catch(e){return!1}}));f=r.isAccessibleFrame=x.default;const S="__EYES__APPLITOOLS__";var O,A={};function E(e){if(!function(e){try{const t=new URL(e);return Boolean(t.username||t.password)}catch(e){return!1}}(e))return e;let t=!0;try{t=e!==decodeURI(e)}catch(e){t=!0}const n=new URL(e);return n.username="",n.password="",t?n.href:decodeURI(n.href)}function C(){return t.crypto.getRandomValues(new Uint32Array(1))[0]}(O=A).translateTo=function(n){return function(){var n=function(e,t,n){return(r=function(t){var n=void 0===t?[]:t,r=n[0],o=n[1];r=r||e.documentElement;var i={value:"translate("+-o.x+"px, "+-o.y+"px)",important:!0};return function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort();o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{}),o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")}))}([r,{transform:i,"-webkit-transform":i}]),o})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.translateTo.snippetName="translateTo",O.setElementStyleProperties=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.setElementStyleProperties.snippetName="setElementStyleProperties",O.setElementAttributes=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1];return Object.keys(r).reduce((function(e,t){return e[t]=n.getAttribute(t),n.setAttribute(t,r[t]),e}),{})})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.setElementAttributes.snippetName="setElementAttributes",O.scrollTo=function(n){return function(){var n=function(e,t,n){return o=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i},(r=function(t){var n=void 0===t?[]:t,r=n[0],i=n[1];r=r||e.documentElement;var a=o([r,{"scroll-behavior":{value:"auto",important:!0}}]);return r.scrollTo?r.scrollTo(i.x,i.y):(r.scrollLeft=i.x,r.scrollTop=i.y),o([r,a]),{x:r.scrollLeft,y:r.scrollTop}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.scrollTo.snippetName="scrollTo",O.reloadPage=function(n){return function(){var n=function(e,t,n){return(r=function(){t.location.reload()})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(0,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(0,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.reloadPage.snippetName="reloadPage",O.lazyLoad=function(n){return function(){var n=function(e,t,n){return function(){var n=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i},r="__EYES__APPLITOOLS__",o="lazyLoadResult";t[r]=t[r]||{};var i=function(t){var r=void 0===t?[]:t,o=r[0],i=r[1];o=o||e.documentElement;var a=n([o,{"scroll-behavior":{value:"auto",important:!0}}]);return o.scrollTo?o.scrollTo(i.x,i.y):(o.scrollLeft=i.x,o.scrollTop=i.y),n([o,a]),{x:o.scrollLeft,y:o.scrollTop}};return function(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}((function(n){var a=void 0===n?[]:n,s=a[0],l=a[1],c=void 0===l?{}:l,u=c.scrollLength,d=c.waitingTime,h=c.maxAmountToScroll;try{if(t[r][o]){var p=t[r][o];return"WIP"!==p.status&&delete t[r][o],JSON.stringify(p)}var f=function(){try{var n=s&&"number"==typeof s.scrollHeight?s:e&&(e.scrollingElement||e.documentElement)||{};return{height:Number(n.scrollHeight)||0,client:Number(n.clientHeight)||void 0!==t&&Number(t.innerHeight)||0}}catch(n){return{height:0,client:0}}},m=function(){var e=f();e.height>_&&(_=e.height)};t[r][o]={status:"WIP"};var g=function(e){var n=[][0];return n?{x:n.scrollLeft,y:n.scrollTop}:{x:t.scrollX||t.pageXOffset,y:t.scrollY||t.pageYOffset}}(),y=[];y.push({maxAmountToScroll:h,scrollLength:u,waitingTime:d,startingScrollPositionX:g.x,startingScrollPositionY:g.y});var b=Date.now(),_=0,v=0,w="number"==typeof u&&u>0&&"number"==typeof h&&h>0?Math.ceil(h/u*1.5)+10:100;return function e(n){var a=void 0===n?{}:n,l=a.doneScrolling,c=a.previousScrollResult,p=void 0===c?{}:c,k=a.resumeY,x=a.attempts,S=a.stalls;x=x||0,S=S||0,setTimeout((function(){try{var n=x>=w;if(l||n){var a=i([s,g]),c=a.x,d=a.y;return y.push({x:c,y:d,msSinceStart:Date.now()-b,reason:n&&!l?"cappedAt":"stalled"===l?"stalled":"done",attempts:x,stalls:S,maxScrollTop:v,maxScrollHeight:_}),void(t[r][o]={status:"SUCCESS",value:y})}var O=i([s,{x:g.x,y:(void 0!==k?k:p.y)+u}]),A=O.x,E=O.y;y.push({x:A,y:E,msSinceStart:Date.now()-b}),E>v&&(v=E),m();var C,P=E===p.y,L=!1,z=0;E>=h?L=!0:P&&(function(e){m();var t=f();return!t.height||!t.client||!(v>t.height)&&e+t.client>=t.height-2}(E)?L=!0:S>=3?(L="stalled",z=S):(z=S+1,C=Math.max(E,v))),e({doneScrolling:L,previousScrollResult:{x:A,y:E},resumeY:C,attempts:x+1,stalls:z})}catch(e){t[r][o]={status:"ERROR",error:e}}}),d)}(),JSON.stringify(t[r][o])}catch(n){return t[r][o]={status:"ERROR",error:n},JSON.stringify(t[r][o])}}))}()},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.lazyLoad.snippetName="lazyLoad",O.isStaleElement=function(n){return function(){var n=function(e,t,n){return(r=function(n){var r=n&&n[0]||null;return!(r&&("isConnected"in t.Node.prototype?r.isConnected:e.documentElement.contains?e.documentElement.contains(r):r.ownerDocument.documentElement.contains(r)))})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.isStaleElement.snippetName="isStaleElement",O.isEqualElements=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=void 0===e?[]:e;return t[0]===t[1]})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.isEqualElements.snippetName="isEqualElements",O.isElementScrollable=function(n){return function(){var n=function(e,t,n){return(r=function(e){var n=(void 0===e?[]:e)[0],r=function(e){var n,r=void 0===e?[]:e,o=r[0],i=r[1],a=void 0===i?[]:i;try{n=t.getComputedStyle(o)}catch(e){return[]}return n&&"function"==typeof n.getPropertyValue?a.map((function(e){return n.getPropertyValue(e)})):[]}([n,["overflow-x","overflow-y","overflow"]]);return("scroll"===r[0]||"auto"===r[0]||"hidden"===r[2])&&n.scrollWidth>n.clientWidth||("scroll"===r[1]||"auto"===r[1]||"hidden"===r[2])&&n.scrollHeight>n.clientHeight})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(0,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(0,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.isElementScrollable.snippetName="isElementScrollable",O.getViewport=function(n){return function(){var n=function(e,t,n){return(r=function(){var n,r=0,o=0;return t.innerHeight?o=t.innerHeight:e.documentElement&&e.documentElement.clientHeight?o=e.documentElement.clientHeight:e.body&&e.body.clientHeight&&(o=e.body.clientHeight),t.innerWidth?r=t.innerWidth:e.documentElement&&e.documentElement.clientWidth?r=e.documentElement.clientWidth:e.body&&e.body.clientWidth&&(r=e.body.clientWidth),t.screen&&t.screen.orientation?n=t.screen.orientation.type.replace(/-primary$/,""):null!=t.orientation&&(0===t.orientation?n="portrait":180===t.orientation?n="portrait-secondary":90===t.orientation?n="landscape":-90===t.orientation&&(n="landscape-secondary")),{viewportSize:{width:r,height:o},pixelRatio:t.devicePixelRatio,viewportScale:t.visualViewport&&t.visualViewport.scale,orientation:n}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getViewport.snippetName="getViewport",O.getUserAgent=function(n){return function(){var n=function(e,t,n){return i="userAgent",t[o="__EYES__APPLITOOLS__"]=t[o]||{},(r=function(){try{if(t[o][i]){var e=t[o][i];return"WIP"!==e.status&&delete t[o][i],JSON.stringify(e)}return t.navigator.userAgentData?(t[o][i]={status:"WIP"},t.navigator.userAgentData.getHighEntropyValues(["brands","platform","platformVersion","model"]).then((function(e){t[o][i]={status:"SUCCESS",value:{legacy:t.navigator.userAgent,brands:e.brands,mobile:e.mobile,platform:e.platform,platformVersion:e.platformVersion,model:e.model}}})).catch((function(e){t[o][i]={status:"ERROR",error:e.message}}))):t[o][i]={status:"SUCCESS",value:t.navigator.userAgent},JSON.stringify(t[o][i])}catch(e){return t[o][i]={status:"ERROR",error:e.message},JSON.stringify(t[o][i])}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o,i},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(0,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(0,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getUserAgent.snippetName="getUserAgent",O.getText=function(n){return function(){var n=function(e,t,n){return(r=function(e){return e[0].innerText})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getText.snippetName="getText",O.getShadowRoot=function(n){return function(){var n=function(e,t,n){return(r=function(e){return(void 0===e?[]:e)[0].shadowRoot})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getShadowRoot.snippetName="getShadowRoot",O.getElementXpath=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=(void 0===e?[]:e)[0],n="",r=t.ownerDocument;if(!r)return n;for(var o=t;o!==r;){var i=Array.prototype.filter.call(o.parentNode.childNodes,(function(e){return e.tagName===o.tagName})).indexOf(o);n="/"+o.tagName+"["+(i+1)+"]"+n,o=o.parentNode}return n})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementXpath.snippetName="getElementXpath",O.getElementTranslateOffset=function(n){return function(){var n=function(e,t,n){return(r=function(t){var n=(void 0===t?[]:t)[0],r=function(e){var t=void 0===e?[]:e,n=t[1],r=void 0===n?[]:n,o=t[0].style;return o&&"function"==typeof o.getPropertyValue?r.reduce((function(e,t){return e[t]={value:o.getPropertyValue(t),important:Boolean(o.getPropertyPriority(t))},e}),{}):{}}([void 0===n?e.documentElement:n,["transform","-webkit-transform"]]),o=Object.keys(r).reduce((function(e,t){var n=r[t].value;if(n){var o=n.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(o){var i=o[1],a=void 0!==o[3]?o[3]:0;e.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else e.push({x:0,y:0})}return e}),[]);if(!o.every((function(e){return o[0].x===e.x||o[0].y===e.y})))throw new Error("Got different css positions!");return o[0]||{x:0,y:0}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementTranslateOffset.snippetName="getElementTranslateOffset",O.getElementStyleProperties=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=void 0===r?[]:r,i=n.style;return i&&"function"==typeof i.getPropertyValue?o.reduce((function(e,t){return e[t]={value:i.getPropertyValue(t),important:Boolean(i.getPropertyPriority(t))},e}),{}):{}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementStyleProperties.snippetName="getElementStyleProperties",O.getElementScrollOffset=function(n){return function(){var n=function(e,t,n){return(r=function(e){var n=(void 0===e?[]:e)[0];return n?{x:n.scrollLeft,y:n.scrollTop}:{x:t.scrollX||t.pageXOffset,y:t.scrollY||t.pageYOffset}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(0,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(0,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementScrollOffset.snippetName="getElementScrollOffset",O.getElementRect=function(n){return function(){var n=function(e,t,n){return function(){var n=function(t){var n=(void 0===t?[]:t)[0],r=function(e){var t=void 0===e?[]:e,n=t[1],r=void 0===n?[]:n,o=t[0].style;return o&&"function"==typeof o.getPropertyValue?r.reduce((function(e,t){return e[t]={value:o.getPropertyValue(t),important:Boolean(o.getPropertyPriority(t))},e}),{}):{}}([void 0===n?e.documentElement:n,["transform","-webkit-transform"]]),o=Object.keys(r).reduce((function(e,t){var n=r[t].value;if(n){var o=n.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(o){var i=o[1],a=void 0!==o[3]?o[3]:0;e.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else e.push({x:0,y:0})}return e}),[]);if(!o.every((function(e){return o[0].x===e.x||o[0].y===e.y})))throw new Error("Got different css positions!");return o[0]||{x:0,y:0}},r=function(e){var r=(void 0===e?[]:e)[0],o=function(e){var n=(void 0===e?[]:e)[0];return n?{x:n.scrollLeft,y:n.scrollTop}:{x:t.scrollX||t.pageXOffset,y:t.scrollY||t.pageYOffset}}([r]),i=n([r]);return{x:o.x+i.x,y:o.y+i.y}};return function(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}((function(n){var o=void 0===n?[]:n,i=o[0],a=o[1],s=void 0!==a&&a,l="string"==typeof i.tagName?i.tagName.toLowerCase():"";if(i===e.documentElement||l===function(){var t="HTML",n=e.scrollingElement;return n&&(t=n.tagName),t.toLowerCase()}())return{x:0,y:0,width:i.clientWidth,height:i.clientHeight};var c="function"==typeof i.getBoundingClientRect?i.getBoundingClientRect():{left:0,top:0,width:0,height:0},u={x:c.left,y:c.top,width:c.width,height:c.height};if(s){var d;try{d=t.getComputedStyle(i)}catch(n){d=null}d&&"function"==typeof d.getPropertyValue&&(u.x+=parseInt(d.getPropertyValue("border-left-width")),u.y+=parseInt(d.getPropertyValue("border-top-width"))),u.width=i.clientWidth,u.height=i.clientHeight}var h=function(n){for(var r,o=(void 0===n?[]:n)[0];o.offsetParent&&o.offsetParent!==e.body&&o.offsetParent!==e.documentElement;)o=o.offsetParent;try{r=t.getComputedStyle(o)}catch(n){return null}return r&&"function"==typeof r.getPropertyValue&&"fixed"===r.getPropertyValue("position")?o:null}([i]);if(h){if(h!==i){var p=r([h]);u.x+=p.x,u.y+=p.y}}else{var f=r();u.x+=f.x,u.y+=f.y}return u}))}()},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementRect.snippetName="getElementRect",O.getElementProperties=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1];return(void 0===r?[]:r).reduce((function(e,t){return e[t]=n[t],e}),{})})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementProperties.snippetName="getElementProperties",O.getElementInnerOffset=function(n){return function(){var n=function(e,t,n){return o=function(t){var n=(void 0===t?[]:t)[0],r=function(e){var t=void 0===e?[]:e,n=t[1],r=void 0===n?[]:n,o=t[0].style;return o&&"function"==typeof o.getPropertyValue?r.reduce((function(e,t){return e[t]={value:o.getPropertyValue(t),important:Boolean(o.getPropertyPriority(t))},e}),{}):{}}([void 0===n?e.documentElement:n,["transform","-webkit-transform"]]),o=Object.keys(r).reduce((function(e,t){var n=r[t].value;if(n){var o=n.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(o){var i=o[1],a=void 0!==o[3]?o[3]:0;e.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else e.push({x:0,y:0})}return e}),[]);if(!o.every((function(e){return o[0].x===e.x||o[0].y===e.y})))throw new Error("Got different css positions!");return o[0]||{x:0,y:0}},(r=function(e){var n=(void 0===e?[]:e)[0],r=function(e){var n=(void 0===e?[]:e)[0];return n?{x:n.scrollLeft,y:n.scrollTop}:{x:t.scrollX||t.pageXOffset,y:t.scrollY||t.pageYOffset}}([n]),i=o([n]);return{x:r.x+i.x,y:r.y+i.y}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementInnerOffset.snippetName="getElementInnerOffset",O.getElementFixedAncestor=function(n){return function(){var n=function(e,t,n){return(r=function(n){for(var r,o=(void 0===n?[]:n)[0];o.offsetParent&&o.offsetParent!==e.body&&o.offsetParent!==e.documentElement;)o=o.offsetParent;try{r=t.getComputedStyle(o)}catch(n){return null}return r&&"function"==typeof r.getPropertyValue&&"fixed"===r.getPropertyValue("position")?o:null})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementFixedAncestor.snippetName="getElementFixedAncestor",O.getElementContentSize=function(n){return function(){var n=function(e,t,n){return o=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i},(r=function(t){var n,r=(void 0===t?[]:t)[0],i="string"==typeof r.tagName?r.tagName.toLowerCase():"";r!==e.documentElement&&i!==function(){var t="HTML",n=e.scrollingElement;return n&&(t=n.tagName),t.toLowerCase()}()||(n=o([r,{transform:"none"}]));var a={width:r.scrollWidth,height:r.scrollHeight};return n&&o([r,n]),a})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementContentSize.snippetName="getElementContentSize",O.getElementComputedStyleProperties=function(n){return function(){var n=function(e,t,n){return(r=function(e){var n,r=void 0===e?[]:e,o=r[0],i=r[1],a=void 0===i?[]:i;try{n=t.getComputedStyle(o)}catch(e){return[]}return n&&"function"==typeof n.getPropertyValue?a.map((function(e){return n.getPropertyValue(e)})):[]})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(0,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(0,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getElementComputedStyleProperties.snippetName="getElementComputedStyleProperties",O.getDocumentSize=function(n){return function(){var n=function(e,t,n){return(r=function(){var t=e.documentElement.scrollWidth,n=e.documentElement.scrollHeight,r=e.documentElement.clientHeight,o=e.body.scrollWidth,i=e.body.scrollHeight,a=e.body.clientHeight;return{width:Math.max(t,o),height:Math.max(r,n,a,i)}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getDocumentSize.snippetName="getDocumentSize",O.getDocumentScrollingElement=function(n){return function(){var n=function(e,t,n){return(r=function(){var t="HTML",n=e.scrollingElement;return n&&(t=n.tagName),t.toLowerCase()})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getDocumentScrollingElement.snippetName="getDocumentScrollingElement",O.getContextInfo=function(n){return function(){var n=function(e,t,n){return(r=function(){var n,r,o;try{n=t.top.document===t.document||"root-context"===t.parent.document["applitools-marker"]}catch(e){n=!1}try{r=!t.parent.document===t.document}catch(n){r=!0}if(!r)try{o=function(e){var t=(void 0===e?[]:e)[0],n="",r=t.ownerDocument;if(!r)return n;for(var o=t;o!==r;){var i=Array.prototype.filter.call(o.parentNode.childNodes,(function(e){return e.tagName===o.tagName})).indexOf(o);n="/"+o.tagName+"["+(i+1)+"]"+n,o=o.parentNode}return n}([t.frameElement])}catch(n){o=null}return[e.documentElement,o,n,r]})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getContextInfo.snippetName="getContextInfo",O.getChildFramesInfo=function(n){return function(){var n=function(e,t,n){return(r=function(){return function t(n){var r=[];(n=n||e).querySelectorAll("frame, iframe").forEach((function(e){return r.push([e,!e.contentDocument,e.src])}));var o=Array.prototype.filter.call(n.querySelectorAll("*"),(function(e){return e.shadowRoot})).map((function(e){return t(e.shadowRoot)}));return r.concat.apply(r,o)}()})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.getChildFramesInfo.snippetName="getChildFramesInfo",O.focusElement=function(n){return function(){var n=function(e,t,n){return(r=function(e){var t=(void 0===e?[]:e)[0];t&&t.focus()})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n().apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n().apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.focusElement.snippetName="focusElement",O.cleanupPageMarker=function(n){return function(){var n=function(e,t,n){return o=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i},(r=function(){var t=e.querySelector("[data-applitools-marker]");t&&e.body.removeChild(t);var n=e.documentElement.getAttribute("data-applitools-original-transforms"),r=e.body.getAttribute("data-applitools-original-transforms");n&&o([e.documentElement,JSON.parse(n)]),r&&o([e.body,JSON.parse(r)])})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.cleanupPageMarker.snippetName="cleanupPageMarker",O.cleanupElementIds=function(n){return function(){var n=function(e,t,n){return(r=function(t){(t=t&&t[0])&&"function"==typeof t.forEach&&t.forEach((function(t){t.removeAttribute("data-applitools-selector");var n=t;if(n.getRootNode)try{for(;n;){var r=n.getRootNode();if(!r||r===e)break;(n=r.constructor&&"ShadowRoot"===r.constructor.name?r.host:r.defaultView?r.defaultView.frameElement:null)&&n.removeAttribute("data-applitools-selector")}}catch(t){}}))})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.cleanupElementIds.snippetName="cleanupElementIds",O.blurElement=function(n){return function(){var n=function(e,t,n){return(r=function(t){var n=(void 0===t?[]:t)[0]||e.activeElement;return n&&n.blur(),n})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.blurElement.snippetName="blurElement",O.addPageMarker=function(n){return function(){var n=function(e,t,n){return o=function(e){var t=void 0===e?[]:e,n=t[0],r=t[1],o=Object.keys(r).sort(),i=o.reduce((function(e,t){return e[t]={value:n.style.getPropertyValue(t),important:Boolean(n.style.getPropertyPriority(t))},e}),{});return o.forEach((function(e){n.style.setProperty(e,"string"!=typeof r[e]&&r[e]?r[e].value:r[e],r[e]&&r[e].important?"important":"")})),i},r=function(t){var n=t[0],r=n.mask,i=n.size,a=void 0===i?1:i,s={1:"rgb(0, 0, 0)",0:"rgb(255, 255, 255)"},l=a,c=e.createElement("div");c.setAttribute("data-applitools-marker",""),c.style.setProperty("position","fixed","important"),c.style.setProperty("top","0","important"),c.style.setProperty("left","0","important"),c.style.setProperty("box-sizing","content-box","important"),c.style.setProperty("padding",l+"px","important"),c.style.setProperty("background","rgb(128, 128, 128)","important"),c.style.setProperty("z-index","2147483647","important");for(var u,d=0;d<r.length;d+=u){for(u=1;r[d]===r[d+u];)++u;var h=r[d],p=e.createElement("div");p.style.setProperty("display","block","important"),p.style.setProperty("float","left","important"),p.style.setProperty("width",u*a+"px","important"),p.style.setProperty("height",a+"px","important"),p.style.setProperty("background",s[h],"important"),c.appendChild(p)}var f={value:"none",important:!0},m=o([e.documentElement,{transform:f,"-webkit-transform":f}]),g=o([e.body,{transform:f,"-webkit-transform":f}]);return e.documentElement.setAttribute("data-applitools-original-transforms",JSON.stringify(m)),e.body.setAttribute("data-applitools-original-transforms",JSON.stringify(g)),e.body.appendChild(c),{mask:r,size:a,offset:l}},r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.addPageMarker.snippetName="addPageMarker",O.addFallbackSelectorIfNeeded=function(n){return function(){var n=function(e,t,n){return(r=function(n){if(!n.hasAttribute("data-applitools-fallback-selector")){if(function(n){var r=n&&n[0]||null;return!(r&&("isConnected"in t.Node.prototype?r.isConnected:e.documentElement.contains?e.documentElement.contains(r):r.ownerDocument.documentElement.contains(r)))}([n]))throw new Error("The element is not connected to the DOM: "+function(e){var t=e.attributes,n=e.tagName,r=e.children.length,o=[].slice.call(t).map((function(e){return e.name+'="'+e.value+'"'})).join(" ");return"<"+n+" "+o+(r?">":"/>")}(n));n.setAttribute("data-applitools-fallback-selector",function(e){for(var t=[];e&&e.nodeType===Node.ELEMENT_NODE;)try{var n,r=e.tagName.toLowerCase(),o=[].slice.call((null==(n=e.parentNode)?void 0:n.children)||[]).indexOf(e);o>-1&&(r+=":nth-child("+(o+1)+")"),t.unshift(r),e=e.parentNode}catch(e){break}return t.length?t.join(" > "):"html"}(n))}})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.addFallbackSelectorIfNeeded.snippetName="addFallbackSelectorIfNeeded",O.addElementIds=function(n){return function(){var n=function(e,t,n){return function(){var n=function(n){var r=n&&n[0]||null;return!(r&&("isConnected"in t.Node.prototype?r.isConnected:e.documentElement.contains?e.documentElement.contains(r):r.ownerDocument.documentElement.contains(r)))},r=n,o=function(e){if(!e.hasAttribute("data-applitools-fallback-selector")){if(r([e]))throw new Error("The element is not connected to the DOM: "+function(e){var t=e.attributes,n=e.tagName,r=e.children.length,o=[].slice.call(t).map((function(e){return e.name+'="'+e.value+'"'})).join(" ");return"<"+n+" "+o+(r?">":"/>")}(e));e.setAttribute("data-applitools-fallback-selector",function(e){for(var t=[];e&&e.nodeType===Node.ELEMENT_NODE;)try{var n,r=e.tagName.toLowerCase(),o=[].slice.call((null==(n=e.parentNode)?void 0:n.children)||[]).indexOf(e);o>-1&&(r+=":nth-child("+(o+1)+")"),t.unshift(r),e=e.parentNode}catch(e){break}return t.length?t.join(" > "):"html"}(e))}},i=n;function a(t,n){if(i([t])){var r=function(e){return null!=e&&e.getAttribute?e.getAttribute("data-applitools-fallback-selector"):{error:"invalid element: "+JSON.stringify(e)}}(t);if(!r)return{error:"Failed to recover from stale element"};if(r.error)return r;var s=e.querySelectorAll(r);if(!s||1!==s.length)return{error:"Failed to recover from stale element - selector found: "+r};var l=s[0];return l.setAttribute("data-applitools-selector",n),l.setAttribute("data-applitools-recovered",!0),a(l,n)}o(t);var c=t.getAttribute("data-applitools-selector"),u=c?c+" "+n:n;return t.setAttribute("data-applitools-selector",u),'[data-applitools-selector~="'+n+'"]'}return function(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}((function(t){return t.map((function(t){var n=t[0],r=t[1];return n.map((function(t){var n=function(t){for(var n=[{element:t,kind:"root"}],r=new Set([t]),o=t;o;){var i,a=o.getRootNode&&o.getRootNode();if(!a)break;if(a===e)break;if(a.constructor&&"ShadowRoot"===a.constructor.name?(o=a.host,i="shadow"):(o=a.defaultView?a.defaultView.frameElement:null,i="frame"),o){if(r.has(o))break;r.add(o),n.push({element:o,kind:i})}}return n}(t);return n.map((function(e){return{selector:a(e.element,r),kind:e.kind}}))}))}))}))}()},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return n(e,t).apply(void 0,arguments);try{var o=function e(t){if(c.Array.isArray(t)){for(var n=new c.Array(t.length),r=0;r<t.length;r++)n[r]=e(t[r]);return n}if(t&&"object"==typeof t&&Object.getPrototypeOf(t)===Object.prototype){var o=new c.Object;for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(o[i]=e(t[i]));return o}return t},i=t.__applitools_sandbox;i||((i=e.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),e.head.appendChild(i),t.__applitools_sandbox=i);var a=Math.floor(4294967296*Math.random()),s=i.contentDocument.createElement("script");s.textContent="window['ctor-"+a+"'] = "+n.toString()+";",i.contentDocument.head.appendChild(s);var l=i.contentWindow["ctor-"+a];if(delete i.contentWindow["ctor-"+a],"function"!=typeof l)throw new Error("Sandbox failed to extract function");r=!1;var c=i.contentWindow,u=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};u._stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));var d=t.__EYES__APPLITOOLS__=t.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var h=new c.Array(arguments.length),p=0;p<arguments.length;p++)h[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return l(e,t,c).apply(void 0,h)}catch(o){try{return n(e,t).apply(void 0,arguments)}catch(n){throw r?n:o}}}(n)},O.addElementIds.snippetName="addElementIds";const P=1,L=2,z=3,N=4,T=5,j=6,I=7,R=8,D=9,M=10,B=11,W=12,J=13,F=14,Y=15,U=16,$=17,V=18,q=19,H=20,Z=21,K=22,G=23,X=24,Q=25,ee=0;function te(e){return e>=48&&e<=57}function ne(e){return te(e)||e>=65&&e<=70||e>=97&&e<=102}function re(e){return e>=65&&e<=90}function oe(e){return function(e){return re(e)||function(e){return e>=97&&e<=122}(e)}(e)||function(e){return e>=128}(e)||95===e}function ie(e){return oe(e)||te(e)||45===e}function ae(e){return e>=0&&e<=8||11===e||e>=14&&e<=31||127===e}function se(e){return 10===e||13===e||12===e}function le(e){return se(e)||32===e||9===e}function ce(e,t){return 92===e&&!se(t)&&t!==ee}function ue(e,t,n){return 45===e?oe(t)||45===t||ce(t,n):!!oe(e)||92===e&&ce(e,t)}function de(e,t,n){return 43===e||45===e?te(t)?2:46===t&&te(n)?3:0:46===e?te(t)?2:0:te(e)?1:0}function he(e){return 65279===e||65534===e?1:0}const pe=new Array(128),fe=130,me=131,ge=132,ye=133;for(let e=0;e<pe.length;e++)pe[e]=le(e)&&fe||te(e)&&me||oe(e)&&ge||ae(e)&&ye||e||128;function be(e){return e<128?pe[e]:ge}function _e(e,t){return t<e.length?e.charCodeAt(t):0}function ve(e,t,n){return 13===n&&10===_e(e,t+1)?2:1}function we(e,t,n){let r=e.charCodeAt(t);return re(r)&&(r|=32),r===n}function ke(e,t,n,r){if(n-t!==r.length)return!1;if(t<0||n>e.length)return!1;for(let o=t;o<n;o++){const n=r.charCodeAt(o-t);let i=e.charCodeAt(o);if(re(i)&&(i|=32),i!==n)return!1}return!0}function xe(e,t){for(;t<e.length&&le(e.charCodeAt(t));t++);return t}function Se(e,t){for(;t<e.length&&te(e.charCodeAt(t));t++);return t}function Oe(e,t){if(ne(_e(e,(t+=2)-1))){for(const n=Math.min(e.length,t+5);t<n&&ne(_e(e,t));t++);const n=_e(e,t);le(n)&&(t+=ve(e,t,n))}return t}function Ae(e,t){for(;t<e.length;t++){const n=e.charCodeAt(t);if(!ie(n)){if(!ce(n,_e(e,t+1)))break;t=Oe(e,t)-1}}return t}function Ee(e,t){let n=e.charCodeAt(t);if(43!==n&&45!==n||(n=e.charCodeAt(t+=1)),te(n)&&(t=Se(e,t+1),n=e.charCodeAt(t)),46===n&&te(e.charCodeAt(t+1))&&(t=Se(e,t+=2)),we(e,t,101)){let r=0;n=e.charCodeAt(t+1),45!==n&&43!==n||(r=1,n=e.charCodeAt(t+2)),te(n)&&(t=Se(e,t+1+r+1))}return t}function Ce(e,t){for(;t<e.length;t++){const n=e.charCodeAt(t);if(41===n){t++;break}ce(n,_e(e,t+1))&&(t=Oe(e,t))}return t}function Pe(e){if(1===e.length&&!ne(e.charCodeAt(0)))return e[0];let t=parseInt(e,16);return(0===t||t>=55296&&t<=57343||t>1114111)&&(t=65533),String.fromCodePoint(t)}var Le=["EOF-token","ident-token","function-token","at-keyword-token","hash-token","string-token","bad-string-token","url-token","bad-url-token","delim-token","number-token","percentage-token","dimension-token","whitespace-token","CDO-token","CDC-token","colon-token","semicolon-token","comma-token","[-token","]-token","(-token",")-token","{-token","}-token","comment-token"];const ze=16384;function Ne(e=null,t){return null===e||e.length<t?new Uint32Array(Math.max(t+1024,ze)):e}function Te(e){const t=e.source,n=t.length,r=t.length>0?he(t.charCodeAt(0)):0,o=Ne(e.lines,n),i=Ne(e.columns,n);let a=e.startLine,s=e.startColumn;for(let e=r;e<n;e++){const r=t.charCodeAt(e);o[e]=a,i[e]=s++,10!==r&&13!==r&&12!==r||(13===r&&e+1<n&&10===t.charCodeAt(e+1)&&(e++,o[e]=a,i[e]=s),a++,s=1)}o[n]=a,i[n]=s,e.lines=o,e.columns=i,e.computed=!0}class je{constructor(e,t,n,r){this.setSource(e,t,n,r),this.lines=null,this.columns=null}setSource(e="",t=0,n=1,r=1){this.source=e,this.startOffset=t,this.startLine=n,this.startColumn=r,this.computed=!1}getLocation(e,t){return this.computed||Te(this),{source:t,offset:this.startOffset+e,line:this.lines[e],column:this.columns[e]}}getLocationRange(e,t,n){return this.computed||Te(this),{source:n,start:{offset:this.startOffset+e,line:this.lines[e],column:this.columns[e]},end:{offset:this.startOffset+t,line:this.lines[t],column:this.columns[t]}}}}const Ie=16777215,Re=24,De=new Uint8Array(32);function Me(e){return 0!==De[e]}De[L]=K,De[Z]=K,De[q]=H,De[G]=X;class Be{constructor(e,t){this.setSource(e,t)}reset(){this.eof=!1,this.tokenIndex=-1,this.tokenType=0,this.tokenStart=this.firstCharOffset,this.tokenEnd=this.firstCharOffset}setSource(e="",t=(()=>{})){const n=(e=String(e||"")).length,r=Ne(this.offsetAndType,e.length+1),o=Ne(this.balance,e.length+1);let i=0,a=-1,s=0,l=e.length;this.offsetAndType=null,this.balance=null,o.fill(0),t(e,((e,t,n)=>{const c=i++;if(r[c]=e<<Re|n,-1===a&&(a=t),o[c]=l,e===s){const e=o[l];o[l]=c,l=e,s=De[r[e]>>Re]}else Me(e)&&(l=c,s=De[e])})),r[i]=0|n,o[i]=i;for(let e=0;e<i;e++){const t=o[e];if(t<=e){const n=o[t];n!==e&&(o[e]=n)}else t>i&&(o[e]=i)}this.source=e,this.firstCharOffset=-1===a?0:a,this.tokenCount=i,this.offsetAndType=r,this.balance=o,this.reset(),this.next()}lookupType(e){return(e+=this.tokenIndex)<this.tokenCount?this.offsetAndType[e]>>Re:0}lookupTypeNonSC(e){for(let t=this.tokenIndex;t<this.tokenCount;t++){const n=this.offsetAndType[t]>>Re;if(n!==J&&n!==Q&&0==e--)return n}return 0}lookupOffset(e){return(e+=this.tokenIndex)<this.tokenCount?this.offsetAndType[e-1]&Ie:this.source.length}lookupOffsetNonSC(e){for(let t=this.tokenIndex;t<this.tokenCount;t++){const n=this.offsetAndType[t]>>Re;if(n!==J&&n!==Q&&0==e--)return t-this.tokenIndex}return 0}lookupValue(e,t){return(e+=this.tokenIndex)<this.tokenCount&&ke(this.source,this.offsetAndType[e-1]&Ie,this.offsetAndType[e]&Ie,t)}getTokenStart(e){return e===this.tokenIndex?this.tokenStart:e>0?e<this.tokenCount?this.offsetAndType[e-1]&Ie:this.offsetAndType[this.tokenCount]&Ie:this.firstCharOffset}substrToCursor(e){return this.source.substring(e,this.tokenStart)}isBalanceEdge(e){return this.balance[this.tokenIndex]<e}isDelim(e,t){return t?this.lookupType(t)===D&&this.source.charCodeAt(this.lookupOffset(t))===e:this.tokenType===D&&this.source.charCodeAt(this.tokenStart)===e}skip(e){let t=this.tokenIndex+e;t<this.tokenCount?(this.tokenIndex=t,this.tokenStart=this.offsetAndType[t-1]&Ie,t=this.offsetAndType[t],this.tokenType=t>>Re,this.tokenEnd=t&Ie):(this.tokenIndex=this.tokenCount,this.next())}next(){let e=this.tokenIndex+1;e<this.tokenCount?(this.tokenIndex=e,this.tokenStart=this.tokenEnd,e=this.offsetAndType[e],this.tokenType=e>>Re,this.tokenEnd=e&Ie):(this.eof=!0,this.tokenIndex=this.tokenCount,this.tokenType=0,this.tokenStart=this.tokenEnd=this.source.length)}skipSC(){for(;this.tokenType===J||this.tokenType===Q;)this.next()}skipUntilBalanced(e,t){let n=e,r=0,o=0;e:for(;n<this.tokenCount&&(r=this.balance[n],!(r<e));n++)switch(o=n>0?this.offsetAndType[n-1]&Ie:this.firstCharOffset,t(this.source.charCodeAt(o))){case 1:break e;case 2:n++;break e;default:Me(this.offsetAndType[n]>>Re)&&(n=r)}this.skip(n-this.tokenIndex)}forEachToken(e){for(let t=0,n=this.firstCharOffset;t<this.tokenCount;t++){const r=n,o=this.offsetAndType[t],i=o&Ie;n=i,e(o>>Re,r,i,t)}}dump(){const e=new Array(this.tokenCount);return this.forEachToken(((t,n,r,o)=>{e[o]={idx:o,type:Le[t],chunk:this.source.substring(n,r),balance:this.balance[o]}})),e}}function We(e,t){function n(t){return t<a?e.charCodeAt(t):0}function r(){return c=Ee(e,c),ue(n(c),n(c+1),n(c+2))?(s=W,void(c=Ae(e,c))):37===n(c)?(s=B,void c++):void(s=M)}function o(){const t=c;return c=Ae(e,c),ke(e,t,c,"url")&&40===n(c)?(c=xe(e,c+1),34===n(c)||39===n(c)?(s=L,void(c=t+4)):void function(){for(s=I,c=xe(e,c);c<e.length;c++){const t=e.charCodeAt(c);switch(be(t)){case 41:return void c++;case fe:return c=xe(e,c),41===n(c)||c>=e.length?void(c<e.length&&c++):(c=Ce(e,c),void(s=R));case 34:case 39:case 40:case ye:return c=Ce(e,c),void(s=R);case 92:if(ce(t,n(c+1))){c=Oe(e,c)-1;break}return c=Ce(e,c),void(s=R)}}}()):40===n(c)?(s=L,void c++):void(s=P)}function i(t){for(t||(t=n(c++)),s=T;c<e.length;c++){const r=e.charCodeAt(c);switch(be(r)){case t:return void c++;case fe:if(se(r))return c+=ve(e,c,r),void(s=j);break;case 92:if(c===e.length-1)break;const o=n(c+1);se(o)?c+=ve(e,c+1,o):ce(r,o)&&(c=Oe(e,c)-1)}}}const a=(e=String(e||"")).length;let s,l=he(n(0)),c=l;for(;c<a;){const a=e.charCodeAt(c);switch(be(a)){case fe:s=J,c=xe(e,c+1);break;case 34:i();break;case 35:ie(n(c+1))||ce(n(c+1),n(c+2))?(s=N,c=Ae(e,c+1)):(s=D,c++);break;case 39:i();break;case 40:s=Z,c++;break;case 41:s=K,c++;break;case 43:de(a,n(c+1),n(c+2))?r():(s=D,c++);break;case 44:s=V,c++;break;case 45:de(a,n(c+1),n(c+2))?r():45===n(c+1)&&62===n(c+2)?(s=Y,c+=3):ue(a,n(c+1),n(c+2))?o():(s=D,c++);break;case 46:de(a,n(c+1),n(c+2))?r():(s=D,c++);break;case 47:42===n(c+1)?(s=Q,c=e.indexOf("*/",c+2),c=-1===c?e.length:c+2):(s=D,c++);break;case 58:s=U,c++;break;case 59:s=$,c++;break;case 60:33===n(c+1)&&45===n(c+2)&&45===n(c+3)?(s=F,c+=4):(s=D,c++);break;case 64:ue(n(c+1),n(c+2),n(c+3))?(s=z,c=Ae(e,c+1)):(s=D,c++);break;case 91:s=q,c++;break;case 92:ce(a,n(c+1))?o():(s=D,c++);break;case 93:s=H,c++;break;case 123:s=G,c++;break;case 125:s=X,c++;break;case me:r();break;case ge:o();break;default:s=D,c++}t(s,l,l=c)}}let Je=null;class Fe{static createItem(e){return{prev:null,next:null,data:e}}constructor(){this.head=null,this.tail=null,this.cursor=null}createItem(e){return Fe.createItem(e)}allocateCursor(e,t){let n;return null!==Je?(n=Je,Je=Je.cursor,n.prev=e,n.next=t,n.cursor=this.cursor):n={prev:e,next:t,cursor:this.cursor},this.cursor=n,n}releaseCursor(){const{cursor:e}=this;this.cursor=e.cursor,e.prev=null,e.next=null,e.cursor=Je,Je=e}updateCursors(e,t,n,r){let{cursor:o}=this;for(;null!==o;)o.prev===e&&(o.prev=t),o.next===n&&(o.next=r),o=o.cursor}*[Symbol.iterator](){for(let e=this.head;null!==e;e=e.next)yield e.data}get size(){let e=0;for(let t=this.head;null!==t;t=t.next)e++;return e}get isEmpty(){return null===this.head}get first(){return this.head&&this.head.data}get last(){return this.tail&&this.tail.data}fromArray(e){let t=null;this.head=null;for(let n of e){const e=Fe.createItem(n);null!==t?t.next=e:this.head=e,e.prev=t,t=e}return this.tail=t,this}toArray(){return[...this]}toJSON(){return[...this]}forEach(e,t=this){const n=this.allocateCursor(null,this.head);for(;null!==n.next;){const r=n.next;n.next=r.next,e.call(t,r.data,r,this)}this.releaseCursor()}forEachRight(e,t=this){const n=this.allocateCursor(this.tail,null);for(;null!==n.prev;){const r=n.prev;n.prev=r.prev,e.call(t,r.data,r,this)}this.releaseCursor()}reduce(e,t,n=this){let r,o=this.allocateCursor(null,this.head),i=t;for(;null!==o.next;)r=o.next,o.next=r.next,i=e.call(n,i,r.data,r,this);return this.releaseCursor(),i}reduceRight(e,t,n=this){let r,o=this.allocateCursor(this.tail,null),i=t;for(;null!==o.prev;)r=o.prev,o.prev=r.prev,i=e.call(n,i,r.data,r,this);return this.releaseCursor(),i}some(e,t=this){for(let n=this.head;null!==n;n=n.next)if(e.call(t,n.data,n,this))return!0;return!1}map(e,t=this){const n=new Fe;for(let r=this.head;null!==r;r=r.next)n.appendData(e.call(t,r.data,r,this));return n}filter(e,t=this){const n=new Fe;for(let r=this.head;null!==r;r=r.next)e.call(t,r.data,r,this)&&n.appendData(r.data);return n}nextUntil(e,t,n=this){if(null===e)return;const r=this.allocateCursor(null,e);for(;null!==r.next;){const e=r.next;if(r.next=e.next,t.call(n,e.data,e,this))break}this.releaseCursor()}prevUntil(e,t,n=this){if(null===e)return;const r=this.allocateCursor(e,null);for(;null!==r.prev;){const e=r.prev;if(r.prev=e.prev,t.call(n,e.data,e,this))break}this.releaseCursor()}clear(){this.head=null,this.tail=null}copy(){const e=new Fe;for(let t of this)e.appendData(t);return e}prepend(e){return this.updateCursors(null,e,this.head,e),null!==this.head?(this.head.prev=e,e.next=this.head):this.tail=e,this.head=e,this}prependData(e){return this.prepend(Fe.createItem(e))}append(e){return this.insert(e)}appendData(e){return this.insert(Fe.createItem(e))}insert(e,t=null){if(null!==t)if(this.updateCursors(t.prev,e,t,e),null===t.prev){if(this.head!==t)throw new Error("before doesn't belong to list");this.head=e,t.prev=e,e.next=t,this.updateCursors(null,e)}else t.prev.next=e,e.prev=t.prev,t.prev=e,e.next=t;else this.updateCursors(this.tail,e,null,e),null!==this.tail?(this.tail.next=e,e.prev=this.tail):this.head=e,this.tail=e;return this}insertData(e,t){return this.insert(Fe.createItem(e),t)}remove(e){if(this.updateCursors(e,e.prev,e,e.next),null!==e.prev)e.prev.next=e.next;else{if(this.head!==e)throw new Error("item doesn't belong to list");this.head=e.next}if(null!==e.next)e.next.prev=e.prev;else{if(this.tail!==e)throw new Error("item doesn't belong to list");this.tail=e.prev}return e.prev=null,e.next=null,e}push(e){this.insert(Fe.createItem(e))}pop(){return null!==this.tail?this.remove(this.tail):null}unshift(e){this.prepend(Fe.createItem(e))}shift(){return null!==this.head?this.remove(this.head):null}prependList(e){return this.insertList(e,this.head)}appendList(e){return this.insertList(e)}insertList(e,t){return null===e.head||(null!=t?(this.updateCursors(t.prev,e.tail,t,e.head),null!==t.prev?(t.prev.next=e.head,e.head.prev=t.prev):this.head=e.head,t.prev=e.tail,e.tail.next=t):(this.updateCursors(this.tail,e.tail,null,e.head),null!==this.tail?(this.tail.next=e.head,e.head.prev=this.tail):this.head=e.head,this.tail=e.tail),e.head=null,e.tail=null),this}replace(e,t){"head"in t?this.insertList(t,e):this.insert(t,e),this.remove(e)}}function Ye(e,t){const n=Object.create(SyntaxError.prototype),r=new Error;return Object.assign(n,{name:e,message:t,get stack(){return(r.stack||"").replace(/^(.+\n){1,3}/,`${e}: ${t}\n`)}})}const Ue=100,$e=60,Ve="    ";function qe({source:e,line:t,column:n,baseLine:r,baseColumn:o},i){function a(e,t){return s.slice(e,t).map(((t,n)=>String(e+n+1).padStart(u)+" |"+t)).join("\n")}const s=("\n".repeat(Math.max(r-1,0))+" ".repeat(Math.max(o-1,0))+e).split(/\r\n?|\n|\f/),l=Math.max(1,t-i)-1,c=Math.min(t+i,s.length+1),u=Math.max(4,String(c).length)+1;let d=0;(n+=(Ve.length-1)*(s[t-1].substr(0,n-1).match(/\t/g)||[]).length)>Ue&&(d=n-$e+3,n=$e-2);for(let e=l;e<=c;e++)e>=0&&e<s.length&&(s[e]=s[e].replace(/\t/g,Ve),s[e]=(d>0&&s[e].length>d?"…":"")+s[e].substr(d,Ue-2)+(s[e].length>d+Ue-1?"…":""));return[a(l,t),new Array(n+u+2).join("-")+"^",a(t,c)].filter(Boolean).join("\n").replace(/^(\s+\d+\s+\|\n)+/,"").replace(/\n(\s+\d+\s+\|)+$/,"")}function He(e,t,n,r,o,i=1,a=1){return Object.assign(Ye("SyntaxError",e),{source:t,offset:n,line:r,column:o,sourceFragment:e=>qe({source:t,line:r,column:o,baseLine:i,baseColumn:a},isNaN(e)?0:e),get formattedMessage(){return`Parse error: ${e}\n`+qe({source:t,line:r,column:o,baseLine:i,baseColumn:a},2)}})}function Ze(e){const t=this.createList();let n=!1;const r={recognizer:e};for(;!this.eof;){switch(this.tokenType){case Q:this.next();continue;case J:n=!0,this.next();continue}let o=e.getNode.call(this,r);if(void 0===o)break;n&&(e.onWhiteSpace&&e.onWhiteSpace.call(this,o,t,r),n=!1),t.push(o)}return n&&e.onWhiteSpace&&e.onWhiteSpace.call(this,null,t,r),t}const Ke=()=>{},Ge=33,Xe=35,Qe=59,et=123,tt=0;function nt(e){return function(){return this[e]()}}function rt(e){const t=Object.create(null);for(const n of Object.keys(e)){const r=e[n],o=r.parse||r;o&&(t[n]=o)}return t}var ot={},it={},at="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");it.encode=function(e){if(0<=e&&e<at.length)return at[e];throw new TypeError("Must be between 0 and 63: "+e)},it.decode=function(e){return 65<=e&&e<=90?e-65:97<=e&&e<=122?e-97+26:48<=e&&e<=57?e-48+52:43==e?62:47==e?63:-1};var st=it;ot.encode=function(e){var t,n="",r=function(e){return e<0?1+(-e<<1):0+(e<<1)}(e);do{t=31&r,(r>>>=5)>0&&(t|=32),n+=st.encode(t)}while(r>0);return n},ot.decode=function(e,t,n){var r,o,i,a,s=e.length,l=0,c=0;do{if(t>=s)throw new Error("Expected more digits in base 64 VLQ value.");if(-1===(o=st.decode(e.charCodeAt(t++))))throw new Error("Invalid base64 digit: "+e.charAt(t-1));r=!!(32&o),l+=(o&=31)<<c,c+=5}while(r);n.value=(a=(i=l)>>1,1==(1&i)?-a:a),n.rest=t};var lt={};!function(e){e.getArg=function(e,t,n){if(t in e)return e[t];if(3===arguments.length)return n;throw new Error('"'+t+'" is a required argument.')};var t=/^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/,n=/^data:.+\,.+$/;function r(e){var n=e.match(t);return n?{scheme:n[1],auth:n[2],host:n[3],port:n[4],path:n[5]}:null}function o(e){var t="";return e.scheme&&(t+=e.scheme+":"),t+="//",e.auth&&(t+=e.auth+"@"),e.host&&(t+=e.host),e.port&&(t+=":"+e.port),e.path&&(t+=e.path),t}e.urlParse=r,e.urlGenerate=o;var i,a,s=(i=function(t){var n=t,i=r(t);if(i){if(!i.path)return t;n=i.path}for(var a=e.isAbsolute(n),s=[],l=0,c=0;;){if(l=c,-1===(c=n.indexOf("/",l))){s.push(n.slice(l));break}for(s.push(n.slice(l,c));c<n.length&&"/"===n[c];)c++}var u,d=0;for(c=s.length-1;c>=0;c--)"."===(u=s[c])?s.splice(c,1):".."===u?d++:d>0&&(""===u?(s.splice(c+1,d),d=0):(s.splice(c,2),d--));return""===(n=s.join("/"))&&(n=a?"/":"."),i?(i.path=n,o(i)):n},a=[],function(e){for(var t=0;t<a.length;t++)if(a[t].input===e){var n=a[0];return a[0]=a[t],a[t]=n,a[0].result}var r=i(e);return a.unshift({input:e,result:r}),a.length>32&&a.pop(),r});function l(e,t){""===e&&(e="."),""===t&&(t=".");var i=r(t),a=r(e);if(a&&(e=a.path||"/"),i&&!i.scheme)return a&&(i.scheme=a.scheme),o(i);if(i||t.match(n))return t;if(a&&!a.host&&!a.path)return a.host=t,o(a);var l="/"===t.charAt(0)?t:s(e.replace(/\/+$/,"")+"/"+t);return a?(a.path=l,o(a)):l}e.normalize=s,e.join=l,e.isAbsolute=function(e){return"/"===e.charAt(0)||t.test(e)},e.relative=function(e,t){""===e&&(e="."),e=e.replace(/\/$/,"");for(var n=0;0!==t.indexOf(e+"/");){var r=e.lastIndexOf("/");if(r<0)return t;if((e=e.slice(0,r)).match(/^([^\/]+:\/)?\/*$/))return t;++n}return Array(n+1).join("../")+t.substr(e.length+1)};var c=!("__proto__"in Object.create(null));function u(e){return e}function d(e){if(!e)return!1;var t=e.length;if(t<9)return!1;if(95!==e.charCodeAt(t-1)||95!==e.charCodeAt(t-2)||111!==e.charCodeAt(t-3)||116!==e.charCodeAt(t-4)||111!==e.charCodeAt(t-5)||114!==e.charCodeAt(t-6)||112!==e.charCodeAt(t-7)||95!==e.charCodeAt(t-8)||95!==e.charCodeAt(t-9))return!1;for(var n=t-10;n>=0;n--)if(36!==e.charCodeAt(n))return!1;return!0}function h(e,t){return e===t?0:null===e?1:null===t?-1:e>t?1:-1}e.toSetString=c?u:function(e){return d(e)?"$"+e:e},e.fromSetString=c?u:function(e){return d(e)?e.slice(1):e},e.compareByOriginalPositions=function(e,t,n){var r=h(e.source,t.source);return 0!==r||0!=(r=e.originalLine-t.originalLine)||0!=(r=e.originalColumn-t.originalColumn)||n||0!=(r=e.generatedColumn-t.generatedColumn)||0!=(r=e.generatedLine-t.generatedLine)?r:h(e.name,t.name)},e.compareByOriginalPositionsNoSource=function(e,t,n){var r;return 0!=(r=e.originalLine-t.originalLine)||0!=(r=e.originalColumn-t.originalColumn)||n||0!=(r=e.generatedColumn-t.generatedColumn)||0!=(r=e.generatedLine-t.generatedLine)?r:h(e.name,t.name)},e.compareByGeneratedPositionsDeflated=function(e,t,n){var r=e.generatedLine-t.generatedLine;return 0!==r||0!=(r=e.generatedColumn-t.generatedColumn)||n||0!==(r=h(e.source,t.source))||0!=(r=e.originalLine-t.originalLine)||0!=(r=e.originalColumn-t.originalColumn)?r:h(e.name,t.name)},e.compareByGeneratedPositionsDeflatedNoLine=function(e,t,n){var r=e.generatedColumn-t.generatedColumn;return 0!==r||n||0!==(r=h(e.source,t.source))||0!=(r=e.originalLine-t.originalLine)||0!=(r=e.originalColumn-t.originalColumn)?r:h(e.name,t.name)},e.compareByGeneratedPositionsInflated=function(e,t){var n=e.generatedLine-t.generatedLine;return 0!==n||0!=(n=e.generatedColumn-t.generatedColumn)||0!==(n=h(e.source,t.source))||0!=(n=e.originalLine-t.originalLine)||0!=(n=e.originalColumn-t.originalColumn)?n:h(e.name,t.name)},e.parseSourceMapInput=function(e){return JSON.parse(e.replace(/^\)]}'[^\n]*\n/,""))},e.computeSourceURL=function(e,t,n){if(t=t||"",e&&("/"!==e[e.length-1]&&"/"!==t[0]&&(e+="/"),t=e+t),n){var i=r(n);if(!i)throw new Error("sourceMapURL could not be parsed");if(i.path){var a=i.path.lastIndexOf("/");a>=0&&(i.path=i.path.substring(0,a+1))}t=l(o(i),t)}return s(t)}}(lt);var ct={},ut=lt,dt=Object.prototype.hasOwnProperty,ht="undefined"!=typeof Map;function pt(){this._array=[],this._set=ht?new Map:Object.create(null)}pt.fromArray=function(e,t){for(var n=new pt,r=0,o=e.length;r<o;r++)n.add(e[r],t);return n},pt.prototype.size=function(){return ht?this._set.size:Object.getOwnPropertyNames(this._set).length},pt.prototype.add=function(e,t){var n=ht?e:ut.toSetString(e),r=ht?this.has(e):dt.call(this._set,n),o=this._array.length;r&&!t||this._array.push(e),r||(ht?this._set.set(e,o):this._set[n]=o)},pt.prototype.has=function(e){if(ht)return this._set.has(e);var t=ut.toSetString(e);return dt.call(this._set,t)},pt.prototype.indexOf=function(e){if(ht){var t=this._set.get(e);if(t>=0)return t}else{var n=ut.toSetString(e);if(dt.call(this._set,n))return this._set[n]}throw new Error('"'+e+'" is not in the set.')},pt.prototype.at=function(e){if(e>=0&&e<this._array.length)return this._array[e];throw new Error("No element indexed by "+e)},pt.prototype.toArray=function(){return this._array.slice()},ct.ArraySet=pt;var ft={},mt=lt;function gt(){this._array=[],this._sorted=!0,this._last={generatedLine:-1,generatedColumn:0}}gt.prototype.unsortedForEach=function(e,t){this._array.forEach(e,t)},gt.prototype.add=function(e){var t,n,r,o,i,a;n=e,r=(t=this._last).generatedLine,o=n.generatedLine,i=t.generatedColumn,a=n.generatedColumn,o>r||o==r&&a>=i||mt.compareByGeneratedPositionsInflated(t,n)<=0?(this._last=e,this._array.push(e)):(this._sorted=!1,this._array.push(e))},gt.prototype.toArray=function(){return this._sorted||(this._array.sort(mt.compareByGeneratedPositionsInflated),this._sorted=!0),this._array},ft.MappingList=gt;var yt=ot,bt=lt,_t=ct.ArraySet,vt=ft.MappingList;function wt(e){e||(e={}),this._file=bt.getArg(e,"file",null),this._sourceRoot=bt.getArg(e,"sourceRoot",null),this._skipValidation=bt.getArg(e,"skipValidation",!1),this._ignoreInvalidMapping=bt.getArg(e,"ignoreInvalidMapping",!1),this._sources=new _t,this._names=new _t,this._mappings=new vt,this._sourcesContents=null}wt.prototype._version=3,wt.fromSourceMap=function(e,t){var n=e.sourceRoot,r=new wt(Object.assign(t||{},{file:e.file,sourceRoot:n}));return e.eachMapping((function(e){var t={generated:{line:e.generatedLine,column:e.generatedColumn}};null!=e.source&&(t.source=e.source,null!=n&&(t.source=bt.relative(n,t.source)),t.original={line:e.originalLine,column:e.originalColumn},null!=e.name&&(t.name=e.name)),r.addMapping(t)})),e.sources.forEach((function(t){var o=t;null!==n&&(o=bt.relative(n,t)),r._sources.has(o)||r._sources.add(o);var i=e.sourceContentFor(t);null!=i&&r.setSourceContent(t,i)})),r},wt.prototype.addMapping=function(e){var t=bt.getArg(e,"generated"),n=bt.getArg(e,"original",null),r=bt.getArg(e,"source",null),o=bt.getArg(e,"name",null);(this._skipValidation||!1!==this._validateMapping(t,n,r,o))&&(null!=r&&(r=String(r),this._sources.has(r)||this._sources.add(r)),null!=o&&(o=String(o),this._names.has(o)||this._names.add(o)),this._mappings.add({generatedLine:t.line,generatedColumn:t.column,originalLine:null!=n&&n.line,originalColumn:null!=n&&n.column,source:r,name:o}))},wt.prototype.setSourceContent=function(e,t){var n=e;null!=this._sourceRoot&&(n=bt.relative(this._sourceRoot,n)),null!=t?(this._sourcesContents||(this._sourcesContents=Object.create(null)),this._sourcesContents[bt.toSetString(n)]=t):this._sourcesContents&&(delete this._sourcesContents[bt.toSetString(n)],0===Object.keys(this._sourcesContents).length&&(this._sourcesContents=null))},wt.prototype.applySourceMap=function(e,t,n){var r=t;if(null==t){if(null==e.file)throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map\'s "file" property. Both were omitted.');r=e.file}var o=this._sourceRoot;null!=o&&(r=bt.relative(o,r));var i=new _t,a=new _t;this._mappings.unsortedForEach((function(t){if(t.source===r&&null!=t.originalLine){var s=e.originalPositionFor({line:t.originalLine,column:t.originalColumn});null!=s.source&&(t.source=s.source,null!=n&&(t.source=bt.join(n,t.source)),null!=o&&(t.source=bt.relative(o,t.source)),t.originalLine=s.line,t.originalColumn=s.column,null!=s.name&&(t.name=s.name))}var l=t.source;null==l||i.has(l)||i.add(l);var c=t.name;null==c||a.has(c)||a.add(c)}),this),this._sources=i,this._names=a,e.sources.forEach((function(t){var r=e.sourceContentFor(t);null!=r&&(null!=n&&(t=bt.join(n,t)),null!=o&&(t=bt.relative(o,t)),this.setSourceContent(t,r))}),this)},wt.prototype._validateMapping=function(e,t,n,r){if(t&&"number"!=typeof t.line&&"number"!=typeof t.column){var o="original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.";if(this._ignoreInvalidMapping)return"undefined"!=typeof console&&console.warn&&console.warn(o),!1;throw new Error(o)}if((!(e&&"line"in e&&"column"in e&&e.line>0&&e.column>=0)||t||n||r)&&!(e&&"line"in e&&"column"in e&&t&&"line"in t&&"column"in t&&e.line>0&&e.column>=0&&t.line>0&&t.column>=0&&n)){if(o="Invalid mapping: "+JSON.stringify({generated:e,source:n,original:t,name:r}),this._ignoreInvalidMapping)return"undefined"!=typeof console&&console.warn&&console.warn(o),!1;throw new Error(o)}},wt.prototype._serializeMappings=function(){for(var e,t,n,r,o=0,i=1,a=0,s=0,l=0,c=0,u="",d=this._mappings.toArray(),h=0,p=d.length;h<p;h++){if(e="",(t=d[h]).generatedLine!==i)for(o=0;t.generatedLine!==i;)e+=";",i++;else if(h>0){if(!bt.compareByGeneratedPositionsInflated(t,d[h-1]))continue;e+=","}e+=yt.encode(t.generatedColumn-o),o=t.generatedColumn,null!=t.source&&(r=this._sources.indexOf(t.source),e+=yt.encode(r-c),c=r,e+=yt.encode(t.originalLine-1-s),s=t.originalLine-1,e+=yt.encode(t.originalColumn-a),a=t.originalColumn,null!=t.name&&(n=this._names.indexOf(t.name),e+=yt.encode(n-l),l=n)),u+=e}return u},wt.prototype._generateSourcesContent=function(e,t){return e.map((function(e){if(!this._sourcesContents)return null;null!=t&&(e=bt.relative(t,e));var n=bt.toSetString(e);return Object.prototype.hasOwnProperty.call(this._sourcesContents,n)?this._sourcesContents[n]:null}),this)},wt.prototype.toJSON=function(){var e={version:this._version,sources:this._sources.toArray(),names:this._names.toArray(),mappings:this._serializeMappings()};return null!=this._file&&(e.file=this._file),null!=this._sourceRoot&&(e.sourceRoot=this._sourceRoot),this._sourcesContents&&(e.sourcesContent=this._generateSourcesContent(e.sources,e.sourceRoot)),e},wt.prototype.toString=function(){return JSON.stringify(this.toJSON())};var kt=wt;const xt=new Set(["Atrule","Selector","Declaration"]),St=(e,t)=>{if(e===D&&(e=t),"string"==typeof e){const t=e.charCodeAt(0);return t>127?32768:t<<8}return e},Ot=[[P,P],[P,L],[P,I],[P,R],[P,"-"],[P,M],[P,B],[P,W],[P,Y],[P,Z],[z,P],[z,L],[z,I],[z,R],[z,"-"],[z,M],[z,B],[z,W],[z,Y],[N,P],[N,L],[N,I],[N,R],[N,"-"],[N,M],[N,B],[N,W],[N,Y],[W,P],[W,L],[W,I],[W,R],[W,"-"],[W,M],[W,B],[W,W],[W,Y],["#",P],["#",L],["#",I],["#",R],["#","-"],["#",M],["#",B],["#",W],["#",Y],["-",P],["-",L],["-",I],["-",R],["-","-"],["-",M],["-",B],["-",W],["-",Y],[M,P],[M,L],[M,I],[M,R],[M,M],[M,B],[M,W],[M,"%"],[M,Y],["@",P],["@",L],["@",I],["@",R],["@","-"],["@",Y],[".",M],[".",B],[".",W],["+",M],["+",B],["+",W],["/","*"]],At=Ot.concat([[P,N],[W,N],[N,N],[z,Z],[z,T],[z,U],[B,B],[B,W],[B,L],[B,"-"],[K,P],[K,L],[K,B],[K,W],[K,N],[K,"-"]]);function Et(e){const t=new Set(e.map((([e,t])=>St(e)<<16|St(t))));return function(e,n,r){const o=St(n,r),i=r.charCodeAt(0);return(45===i&&n!==P&&n!==L&&n!==Y||43===i?t.has(e<<16|i<<8):t.has(e<<16|o))&&this.emit(" ",J,!0),o}}const Ct=Et(Ot),Pt=Et(At);var Lt=Object.freeze({__proto__:null,safe:Pt,spec:Ct});const zt=92;function Nt(e,t){if("function"!=typeof t)e.children.forEach(this.node,this);else{let n=null;e.children.forEach((e=>{null!==n&&t.call(this,n),this.node(e),n=e}))}}function Tt(e){We(e,((t,n,r)=>{this.token(t,e.slice(n,r))}))}const{hasOwnProperty:jt}=Object.prototype,It=function(){};function Rt(e){return"function"==typeof e?e:It}function Dt(e,t){return function(n,r,o){n.type===t&&e.call(this,n,r,o)}}function Mt(e,t){const n=t.structure,r=[];for(const e in n){if(!1===jt.call(n,e))continue;let t=n[e];const o={name:e,type:!1,nullable:!1};Array.isArray(t)||(t=[t]);for(const e of t)null===e?o.nullable=!0:"string"==typeof e?o.type="node":Array.isArray(e)&&(o.type="list");o.type&&r.push(o)}return r.length?{context:t.walkContext,fields:r}:null}function Bt(e,t){const n=e.fields.slice(),r=e.context,o="string"==typeof r;return t&&n.reverse(),function(e,i,a,s){let l;o&&(l=i[r],i[r]=e);for(const r of n){const n=e[r.name];if(!r.nullable||n)if("list"===r.type){if(t?n.reduceRight(s,!1):n.reduce(s,!1))return!0}else if(a(n))return!0}o&&(i[r]=l)}}function Wt({StyleSheet:e,Atrule:t,Rule:n,Block:r,DeclarationList:o}){return{Atrule:{StyleSheet:e,Atrule:t,Rule:n,Block:r},Rule:{StyleSheet:e,Atrule:t,Rule:n,Block:r},Declaration:{StyleSheet:e,Atrule:t,Rule:n,Block:r,DeclarationList:o}}}function Jt(e){return e}function Ft(e,t,n,r){let o;switch(e.type){case"Group":o=function(e,t,n,r){const o=" "===e.combinator||r?e.combinator:" "+e.combinator+" ",i=e.terms.map((e=>Ft(e,t,n,r))).join(o);return e.explicit||n?(r||","===i[0]?"[":"[ ")+i+(r?"]":" ]"):i}(e,t,n,r)+(e.disallowEmpty?"!":"");break;case"Multiplier":return Ft(e.term,t,n,r)+t(function(e){const{min:t,max:n,comma:r}=e;return 0===t&&0===n?r?"#?":"*":0===t&&1===n?"?":1===t&&0===n?r?"#":"+":1===t&&1===n?"":(r?"#":"")+(t===n?"{"+t+"}":"{"+t+","+(0!==n?n:"")+"}")}(e),e);case"Boolean":o="<boolean-expr["+Ft(e.term,t,n,r)+"]>";break;case"Type":o="<"+e.name+(e.opts?t(function(e){if("Range"===e.type)return" ["+(null===e.min?"-∞":e.min)+","+(null===e.max?"∞":e.max)+"]";throw new Error("Unknown node type `"+e.type+"`")}(e.opts),e.opts):"")+">";break;case"Property":o="<'"+e.name+"'>";break;case"Keyword":o=e.name;break;case"AtKeyword":o="@"+e.name;break;case"Function":o=e.name+"(";break;case"String":case"Token":o=e.value;break;case"Comma":o=",";break;default:throw new Error("Unknown node type `"+e.type+"`")}return t(o,e)}function Yt(e,t){let n=Jt,r=!1,o=!1;return"function"==typeof t?n=t:t&&(r=Boolean(t.forceBraces),o=Boolean(t.compact),"function"==typeof t.decorate&&(n=t.decorate)),Ft(e,n,r,o)}const Ut={offset:0,line:1,column:1};function $t(e,t){const n=e&&e.loc&&e.loc[t];return n?"line"in n?Vt(n):n:null}function Vt({offset:e,line:t,column:n},r){const o={offset:e,line:t,column:n};if(r){const e=r.split(/\n|\r\n?|\f/);o.offset+=r.length,o.line+=e.length-1,o.column=1===e.length?o.column+r.length:e.pop().length+1}return o}const qt=function(e,t){const n=Ye("SyntaxReferenceError",e+(t?" `"+t+"`":""));return n.reference=t,n},Ht=function(e,t,n,r){const o=Ye("SyntaxMatchError",e),{css:i,mismatchOffset:a,mismatchLength:s,start:l,end:c}=function(e,t){const n=e.tokens,r=e.longestMatch,o=r<n.length&&n[r].node||null,i=o!==t?o:null;let a,s,l=0,c=0,u=0,d="";for(let e=0;e<n.length;e++){const t=n[e].value;e===r&&(c=t.length,l=d.length),null!==i&&n[e].node===i&&(e<=r?u++:u=0),d+=t}return r===n.length||u>1?(a=$t(i||t,"end")||Vt(Ut,d),s=Vt(a)):(a=$t(i,"start")||Vt($t(t,"start")||Ut,d.slice(0,l)),s=$t(i,"end")||Vt(a,d.substr(l,c))),{css:d,mismatchOffset:l,mismatchLength:c,start:a,end:s}}(r,n);return o.rawMessage=e,o.syntax=t?Yt(t):"<generic>",o.css=i,o.mismatchOffset=a,o.mismatchLength=s,o.message=e+"\n  syntax: "+o.syntax+"\n   value: "+(i||"<empty string>")+"\n  --------"+new Array(o.mismatchOffset+1).join("-")+"^",Object.assign(o,l),o.loc={source:n&&n.loc&&n.loc.source||"<unknown>",start:l,end:c},o},Zt=new Map,Kt=new Map,Gt=45,Xt=function(e){if(Zt.has(e))return Zt.get(e);const t=e.toLowerCase();let n=Zt.get(t);if(void 0===n){const e=en(t,0),r=e?"":tn(t,0);n=Object.freeze({basename:t.substr(r.length),name:t,prefix:r,vendor:r,custom:e})}return Zt.set(e,n),n},Qt=function(e){if(Kt.has(e))return Kt.get(e);let t=e,n=e[0];"/"===n?n="/"===e[1]?"//":"/":"_"!==n&&"*"!==n&&"$"!==n&&"#"!==n&&"+"!==n&&"&"!==n&&(n="");const r=en(t,n.length);if(!r&&(t=t.toLowerCase(),Kt.has(t))){const n=Kt.get(t);return Kt.set(e,n),n}const o=r?"":tn(t,n.length),i=t.substr(0,n.length+o.length),a=Object.freeze({basename:t.substr(i.length),name:t.substr(n.length),hack:n,vendor:o,prefix:i,custom:r});return Kt.set(e,a),a};function en(e,t){return t=t||0,e.length-t>=2&&e.charCodeAt(t)===Gt&&e.charCodeAt(t+1)===Gt}function tn(e,t){if(t=t||0,e.length-t>=3&&e.charCodeAt(t)===Gt&&e.charCodeAt(t+1)!==Gt){const n=e.indexOf("-",t+2);if(-1!==n)return e.substring(t,n+1)}return""}const nn=["initial","inherit","unset","revert","revert-layer"],rn=43,on=45,an=!0;function sn(e,t){return null!==e&&e.type===D&&e.value.charCodeAt(0)===t}function ln(e,t,n){for(;null!==e&&(e.type===J||e.type===Q);)e=n(++t);return t}function cn(e,t,n,r){if(!e)return 0;const o=e.value.charCodeAt(t);if(o===rn||o===on){if(n)return 0;t++}for(;t<e.value.length;t++)if(!te(e.value.charCodeAt(t)))return 0;return r+1}function un(e,t,n){let r=!1,o=ln(e,t,n);if(null===(e=n(o)))return t;if(e.type!==M){if(!sn(e,rn)&&!sn(e,on))return t;if(r=!0,o=ln(n(++o),o,n),null===(e=n(o))||e.type!==M)return 0}if(!r){const t=e.value.charCodeAt(0);if(t!==rn&&t!==on)return 0}return cn(e,r?0:1,r,o)}function dn(e,t){return null!==e&&e.type===D&&e.value.charCodeAt(0)===t}function hn(e,t,n){let r=0;for(let o=t;o<e.value.length;o++){const i=e.value.charCodeAt(o);if(45===i&&n&&0!==r)return hn(e,t+r+1,!1),6;if(!ne(i))return 0;if(++r>6)return 0}return r}function pn(e,t,n){if(!e)return 0;for(;dn(n(t),63);){if(++e>6)return 0;t++}return t}const fn=["calc(","-moz-calc(","-webkit-calc("],mn=new Map([[L,K],[Z,K],[q,H],[G,X]]);function gn(e,t){return t<e.length?e.charCodeAt(t):0}function yn(e,t){return ke(e,0,e.length,t)}function bn(e,t){for(let n=0;n<t.length;n++)if(yn(e,t[n]))return!0;return!1}function _n(e,t){return t===e.length-2&&92===gn(e,t)&&te(gn(e,t+1))}function vn(e,t,n){if(e&&"Range"===e.type){const r=Number(void 0!==n&&n!==t.length?t.substr(0,n):t);if(isNaN(r))return!0;if(null!==e.min&&r<e.min&&"string"!=typeof e.min)return!0;if(null!==e.max&&r>e.max&&"string"!=typeof e.max)return!0}return!1}function wn(e){return function(t,n,r){return null===t?0:t.type===L&&bn(t.value,fn)?function(e,t){let n=0,r=[],o=0;e:do{switch(e.type){case X:case K:case H:if(e.type!==n)break e;if(n=r.pop(),0===r.length){o++;break e}break;case L:case Z:case q:case G:r.push(n),n=mn.get(e.type)}o++}while(e=t(o));return o}(t,n):e(t,n,r)}}function kn(e){return function(t){return null===t||t.type!==e?0:1}}function xn(e){return null===e||e.type!==P||45!==gn(e.value,0)||45!==gn(e.value,1)?0:1}function Sn(e){return e&&(e=new Set(e)),function(t,n,r){if(null===t||t.type!==W)return 0;const o=Ee(t.value,0);if(null!==e){const n=t.value.indexOf("\\",o),r=-1!==n&&_n(t.value,n)?t.value.substring(o,n):t.value.substr(o);if(!1===e.has(r.toLowerCase()))return 0}return vn(r,t.value,o)?0:1}}function On(e){return"function"!=typeof e&&(e=function(){return 0}),function(t,n,r){return null!==t&&t.type===M&&0===Number(t.value)?1:e(t,n,r)}}const An={"ident-token":kn(P),"function-token":kn(L),"at-keyword-token":kn(z),"hash-token":kn(N),"string-token":kn(T),"bad-string-token":kn(j),"url-token":kn(I),"bad-url-token":kn(R),"delim-token":kn(D),"number-token":kn(M),"percentage-token":kn(B),"dimension-token":kn(W),"whitespace-token":kn(J),"CDO-token":kn(F),"CDC-token":kn(Y),"colon-token":kn(U),"semicolon-token":kn($),"comma-token":kn(V),"[-token":kn(q),"]-token":kn(H),"(-token":kn(Z),")-token":kn(K),"{-token":kn(G),"}-token":kn(X)},En={string:kn(T),ident:kn(P),percentage:wn((function(e,t,n){return null===e||e.type!==B||vn(n,e.value,e.value.length-1)?0:1})),zero:On(),number:wn((function(e,t,n){if(null===e)return 0;const r=Ee(e.value,0);return r===e.value.length||_n(e.value,r)?vn(n,e.value,r)?0:1:0})),integer:wn((function(e,t,n){if(null===e||e.type!==M)return 0;let r=43===gn(e.value,0)||45===gn(e.value,0)?1:0;for(;r<e.value.length;r++)if(!te(gn(e.value,r)))return 0;return vn(n,e.value,r)?0:1})),"custom-ident":function(e){if(null===e||e.type!==P)return 0;const t=e.value.toLowerCase();return bn(t,nn)||yn(t,"default")?0:1},"dashed-ident":xn,"custom-property-name":function(e){return xn(e)?"--"===e.value?0:1:0},"hex-color":function(e){if(null===e||e.type!==N)return 0;const t=e.value.length;if(4!==t&&5!==t&&7!==t&&9!==t)return 0;for(let n=1;n<t;n++)if(!ne(gn(e.value,n)))return 0;return 1},"id-selector":function(e){return null===e||e.type!==N?0:ue(gn(e.value,1),gn(e.value,2),gn(e.value,3))?1:0},"an-plus-b":function(e,t){let n=0;if(!e)return 0;if(e.type===M)return cn(e,0,!1,n);if(e.type===P&&e.value.charCodeAt(0)===on){if(!we(e.value,1,110))return 0;switch(e.value.length){case 2:return un(t(++n),n,t);case 3:return e.value.charCodeAt(2)!==on?0:(n=ln(t(++n),n,t),cn(e=t(n),0,an,n));default:return e.value.charCodeAt(2)!==on?0:cn(e,3,an,n)}}else if(e.type===P||sn(e,rn)&&t(n+1).type===P){if(e.type!==P&&(e=t(++n)),null===e||!we(e.value,0,110))return 0;switch(e.value.length){case 1:return un(t(++n),n,t);case 2:return e.value.charCodeAt(1)!==on?0:(n=ln(t(++n),n,t),cn(e=t(n),0,an,n));default:return e.value.charCodeAt(1)!==on?0:cn(e,2,an,n)}}else if(e.type===W){let r=e.value.charCodeAt(0),o=r===rn||r===on?1:0,i=o;for(;i<e.value.length&&te(e.value.charCodeAt(i));i++);return i===o?0:we(e.value,i,110)?i+1===e.value.length?un(t(++n),n,t):e.value.charCodeAt(i+1)!==on?0:i+2===e.value.length?(n=ln(t(++n),n,t),cn(e=t(n),0,an,n)):cn(e,i+2,an,n):0}return 0},urange:function(e,t){let n=0;if(null===e||e.type!==P||!we(e.value,0,117))return 0;if(null===(e=t(++n)))return 0;if(dn(e,43))return null===(e=t(++n))?0:e.type===P?pn(hn(e,0,!0),++n,t):dn(e,63)?pn(1,++n,t):0;if(e.type===M){const r=hn(e,1,!0);return 0===r?0:null===(e=t(++n))?n:e.type===W||e.type===M?function(e,t){return 45===e.value.charCodeAt(0)}(e)&&hn(e,1,!1)?n+1:0:pn(r,n,t)}return e.type===W?pn(hn(e,1,!0),++n,t):0},"declaration-value":function(e,t){if(!e)return 0;let n=0,r=[],o=0;e:do{switch(e.type){case j:case R:break e;case X:case K:case H:if(e.type!==n)break e;n=r.pop();break;case $:if(0===n)break e;break;case D:if(0===n&&"!"===e.value)break e;break;case L:case Z:case q:case G:r.push(n),n=mn.get(e.type)}o++}while(e=t(o));return o},"any-value":function(e,t){if(!e)return 0;let n=0,r=[],o=0;e:do{switch(e.type){case j:case R:break e;case X:case K:case H:if(e.type!==n)break e;n=r.pop();break;case L:case Z:case q:case G:r.push(n),n=mn.get(e.type)}o++}while(e=t(o));return o}};function Cn(e){const{angle:t,decibel:n,frequency:r,flex:o,length:i,resolution:a,semitones:s,time:l}=e||{};return{dimension:wn(Sn(null)),angle:wn(Sn(t)),decibel:wn(Sn(n)),frequency:wn(Sn(r)),flex:wn(Sn(o)),length:wn(On(Sn(i))),resolution:wn(Sn(a)),semitones:wn(Sn(s)),time:wn(Sn(l))}}var Pn=Object.freeze({__proto__:null,angle:["deg","grad","rad","turn"],decibel:["db"],flex:["fr"],frequency:["hz","khz"],length:["cm","mm","q","in","pt","pc","px","em","rem","ex","rex","cap","rcap","ch","rch","ic","ric","lh","rlh","vw","svw","lvw","dvw","vh","svh","lvh","dvh","vi","svi","lvi","dvi","vb","svb","lvb","dvb","vmin","svmin","lvmin","dvmin","vmax","svmax","lvmax","dvmax","cqw","cqh","cqi","cqb","cqmin","cqmax"],resolution:["dpi","dpcm","dppx","x"],semitones:["st"],time:["s","ms"]});function Ln(e,t,n){return Object.assign(Ye("SyntaxError",e),{input:t,offset:n,rawMessage:e,message:e+"\n  "+t+"\n--"+new Array((n||t.length)+1).join("-")+"^"})}const zn=new Uint8Array(128).map(((e,t)=>/[a-zA-Z0-9\-]/.test(String.fromCharCode(t))?1:0));class Nn{constructor(e){this.str=e,this.pos=0}charCodeAt(e){return e<this.str.length?this.str.charCodeAt(e):0}charCode(){return this.charCodeAt(this.pos)}isNameCharCode(e=this.charCode()){return e<128&&1===zn[e]}nextCharCode(){return this.charCodeAt(this.pos+1)}nextNonWsCode(e){return this.charCodeAt(this.findWsEnd(e))}skipWs(){this.pos=this.findWsEnd(this.pos)}findWsEnd(e){for(;e<this.str.length;e++){const t=this.str.charCodeAt(e);if(13!==t&&10!==t&&12!==t&&32!==t&&9!==t)break}return e}substringToPos(e){return this.str.substring(this.pos,this.pos=e)}eat(e){this.charCode()!==e&&this.error("Expect `"+String.fromCharCode(e)+"`"),this.pos++}peek(){return this.pos<this.str.length?this.str.charAt(this.pos++):""}error(e){throw new Ln(e,this.str,this.pos)}scanSpaces(){return this.substringToPos(this.findWsEnd(this.pos))}scanWord(){let e=this.pos;for(;e<this.str.length;e++){const t=this.str.charCodeAt(e);if(t>=128||0===zn[t])break}return this.pos===e&&this.error("Expect a keyword"),this.substringToPos(e)}scanNumber(){let e=this.pos;for(;e<this.str.length;e++){const t=this.str.charCodeAt(e);if(t<48||t>57)break}return this.pos===e&&this.error("Expect a number"),this.substringToPos(e)}scanString(){const e=this.str.indexOf("'",this.pos+1);return-1===e&&(this.pos=this.str.length,this.error("Expect an apostrophe")),this.substringToPos(e+1)}}const Tn=9,jn=10,In=12,Rn=13,Dn=32,Mn=33,Bn=35,Wn=38,Jn=39,Fn=40,Yn=41,Un=42,$n=43,Vn=44,qn=45,Hn=60,Zn=62,Kn=63,Gn=64,Xn=91,Qn=93,er=123,tr=124,nr=125,rr=8734,or={" ":1,"&&":2,"||":3,"|":4};function ir(e){let t=null,n=null;return e.eat(er),e.skipWs(),t=e.scanNumber(e),e.skipWs(),e.charCode()===Vn?(e.pos++,e.skipWs(),e.charCode()!==nr&&(n=e.scanNumber(e),e.skipWs())):n=t,e.eat(nr),{min:Number(t),max:n?Number(n):0}}function ar(e,t){const n=function(e){let t=null,n=!1;switch(e.charCode()){case Un:e.pos++,t={min:0,max:0};break;case $n:e.pos++,t={min:1,max:0};break;case Kn:e.pos++,t={min:0,max:1};break;case Bn:e.pos++,n=!0,e.charCode()===er?t=ir(e):e.charCode()===Kn?(e.pos++,t={min:0,max:0}):t={min:1,max:0};break;case er:t=ir(e);break;default:return null}return{type:"Multiplier",comma:n,min:t.min,max:t.max,term:null}}(e);return null!==n?(n.term=t,e.charCode()===Bn&&e.charCodeAt(e.pos-1)===$n?ar(e,n):n):t}function sr(e){const t=e.peek();return""===t?null:ar(e,{type:"Token",value:t})}function lr(e,t){function n(e,t){return{type:"Group",terms:e,combinator:t,disallowEmpty:!1,explicit:!1}}let r;for(t=Object.keys(t).sort(((e,t)=>or[e]-or[t]));t.length>0;){r=t.shift();let o=0,i=0;for(;o<e.length;o++){const t=e[o];"Combinator"===t.type&&(t.value===r?(-1===i&&(i=o-1),e.splice(o,1),o--):(-1!==i&&o-i>1&&(e.splice(i,o-i,n(e.slice(i,o),r)),o=i+1),i=-1))}-1!==i&&t.length&&e.splice(i,o-i,n(e.slice(i,o),r))}return r}function cr(e,t){const n=Object.create(null),r=[];let o,i=null,a=e.pos;for(;e.charCode()!==t&&(o=ur(e,t));)"Spaces"!==o.type&&("Combinator"===o.type?(null!==i&&"Combinator"!==i.type||(e.pos=a,e.error("Unexpected combinator")),n[o.value]=!0):null!==i&&"Combinator"!==i.type&&(n[" "]=!0,r.push({type:"Combinator",value:" "})),r.push(o),i=o,a=e.pos);return null!==i&&"Combinator"===i.type&&(e.pos-=a,e.error("Unexpected combinator")),{type:"Group",terms:r,combinator:lr(r,n)||" ",disallowEmpty:!1,explicit:!1}}function ur(e,t){let n=e.charCode();switch(n){case Qn:break;case Xn:return ar(e,function(e,t){let n;return e.eat(Xn),n=cr(e,t),e.eat(Qn),n.explicit=!0,e.charCode()===Mn&&(e.pos++,n.disallowEmpty=!0),n}(e,t));case Hn:return e.nextCharCode()===Jn?function(e){let t;return e.eat(Hn),e.eat(Jn),t=e.scanWord(),e.eat(Jn),e.eat(Zn),ar(e,{type:"Property",name:t})}(e):function(e){let t,n=null;if(e.eat(Hn),t=e.scanWord(),"boolean-expr"===t){e.eat(Xn);const t=cr(e,Qn);return e.eat(Qn),e.eat(Zn),ar(e,{type:"Boolean",term:1===t.terms.length?t.terms[0]:t})}return e.charCode()===Fn&&e.nextCharCode()===Yn&&(e.pos+=2,t+="()"),e.charCodeAt(e.findWsEnd(e.pos))===Xn&&(e.skipWs(),n=function(e){let t=null,n=null,r=1;return e.eat(Xn),e.charCode()===qn&&(e.peek(),r=-1),-1==r&&e.charCode()===rr?e.peek():(t=r*Number(e.scanNumber(e)),e.isNameCharCode()&&(t+=e.scanWord())),e.skipWs(),e.eat(Vn),e.skipWs(),e.charCode()===rr?e.peek():(r=1,e.charCode()===qn&&(e.peek(),r=-1),n=r*Number(e.scanNumber(e)),e.isNameCharCode()&&(n+=e.scanWord())),e.eat(Qn),{type:"Range",min:t,max:n}}(e)),e.eat(Zn),ar(e,{type:"Type",name:t,opts:n})}(e);case tr:return{type:"Combinator",value:e.substringToPos(e.pos+(e.nextCharCode()===tr?2:1))};case Wn:return e.pos++,e.eat(Wn),{type:"Combinator",value:"&&"};case Vn:return e.pos++,{type:"Comma"};case Jn:return ar(e,{type:"String",value:e.scanString()});case Dn:case Tn:case jn:case Rn:case In:return{type:"Spaces",value:e.scanSpaces()};case Gn:return n=e.nextCharCode(),e.isNameCharCode(n)?(e.pos++,{type:"AtKeyword",name:e.scanWord()}):sr(e);case Un:case $n:case Kn:case Bn:case Mn:break;case er:if(n=e.nextCharCode(),n<48||n>57)return sr(e);break;default:return e.isNameCharCode(n)?function(e){const t=e.scanWord();return e.charCode()===Fn?(e.pos++,{type:"Function",name:t}):ar(e,{type:"Keyword",name:t})}(e):sr(e)}}function dr(e){const t=new Nn(e),n=cr(t);return t.pos!==e.length&&t.error("Unexpected input"),1===n.terms.length&&"Group"===n.terms[0].type?n.terms[0]:n}const hr=function(){};const pr={decorator(e){const t=[];let n=null;return{...e,node(t){const r=n;n=t,e.node.call(this,t),n=r},emit(e,r,o){t.push({type:r,value:e,node:o?null:n})},result:()=>t}}};const fr={type:"Match"},mr={type:"Mismatch"},gr={type:"DisallowEmpty"},yr=40,br=41;function _r(e,t,n){return t===fr&&n===mr||e===fr&&t===fr&&n===fr?e:("If"===e.type&&e.else===mr&&t===fr&&(t=e.then,e=e.match),{type:"If",match:e,then:t,else:n})}function vr(e){return e.length>2&&e.charCodeAt(e.length-2)===yr&&e.charCodeAt(e.length-1)===br}function wr(e){return"Keyword"===e.type||"AtKeyword"===e.type||"Function"===e.type||"Type"===e.type&&vr(e.name)}function kr(e,t=" ",n=!1){return{type:"Group",terms:e,combinator:t,disallowEmpty:!1,explicit:n}}function xr(e,t,n=new Set){if(!n.has(e))switch(n.add(e),e.type){case"If":e.match=xr(e.match,t,n),e.then=xr(e.then,t,n),e.else=xr(e.else,t,n);break;case"Type":return t[e.name]||e}return e}function Sr(e,t,n){switch(e){case" ":{let e=fr;for(let n=t.length-1;n>=0;n--)e=_r(t[n],e,mr);return e}case"|":{let e=mr,n=null;for(let r=t.length-1;r>=0;r--){let o=t[r];if(wr(o)&&(null===n&&r>0&&wr(t[r-1])&&(n=Object.create(null),e=_r({type:"Enum",map:n},fr,e)),null!==n)){const e=(vr(o.name)?o.name.slice(0,-1):o.name).toLowerCase();if(e in n==0){n[e]=o;continue}}n=null,e=_r(o,fr,e)}return e}case"&&":{if(t.length>5)return{type:"MatchOnce",terms:t,all:!0};let n=mr;for(let r=t.length-1;r>=0;r--){const o=t[r];let i;i=t.length>1?Sr(e,t.filter((function(e){return e!==o})),!1):fr,n=_r(o,i,n)}return n}case"||":{if(t.length>5)return{type:"MatchOnce",terms:t,all:!1};let r=n?fr:mr;for(let n=t.length-1;n>=0;n--){const o=t[n];let i;i=t.length>1?Sr(e,t.filter((function(e){return e!==o})),!0):fr,r=_r(o,i,r)}return r}}}function Or(e){if("function"==typeof e)return{type:"Generic",fn:e};switch(e.type){case"Group":{let t=Sr(e.combinator,e.terms.map(Or),!1);return e.disallowEmpty&&(t=_r(t,gr,mr)),t}case"Multiplier":return function(e){let t=fr,n=Or(e.term);if(0===e.max)n=_r(n,gr,mr),t=_r(n,null,mr),t.then=_r(fr,fr,t),e.comma&&(t.then.else=_r({type:"Comma",syntax:e},t,mr));else for(let r=e.min||1;r<=e.max;r++)e.comma&&t!==fr&&(t=_r({type:"Comma",syntax:e},t,mr)),t=_r(n,_r(fr,fr,t),mr);if(0===e.min)t=_r(fr,fr,t);else for(let r=0;r<e.min-1;r++)e.comma&&t!==fr&&(t=_r({type:"Comma",syntax:e},t,mr)),t=_r(n,t,mr);return t}(e);case"Boolean":{const t=Or(e.term),n=Or(kr([kr([{type:"Keyword",name:"not"},{type:"Type",name:"!boolean-group"}]),kr([{type:"Type",name:"!boolean-group"},kr([{type:"Multiplier",comma:!1,min:0,max:0,term:kr([{type:"Keyword",name:"and"},{type:"Type",name:"!boolean-group"}])},{type:"Multiplier",comma:!1,min:0,max:0,term:kr([{type:"Keyword",name:"or"},{type:"Type",name:"!boolean-group"}])}],"|")])],"|")),r=Or(kr([{type:"Type",name:"!term"},kr([{type:"Token",value:"("},{type:"Type",name:"!self"},{type:"Token",value:")"}]),{type:"Type",name:"general-enclosed"}],"|"));return xr(r,{"!term":t,"!self":n}),xr(n,{"!boolean-group":r}),n}case"Type":case"Property":return{type:e.type,name:e.name,syntax:e};case"Keyword":return{type:e.type,name:e.name.toLowerCase(),syntax:e};case"AtKeyword":return{type:e.type,name:"@"+e.name.toLowerCase(),syntax:e};case"Function":return{type:e.type,name:e.name.toLowerCase()+"(",syntax:e};case"String":return 3===e.value.length?{type:"Token",value:e.value.charAt(1),syntax:e}:{type:e.type,value:e.value.substr(1,e.value.length-2).replace(/\\'/g,"'"),syntax:e};case"Token":return{type:e.type,value:e.value,syntax:e};case"Comma":return{type:e.type,syntax:e};default:throw new Error("Unknown node type:",e.type)}}function Ar(e,t){return"string"==typeof e&&(e=dr(e)),{type:"MatchGraph",match:Or(e),syntax:t||null,source:e}}const{hasOwnProperty:Er}=Object.prototype,Cr=0,Pr=1,Lr=2,zr=3,Nr="Match",Tr="Mismatch",jr="Maximum iteration number exceeded (please fill an issue on https://github.com/csstree/csstree/issues)",Ir=15e3;function Rr(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++){const r=t.charCodeAt(n);let o=e.charCodeAt(n);if(o>=65&&o<=90&&(o|=32),o!==r)return!1}return!0}function Dr(e){return null===e||e.type===V||e.type===L||e.type===Z||e.type===q||e.type===G||function(e){return e.type===D&&"?"!==e.value}(e)}function Mr(e){return null===e||e.type===K||e.type===H||e.type===X||e.type===D&&"/"===e.value}function Br(e,t,n){const r=function(e,t,n){function r(){do{y++,g=y<e.length?e[y]:null}while(null!==g&&(g.type===J||g.type===Q))}function o(t){const n=y+t;return n<e.length?e[n]:null}function i(e,t){return{nextState:e,matchStack:_,syntaxStack:u,thenStack:d,tokenIndex:y,prev:t}}function a(e){d={nextState:e,matchStack:_,syntaxStack:u,prev:d}}function s(e){h=i(e,h)}function l(){_={type:Pr,syntax:t.syntax,token:g,prev:_},r(),p=null,y>b&&(b=y)}function c(){_=_.type===Lr?_.prev:{type:zr,syntax:u.syntax,token:_.token,prev:_},u=u.prev}let u=null,d=null,h=null,p=null,f=0,m=null,g=null,y=-1,b=0,_={type:Cr,syntax:null,token:null,prev:null};for(r();null===m&&++f<Ir;)switch(t.type){case"Match":if(null===d){if(null!==g&&(y!==e.length-1||"\\0"!==g.value&&"\\9"!==g.value)){t=mr;break}m=Nr;break}if((t=d.nextState)===gr){if(d.matchStack===_){t=mr;break}t=fr}for(;d.syntaxStack!==u;)c();d=d.prev;break;case"Mismatch":if(null!==p&&!1!==p)(null===h||y>h.tokenIndex)&&(h=p,p=!1);else if(null===h){m=Tr;break}t=h.nextState,d=h.thenStack,u=h.syntaxStack,_=h.matchStack,y=h.tokenIndex,g=y<e.length?e[y]:null,h=h.prev;break;case"MatchGraph":t=t.match;break;case"If":t.else!==mr&&s(t.else),t.then!==fr&&a(t.then),t=t.match;break;case"MatchOnce":t={type:"MatchOnceBuffer",syntax:t,index:0,mask:0};break;case"MatchOnceBuffer":{const e=t.syntax.terms;if(t.index===e.length){if(0===t.mask||t.syntax.all){t=mr;break}t=fr;break}if(t.mask===(1<<e.length)-1){t=fr;break}for(;t.index<e.length;t.index++){const n=1<<t.index;if(0==(t.mask&n)){s(t),a({type:"AddMatchOnce",syntax:t.syntax,mask:t.mask|n}),t=e[t.index++];break}}break}case"AddMatchOnce":t={type:"MatchOnceBuffer",syntax:t.syntax,index:0,mask:t.mask};break;case"Enum":if(null!==g){let e=g.value.toLowerCase();if(-1!==e.indexOf("\\")&&(e=e.replace(/\\[09].*$/,"")),Er.call(t.map,e)){t=t.map[e];break}}t=mr;break;case"Generic":{const e=null!==u?u.opts:null,n=y+Math.floor(t.fn(g,o,e));if(!isNaN(n)&&n>y){for(;y<n;)l();t=fr}else t=mr;break}case"Type":case"Property":{const e="Type"===t.type?"types":"properties",r=Er.call(n,e)?n[e][t.name]:null;if(!r||!r.match)throw new Error("Bad syntax reference: "+("Type"===t.type?"<"+t.name+">":"<'"+t.name+"'>"));if(!1!==p&&null!==g&&"Type"===t.type&&("custom-ident"===t.name&&g.type===P||"length"===t.name&&"0"===g.value)){null===p&&(p=i(t,h)),t=mr;break}u={syntax:t.syntax,opts:t.syntax.opts||null!==u&&u.opts||null,prev:u},_={type:Lr,syntax:t.syntax,token:_.token,prev:_},t=r.matchRef||r.match;break}case"Keyword":{const e=t.name;if(null!==g){let n=g.value;if(-1!==n.indexOf("\\")&&(n=n.replace(/\\[09].*$/,"")),Rr(n,e)){l(),t=fr;break}}t=mr;break}case"AtKeyword":case"Function":if(null!==g&&Rr(g.value,t.name)){l(),t=fr;break}t=mr;break;case"Token":if(null!==g&&g.value===t.value){l(),t=fr;break}t=mr;break;case"Comma":null!==g&&g.type===V?Dr(_.token)?t=mr:(l(),t=Mr(g)?mr:fr):t=Dr(_.token)||Mr(g)?fr:mr;break;case"String":let r="",f=y;for(;f<e.length&&r.length<t.value.length;f++)r+=e[f].value;if(Rr(r,t.value)){for(;y<f;)l();t=fr}else t=mr;break;default:throw new Error("Unknown node type: "+t.type)}switch(m){case null:console.warn("[csstree-match] BREAK after "+Ir+" iterations"),m=jr,_=null;break;case Nr:for(;null!==u;)c();break;default:_=null}return{tokens:e,reason:m,iterations:f,match:_,longestMatch:b}}(e,t,n||{});if(null===r.match)return r;let o=r.match,i=r.match={syntax:t.syntax||null,match:[]};const a=[i];for(o=function(e){let t=null,n=null,r=e;for(;null!==r;)n=r.prev,r.prev=t,t=r,r=n;return t}(o).prev;null!==o;){switch(o.type){case Lr:i.match.push(i={syntax:o.syntax,match:[]}),a.push(i);break;case zr:a.pop(),i=a[a.length-1];break;default:i.match.push({syntax:o.syntax||null,token:o.token.value,node:o.token.node})}o=o.prev}return r}function Wr(e){function t(e){return null!==e&&("Type"===e.type||"Property"===e.type||"Keyword"===e.type)}let n=null;return null!==this.matched&&function r(o){if(Array.isArray(o.match)){for(let e=0;e<o.match.length;e++)if(r(o.match[e]))return t(o.syntax)&&n.unshift(o.syntax),!0}else if(o.node===e)return n=t(o.syntax)?[o.syntax]:[],!0;return!1}(this.matched),n}function Jr(e,t,n){const r=Wr.call(e,t);return null!==r&&r.some(n)}var Fr=Object.freeze({__proto__:null,getTrace:Wr,isKeyword:function(e){return Jr(this,e,(e=>"Keyword"===e.type))},isProperty:function(e,t){return Jr(this,e,(e=>"Property"===e.type&&e.name===t))},isType:function(e,t){return Jr(this,e,(e=>"Type"===e.type&&e.name===t))}});function Yr(e){return"node"in e?e.node:Yr(e.match[0])}function Ur(e){return"node"in e?e.node:Ur(e.match[e.match.length-1])}function $r(e,t,n,r,o){const i=[];return null!==n.matched&&function n(a){if(null!==a.syntax&&a.syntax.type===r&&a.syntax.name===o){const n=Yr(a),r=Ur(a);e.syntax.walk(t,(function(e,t,o){if(e===n){const e=new Fe;do{if(e.appendData(t.data),t.data===r)break;t=t.next}while(null!==t);i.push({parent:o,nodes:e})}}))}Array.isArray(a.match)&&a.match.forEach(n)}(n.matched),i}const{hasOwnProperty:Vr}=Object.prototype;function qr(e){return"number"==typeof e&&isFinite(e)&&Math.floor(e)===e&&e>=0}function Hr(e){return Boolean(e)&&qr(e.offset)&&qr(e.line)&&qr(e.column)}function Zr(e,t){return function(n,r){if(!n||n.constructor!==Object)return r(n,"Type of node should be an Object");for(let o in n){let i=!0;if(!1!==Vr.call(n,o)){if("type"===o)n.type!==e&&r(n,"Wrong node type `"+n.type+"`, expected `"+e+"`");else if("loc"===o){if(null===n.loc)continue;if(n.loc&&n.loc.constructor===Object)if("string"!=typeof n.loc.source)o+=".source";else if(Hr(n.loc.start)){if(Hr(n.loc.end))continue;o+=".end"}else o+=".start";i=!1}else if(t.hasOwnProperty(o)){i=!1;for(let e=0;!i&&e<t[o].length;e++){const r=t[o][e];switch(r){case String:i="string"==typeof n[o];break;case Boolean:i="boolean"==typeof n[o];break;case null:i=null===n[o];break;default:"string"==typeof r?i=n[o]&&n[o].type===r:Array.isArray(r)&&(i=n[o]instanceof Fe)}}}else r(n,"Unknown field `"+o+"` for "+e+" node type");i||r(n,"Bad value for `"+e+"."+o+"`")}}for(const o in t)Vr.call(t,o)&&!1===Vr.call(n,o)&&r(n,"Field `"+e+"."+o+"` is missed")}}function Kr(e,t){const n=[];for(let r=0;r<e.length;r++){const o=e[r];if(o===String||o===Boolean)n.push(o.name.toLowerCase());else if(null===o)n.push("null");else if("string"==typeof o)n.push(o);else{if(!Array.isArray(o))throw new Error("Wrong value `"+o+"` in `"+t+"` structure definition");n.push("List<"+(Kr(o,t)||"any")+">")}}return n.join(" | ")}function Gr(e,t){const n=t.structure,r={type:String,loc:!0},o={type:'"'+e+'"'};for(const t in n){if(!1===Vr.call(n,t))continue;const i=r[t]=Array.isArray(n[t])?n[t].slice():[n[t]];o[t]=Kr(i,e+"."+t)}return{docs:o,check:Zr(e,r)}}function Xr(e,t,n){const r={};for(const o in e)e[o].syntax&&(r[o]=n?e[o].syntax:Yt(e[o].syntax,{compact:t}));return r}function Qr(e,t,n){const r={};for(const[o,i]of Object.entries(e))r[o]={prelude:i.prelude&&(n?i.prelude.syntax:Yt(i.prelude.syntax,{compact:t})),descriptors:i.descriptors&&Xr(i.descriptors,t,n)};return r}function eo(e,t,n){return{matched:e,iterations:n,error:t,...Fr}}function to(e,t,n,r){const o=function(e,t){return"string"==typeof e?function(e){const t=[];return We(e,((n,r,o)=>t.push({type:n,value:e.slice(r,o),node:null}))),t}(e):t.generate(e,pr)}(n,e.syntax);let i;return function(e){for(let t=0;t<e.length;t++)if("var("===e[t].value.toLowerCase())return!0;return!1}(o)?eo(null,new Error("Matching for a tree with var() is not supported")):(r&&(i=Br(o,e.cssWideKeywordsSyntax,e)),r&&i.match||(i=Br(o,t.match,e),i.match)?eo(i.match,null,i.iterations):eo(null,new Ht(i.reason,t.syntax,n,i),i.iterations))}class no{constructor(e,t,n){if(this.cssWideKeywords=nn,this.syntax=t,this.generic=!1,this.units={...Pn},this.atrules=Object.create(null),this.properties=Object.create(null),this.types=Object.create(null),this.structure=n||function(e){const t={};if(e.node)for(const n in e.node)if(Vr.call(e.node,n)){const r=e.node[n];if(!r.structure)throw new Error("Missed `structure` field in `"+n+"` node type definition");t[n]=Gr(n,r)}return t}(e),e){if(e.cssWideKeywords&&(this.cssWideKeywords=e.cssWideKeywords),e.units)for(const t of Object.keys(Pn))Array.isArray(e.units[t])&&(this.units[t]=e.units[t]);if(e.types)for(const[t,n]of Object.entries(e.types))this.addType_(t,n);if(e.generic){this.generic=!0;for(const[e,t]of Object.entries(function(e){return{...An,...En,...Cn(e)}}(this.units)))this.addType_(e,t)}if(e.atrules)for(const[t,n]of Object.entries(e.atrules))this.addAtrule_(t,n);if(e.properties)for(const[t,n]of Object.entries(e.properties))this.addProperty_(t,n)}this.cssWideKeywordsSyntax=Ar(this.cssWideKeywords.join(" |  "))}checkStructure(e){function t(e,t){r.push({node:e,message:t})}const n=this.structure,r=[];return this.syntax.walk(e,(function(e){n.hasOwnProperty(e.type)?n[e.type].check(e,t):t(e,"Unknown node type `"+e.type+"`")})),!!r.length&&r}createDescriptor(e,t,n,r=null){const o={type:t,name:n},i={type:t,name:n,parent:r,serializable:"string"==typeof e||e&&"string"==typeof e.type,syntax:null,match:null,matchRef:null};return"function"==typeof e?i.match=Ar(e,o):("string"==typeof e?Object.defineProperty(i,"syntax",{get:()=>(Object.defineProperty(i,"syntax",{value:dr(e)}),i.syntax)}):i.syntax=e,Object.defineProperty(i,"match",{get:()=>(Object.defineProperty(i,"match",{value:Ar(i.syntax,o)}),i.match)}),"Property"===t&&Object.defineProperty(i,"matchRef",{get(){const e=i.syntax,t=function(e){const t=e.terms[0];return!1===e.explicit&&1===e.terms.length&&"Multiplier"===t.type&&!0===t.comma}(e)?Ar({...e,terms:[e.terms[0].term]},o):null;return Object.defineProperty(i,"matchRef",{value:t}),t}})),i}addAtrule_(e,t){t&&(this.atrules[e]={type:"Atrule",name:e,prelude:t.prelude?this.createDescriptor(t.prelude,"AtrulePrelude",e):null,descriptors:t.descriptors?Object.keys(t.descriptors).reduce(((n,r)=>(n[r]=this.createDescriptor(t.descriptors[r],"AtruleDescriptor",r,e),n)),Object.create(null)):null})}addProperty_(e,t){t&&(this.properties[e]=this.createDescriptor(t,"Property",e))}addType_(e,t){t&&(this.types[e]=this.createDescriptor(t,"Type",e))}checkAtruleName(e){if(!this.getAtrule(e))return new qt("Unknown at-rule","@"+e)}checkAtrulePrelude(e,t){const n=this.checkAtruleName(e);if(n)return n;const r=this.getAtrule(e);return!r.prelude&&t?new SyntaxError("At-rule `@"+e+"` should not contain a prelude"):!r.prelude||t||to(this,r.prelude,"",!1).matched?void 0:new SyntaxError("At-rule `@"+e+"` should contain a prelude")}checkAtruleDescriptorName(e,t){const n=this.checkAtruleName(e);if(n)return n;const r=this.getAtrule(e),o=Xt(t);return r.descriptors?r.descriptors[o.name]||r.descriptors[o.basename]?void 0:new qt("Unknown at-rule descriptor",t):new SyntaxError("At-rule `@"+e+"` has no known descriptors")}checkPropertyName(e){if(!this.getProperty(e))return new qt("Unknown property",e)}matchAtrulePrelude(e,t){const n=this.checkAtrulePrelude(e,t);if(n)return eo(null,n);const r=this.getAtrule(e);return r.prelude?to(this,r.prelude,t||"",!1):eo(null,null)}matchAtruleDescriptor(e,t,n){const r=this.checkAtruleDescriptorName(e,t);if(r)return eo(null,r);const o=this.getAtrule(e),i=Xt(t);return to(this,o.descriptors[i.name]||o.descriptors[i.basename],n,!1)}matchDeclaration(e){return"Declaration"!==e.type?eo(null,new Error("Not a Declaration node")):this.matchProperty(e.property,e.value)}matchProperty(e,t){if(Qt(e).custom)return eo(null,new Error("Lexer matching doesn't applicable for custom properties"));const n=this.checkPropertyName(e);return n?eo(null,n):to(this,this.getProperty(e),t,!0)}matchType(e,t){const n=this.getType(e);return n?to(this,n,t,!1):eo(null,new qt("Unknown type",e))}match(e,t){return"string"==typeof e||e&&e.type?("string"!=typeof e&&e.match||(e=this.createDescriptor(e,"Type","anonymous")),to(this,e,t,!1)):eo(null,new qt("Bad syntax"))}findValueFragments(e,t,n,r){return $r(this,t,this.matchProperty(e,t),n,r)}findDeclarationValueFragments(e,t,n){return $r(this,e.value,this.matchDeclaration(e),t,n)}findAllFragments(e,t,n){const r=[];return this.syntax.walk(e,{visit:"Declaration",enter:e=>{r.push.apply(r,this.findDeclarationValueFragments(e,t,n))}}),r}getAtrule(e,t=!0){const n=Xt(e);return(n.vendor&&t?this.atrules[n.name]||this.atrules[n.basename]:this.atrules[n.name])||null}getAtrulePrelude(e,t=!0){const n=this.getAtrule(e,t);return n&&n.prelude||null}getAtruleDescriptor(e,t){return this.atrules.hasOwnProperty(e)&&this.atrules.declarators&&this.atrules[e].declarators[t]||null}getProperty(e,t=!0){const n=Qt(e);return(n.vendor&&t?this.properties[n.name]||this.properties[n.basename]:this.properties[n.name])||null}getType(e){return hasOwnProperty.call(this.types,e)?this.types[e]:null}validate(){function e(e,t){return t?`<${e}>`:`<'${e}'>`}function t(i,a,s,l){if(s.has(a))return s.get(a);s.set(a,!1),null!==l.syntax&&function(e,t,n){let r=hr,o=hr;if(r=t,r===hr&&o===hr)throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");!function e(t){switch(r.call(n,t),t.type){case"Group":t.terms.forEach(e);break;case"Multiplier":case"Boolean":e(t.term);break;case"Type":case"Property":case"Keyword":case"AtKeyword":case"Function":case"String":case"Token":case"Comma":break;default:throw new Error("Unknown type: "+t.type)}o.call(n,t)}(e)}(l.syntax,(function(l){if("Type"!==l.type&&"Property"!==l.type)return;const c="Type"===l.type?i.types:i.properties,u="Type"===l.type?r:o;hasOwnProperty.call(c,l.name)?t(i,l.name,u,c[l.name])&&(n.push(`${e(a,s===r)} used broken syntax definition ${e(l.name,"Type"===l.type)}`),s.set(a,!0)):(n.push(`${e(a,s===r)} used missed syntax definition ${e(l.name,"Type"===l.type)}`),s.set(a,!0))}),this)}const n=[];let r=new Map,o=new Map;for(const e in this.types)t(this,e,r,this.types[e]);for(const e in this.properties)t(this,e,o,this.properties[e]);const i=[...r.keys()].filter((e=>r.get(e))),a=[...o.keys()].filter((e=>o.get(e)));return i.length||a.length?{errors:n,types:i,properties:a}:null}dump(e,t){return{generic:this.generic,cssWideKeywords:this.cssWideKeywords,units:this.units,types:Xr(this.types,!t,e),properties:Xr(this.properties,!t,e),atrules:Qr(this.atrules,!t,e)}}toString(){return JSON.stringify(this.dump())}}function ro(e,t){return"string"==typeof t&&/^\s*\|/.test(t)?"string"==typeof e?e+t:t.replace(/^\s*\|\s*/,""):t||null}function oo(e,t){const n=Object.create(null);for(const[r,o]of Object.entries(e))if(o){n[r]={};for(const e of Object.keys(o))t.includes(e)&&(n[r][e]=o[e])}return n}function io(e,t){const n={...e};for(const[r,o]of Object.entries(t))switch(r){case"generic":n[r]=Boolean(o);break;case"cssWideKeywords":n[r]=e[r]?[...e[r],...o]:o||[];break;case"units":n[r]={...e[r]};for(const[e,t]of Object.entries(o))n[r][e]=Array.isArray(t)?t:[];break;case"atrules":n[r]={...e[r]};for(const[e,t]of Object.entries(o)){const o=n[r][e]||{},i=n[r][e]={prelude:o.prelude||null,descriptors:{...o.descriptors}};if(t){i.prelude=t.prelude?ro(i.prelude,t.prelude):i.prelude||null;for(const[e,n]of Object.entries(t.descriptors||{}))i.descriptors[e]=n?ro(i.descriptors[e],n):null;Object.keys(i.descriptors).length||(i.descriptors=null)}}break;case"types":case"properties":n[r]={...e[r]};for(const[e,t]of Object.entries(o))n[r][e]=ro(n[r][e],t);break;case"scope":case"features":n[r]={...e[r]};for(const[e,t]of Object.entries(o))n[r][e]={...n[r][e],...t};break;case"parseContext":n[r]={...e[r],...o};break;case"atrule":case"pseudo":n[r]={...e[r],...oo(o,["parse"])};break;case"node":n[r]={...e[r],...oo(o,["name","structure","parse","generate","walkContext"])}}return n}const ao=43,so=45,lo=110,co=!0;function uo(e,t){let n=this.tokenStart+e;const r=this.charCodeAt(n);for(r!==ao&&r!==so||(t&&this.error("Number sign is not allowed"),n++);n<this.tokenEnd;n++)te(this.charCodeAt(n))||this.error("Integer is expected",n)}function ho(e){return uo.call(this,0,e)}function po(e,t){if(!this.cmpChar(this.tokenStart+e,t)){let n="";switch(t){case lo:n="N is expected";break;case so:n="HyphenMinus is expected"}this.error(n,this.tokenStart+e)}}function fo(){let e=0,t=0,n=this.tokenType;for(;n===J||n===Q;)n=this.lookupType(++e);if(n!==M){if(!this.isDelim(ao,e)&&!this.isDelim(so,e))return null;t=this.isDelim(ao,e)?ao:so;do{n=this.lookupType(++e)}while(n===J||n===Q);n!==M&&(this.skip(e),ho.call(this,co))}return e>0&&this.skip(e),0===t&&(n=this.charCodeAt(this.tokenStart),n!==ao&&n!==so&&this.error("Number sign is expected")),ho.call(this,0!==t),t===so?"-"+this.consume(M):this.consume(M)}const mo={a:[String,null],b:[String,null]};function go(){const e=this.tokenStart;let t=null,n=null;if(this.tokenType===M)ho.call(this,!1),n=this.consume(M);else if(this.tokenType===P&&this.cmpChar(this.tokenStart,so))switch(t="-1",po.call(this,1,lo),this.tokenEnd-this.tokenStart){case 2:this.next(),n=fo.call(this);break;case 3:po.call(this,2,so),this.next(),this.skipSC(),ho.call(this,co),n="-"+this.consume(M);break;default:po.call(this,2,so),uo.call(this,3,co),this.next(),n=this.substrToCursor(e+2)}else if(this.tokenType===P||this.isDelim(ao)&&this.lookupType(1)===P){let r=0;switch(t="1",this.isDelim(ao)&&(r=1,this.next()),po.call(this,0,lo),this.tokenEnd-this.tokenStart){case 1:this.next(),n=fo.call(this);break;case 2:po.call(this,1,so),this.next(),this.skipSC(),ho.call(this,co),n="-"+this.consume(M);break;default:po.call(this,1,so),uo.call(this,2,co),this.next(),n=this.substrToCursor(e+r+1)}}else if(this.tokenType===W){const r=this.charCodeAt(this.tokenStart),o=r===ao||r===so;let i=this.tokenStart+o;for(;i<this.tokenEnd&&te(this.charCodeAt(i));i++);i===this.tokenStart+o&&this.error("Integer is expected",this.tokenStart+o),po.call(this,i-this.tokenStart,lo),t=this.substring(e,i),i+1===this.tokenEnd?(this.next(),n=fo.call(this)):(po.call(this,i-this.tokenStart+1,so),i+2===this.tokenEnd?(this.next(),this.skipSC(),ho.call(this,co),n="-"+this.consume(M)):(uo.call(this,i-this.tokenStart+2,co),this.next(),n=this.substrToCursor(i+1)))}else this.error();return null!==t&&t.charCodeAt(0)===ao&&(t=t.substr(1)),null!==n&&n.charCodeAt(0)===ao&&(n=n.substr(1)),{type:"AnPlusB",loc:this.getLocation(e,this.tokenStart),a:t,b:n}}var yo=Object.freeze({__proto__:null,generate:function(e){if(e.a){const t=("+1"===e.a||"1"===e.a?"n":"-1"===e.a&&"-n")||e.a+"n";if(e.b){const n="-"===e.b[0]||"+"===e.b[0]?e.b:"+"+e.b;this.tokenize(t+n)}else this.tokenize(t)}else this.tokenize(e.b)},name:"AnPlusB",parse:go,structure:mo});function bo(){return this.Raw(this.consumeUntilLeftCurlyBracketOrSemicolon,!0)}function _o(){for(let e,t=1;e=this.lookupType(t);t++){if(e===X)return!0;if(e===G||e===z)return!1}return!1}const vo={name:String,prelude:["AtrulePrelude","Raw",null],block:["Block",null]};function wo(e=!1){const t=this.tokenStart;let n,r,o=null,i=null;switch(this.eat(z),n=this.substrToCursor(t+1),r=n.toLowerCase(),this.skipSC(),!1===this.eof&&this.tokenType!==G&&this.tokenType!==$&&(o=this.parseAtrulePrelude?this.parseWithFallback(this.AtrulePrelude.bind(this,n,e),bo):bo.call(this,this.tokenIndex),this.skipSC()),this.tokenType){case $:this.next();break;case G:i=hasOwnProperty.call(this.atrule,r)&&"function"==typeof this.atrule[r].block?this.atrule[r].block.call(this,e):this.Block(_o.call(this))}return{type:"Atrule",loc:this.getLocation(t,this.tokenStart),name:n,prelude:o,block:i}}var ko=Object.freeze({__proto__:null,generate:function(e){this.token(z,"@"+e.name),null!==e.prelude&&this.node(e.prelude),e.block?this.node(e.block):this.token($,";")},name:"Atrule",parse:wo,structure:vo,walkContext:"atrule"});function xo(e){let t=null;return null!==e&&(e=e.toLowerCase()),this.skipSC(),t=hasOwnProperty.call(this.atrule,e)&&"function"==typeof this.atrule[e].prelude?this.atrule[e].prelude.call(this):this.readSequence(this.scope.AtrulePrelude),this.skipSC(),!0!==this.eof&&this.tokenType!==G&&this.tokenType!==$&&this.error("Semicolon or block is expected"),{type:"AtrulePrelude",loc:this.getLocationFromList(t),children:t}}var So=Object.freeze({__proto__:null,generate:function(e){this.children(e)},name:"AtrulePrelude",parse:xo,structure:{children:[[]]},walkContext:"atrulePrelude"});const Oo=36,Ao=42,Eo=61,Co=94,Po=124,Lo=126;function zo(){this.eof&&this.error("Unexpected end of input");const e=this.tokenStart;let t=!1;return this.isDelim(Ao)?(t=!0,this.next()):this.isDelim(Po)||this.eat(P),this.isDelim(Po)?this.charCodeAt(this.tokenStart+1)!==Eo?(this.next(),this.eat(P)):t&&this.error("Identifier is expected",this.tokenEnd):t&&this.error("Vertical line is expected"),{type:"Identifier",loc:this.getLocation(e,this.tokenStart),name:this.substrToCursor(e)}}function No(){const e=this.tokenStart,t=this.charCodeAt(e);return t!==Eo&&t!==Lo&&t!==Co&&t!==Oo&&t!==Ao&&t!==Po&&this.error("Attribute selector (=, ~=, ^=, $=, *=, |=) is expected"),this.next(),t!==Eo&&(this.isDelim(Eo)||this.error("Equal sign is expected"),this.next()),this.substrToCursor(e)}const To={name:"Identifier",matcher:[String,null],value:["String","Identifier",null],flags:[String,null]};function jo(){const e=this.tokenStart;let t,n=null,r=null,o=null;return this.eat(q),this.skipSC(),t=zo.call(this),this.skipSC(),this.tokenType!==H&&(this.tokenType!==P&&(n=No.call(this),this.skipSC(),r=this.tokenType===T?this.String():this.Identifier(),this.skipSC()),this.tokenType===P&&(o=this.consume(P),this.skipSC())),this.eat(H),{type:"AttributeSelector",loc:this.getLocation(e,this.tokenStart),name:t,matcher:n,value:r,flags:o}}var Io=Object.freeze({__proto__:null,generate:function(e){this.token(D,"["),this.node(e.name),null!==e.matcher&&(this.tokenize(e.matcher),this.node(e.value)),null!==e.flags&&this.token(P,e.flags),this.token(D,"]")},name:"AttributeSelector",parse:jo,structure:To});function Ro(){return this.Raw(null,!0)}function Do(){return this.parseWithFallback(this.Rule,Ro)}function Mo(){return this.Raw(this.consumeUntilSemicolonIncluded,!0)}function Bo(){if(this.tokenType===$)return Mo.call(this,this.tokenIndex);const e=this.parseWithFallback(this.Declaration,Mo);return this.tokenType===$&&this.next(),e}function Wo(e){const t=e?Bo:Do,n=this.tokenStart;let r=this.createList();this.eat(G);e:for(;!this.eof;)switch(this.tokenType){case X:break e;case J:case Q:this.next();break;case z:r.push(this.parseWithFallback(this.Atrule.bind(this,e),Ro));break;default:e&&this.isDelim(38)?r.push(Do.call(this)):r.push(t.call(this))}return this.eof||this.eat(X),{type:"Block",loc:this.getLocation(n,this.tokenStart),children:r}}var Jo=Object.freeze({__proto__:null,generate:function(e){this.token(G,"{"),this.children(e,(e=>{"Declaration"===e.type&&this.token($,";")})),this.token(X,"}")},name:"Block",parse:Wo,structure:{children:[["Atrule","Rule","Declaration"]]},walkContext:"block"});function Fo(e,t){const n=this.tokenStart;let r=null;return this.eat(q),r=e.call(this,t),this.eof||this.eat(H),{type:"Brackets",loc:this.getLocation(n,this.tokenStart),children:r}}var Yo=Object.freeze({__proto__:null,generate:function(e){this.token(D,"["),this.children(e),this.token(D,"]")},name:"Brackets",parse:Fo,structure:{children:[[]]}});function Uo(){const e=this.tokenStart;return this.eat(Y),{type:"CDC",loc:this.getLocation(e,this.tokenStart)}}var $o=Object.freeze({__proto__:null,generate:function(){this.token(Y,"--\x3e")},name:"CDC",parse:Uo,structure:[]});function Vo(){const e=this.tokenStart;return this.eat(F),{type:"CDO",loc:this.getLocation(e,this.tokenStart)}}var qo=Object.freeze({__proto__:null,generate:function(){this.token(F,"\x3c!--")},name:"CDO",parse:Vo,structure:[]});const Ho={name:String};function Zo(){return this.eatDelim(46),{type:"ClassSelector",loc:this.getLocation(this.tokenStart-1,this.tokenEnd),name:this.consume(P)}}var Ko=Object.freeze({__proto__:null,generate:function(e){this.token(D,"."),this.token(P,e.name)},name:"ClassSelector",parse:Zo,structure:Ho});const Go={name:String};function Xo(){const e=this.tokenStart;let t;switch(this.tokenType){case J:t=" ";break;case D:switch(this.charCodeAt(this.tokenStart)){case 62:case 43:case 126:this.next();break;case 47:this.next(),this.eatIdent("deep"),this.eatDelim(47);break;default:this.error("Combinator is expected")}t=this.substrToCursor(e)}return{type:"Combinator",loc:this.getLocation(e,this.tokenStart),name:t}}var Qo=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.name)},name:"Combinator",parse:Xo,structure:Go});const ei={value:String};function ti(){const e=this.tokenStart;let t=this.tokenEnd;return this.eat(Q),t-e+2>=2&&42===this.charCodeAt(t-2)&&47===this.charCodeAt(t-1)&&(t-=2),{type:"Comment",loc:this.getLocation(e,this.tokenStart),value:this.substring(e+2,t)}}var ni=Object.freeze({__proto__:null,generate:function(e){this.token(Q,"/*"+e.value+"*/")},name:"Comment",parse:ti,structure:ei});const ri=new Set([U,K,0]),oi={kind:String,children:[["Identifier","Feature","FeatureFunction","FeatureRange","SupportsDeclaration"]]};function ii(e){return this.lookupTypeNonSC(1)===P&&ri.has(this.lookupTypeNonSC(2))?this.Feature(e):this.FeatureRange(e)}const ai={media:ii,container:ii,supports(){return this.SupportsDeclaration()}};function si(e="media"){const t=this.createList();e:for(;!this.eof;)switch(this.tokenType){case Q:case J:this.next();continue;case P:t.push(this.Identifier());break;case Z:{let n=this.parseWithFallback((()=>ai[e].call(this,e)),(()=>null));n||(n=this.parseWithFallback((()=>{this.eat(Z);const t=this.Condition(e);return this.eat(K),t}),(()=>this.GeneralEnclosed(e)))),t.push(n);break}case L:{let n=this.parseWithFallback((()=>this.FeatureFunction(e)),(()=>null));n||(n=this.GeneralEnclosed(e)),t.push(n);break}default:break e}return t.isEmpty&&this.error("Condition is expected"),{type:"Condition",loc:this.getLocationFromList(t),kind:e,children:t}}var li=Object.freeze({__proto__:null,generate:function(e){e.children.forEach((e=>{"Condition"===e.type?(this.token(Z,"("),this.node(e),this.token(K,")")):this.node(e)}))},name:"Condition",parse:si,structure:oi});const ci=33,ui=35,di=36,hi=38,pi=42,fi=43,mi=47;function gi(){return this.Raw(this.consumeUntilExclamationMarkOrSemicolon,!0)}function yi(){return this.Raw(this.consumeUntilExclamationMarkOrSemicolon,!1)}function bi(){const e=this.tokenIndex,t=this.Value();return"Raw"!==t.type&&!1===this.eof&&this.tokenType!==$&&!1===this.isDelim(ci)&&!1===this.isBalanceEdge(e)&&this.error(),t}const _i={important:[Boolean,String],property:String,value:["Value","Raw"]};function vi(){const e=this.tokenStart,t=this.tokenIndex,n=wi.call(this),r=en(n),o=r?this.parseCustomProperty:this.parseValue,i=r?yi:gi;let a,s=!1;this.skipSC(),this.eat(U);const l=this.tokenIndex;if(r||this.skipSC(),a=o?this.parseWithFallback(bi,i):i.call(this,this.tokenIndex),r&&"Value"===a.type&&a.children.isEmpty)for(let e=l-this.tokenIndex;e<=0;e++)if(this.lookupType(e)===J){a.children.appendData({type:"WhiteSpace",loc:null,value:" "});break}return this.isDelim(ci)&&(s=ki.call(this),this.skipSC()),!1===this.eof&&this.tokenType!==$&&!1===this.isBalanceEdge(t)&&this.error(),{type:"Declaration",loc:this.getLocation(e,this.tokenStart),important:s,property:n,value:a}}function wi(){const e=this.tokenStart;if(this.tokenType===D)switch(this.charCodeAt(this.tokenStart)){case pi:case di:case fi:case ui:case hi:this.next();break;case mi:this.next(),this.isDelim(mi)&&this.next()}return this.tokenType===N?this.eat(N):this.eat(P),this.substrToCursor(e)}function ki(){this.eat(D),this.skipSC();const e=this.consume(P);return"important"===e||e}var xi=Object.freeze({__proto__:null,generate:function(e){this.token(P,e.property),this.token(U,":"),this.node(e.value),e.important&&(this.token(D,"!"),this.token(P,!0===e.important?"important":e.important))},name:"Declaration",parse:vi,structure:_i,walkContext:"declaration"});function Si(){return this.Raw(this.consumeUntilSemicolonIncluded,!0)}function Oi(){const e=this.createList();for(;!this.eof;)switch(this.tokenType){case J:case Q:case $:this.next();break;case z:e.push(this.parseWithFallback(this.Atrule.bind(this,!0),Si));break;default:this.isDelim(38)?e.push(this.parseWithFallback(this.Rule,Si)):e.push(this.parseWithFallback(this.Declaration,Si))}return{type:"DeclarationList",loc:this.getLocationFromList(e),children:e}}var Ai=Object.freeze({__proto__:null,generate:function(e){this.children(e,(e=>{"Declaration"===e.type&&this.token($,";")}))},name:"DeclarationList",parse:Oi,structure:{children:[["Declaration","Atrule","Rule"]]}});const Ei={value:String,unit:String};function Ci(){const e=this.tokenStart,t=this.consumeNumber(W);return{type:"Dimension",loc:this.getLocation(e,this.tokenStart),value:t,unit:this.substring(e+t.length,this.tokenStart)}}var Pi=Object.freeze({__proto__:null,generate:function(e){this.token(W,e.value+e.unit)},name:"Dimension",parse:Ci,structure:Ei});const Li={kind:String,name:String,value:["Identifier","Number","Dimension","Ratio","Function",null]};function zi(e){const t=this.tokenStart;let n,r=null;if(this.eat(Z),this.skipSC(),n=this.consume(P),this.skipSC(),this.tokenType!==K){switch(this.eat(U),this.skipSC(),this.tokenType){case M:r=this.lookupNonWSType(1)===D?this.Ratio():this.Number();break;case W:r=this.Dimension();break;case P:r=this.Identifier();break;case L:r=this.parseWithFallback((()=>{const e=this.Function(this.readSequence,this.scope.Value);return this.skipSC(),this.isDelim(47)&&this.error(),e}),(()=>this.Ratio()));break;default:this.error("Number, dimension, ratio or identifier is expected")}this.skipSC()}return this.eof||this.eat(K),{type:"Feature",loc:this.getLocation(t,this.tokenStart),kind:e,name:n,value:r}}var Ni=Object.freeze({__proto__:null,generate:function(e){this.token(Z,"("),this.token(P,e.name),null!==e.value&&(this.token(U,":"),this.node(e.value)),this.token(K,")")},name:"Feature",parse:zi,structure:Li});const Ti={kind:String,feature:String,value:["Declaration","Selector"]};function ji(e,t){const n=(this.features[e]||{})[t];return"function"!=typeof n&&this.error(`Unknown feature ${t}()`),n}function Ii(e="unknown"){const t=this.tokenStart,n=this.consumeFunctionName(),r=ji.call(this,e,n.toLowerCase());this.skipSC();const o=this.parseWithFallback((()=>{const e=this.tokenIndex,t=r.call(this);return!1===this.eof&&!1===this.isBalanceEdge(e)&&this.error(),t}),(()=>this.Raw(null,!1)));return this.eof||this.eat(K),{type:"FeatureFunction",loc:this.getLocation(t,this.tokenStart),kind:e,feature:n,value:o}}var Ri=Object.freeze({__proto__:null,generate:function(e){this.token(L,e.feature+"("),this.node(e.value),this.token(K,")")},name:"FeatureFunction",parse:Ii,structure:Ti});const Di=47,Mi=60,Bi=61,Wi=62,Ji={kind:String,left:["Identifier","Number","Dimension","Ratio","Function"],leftComparison:String,middle:["Identifier","Number","Dimension","Ratio","Function"],rightComparison:[String,null],right:["Identifier","Number","Dimension","Ratio","Function",null]};function Fi(){switch(this.skipSC(),this.tokenType){case M:return this.isDelim(Di,this.lookupOffsetNonSC(1))?this.Ratio():this.Number();case W:return this.Dimension();case P:return this.Identifier();case L:return this.parseWithFallback((()=>{const e=this.Function(this.readSequence,this.scope.Value);return this.skipSC(),this.isDelim(Di)&&this.error(),e}),(()=>this.Ratio()));default:this.error("Number, dimension, ratio or identifier is expected")}}function Yi(e){if(this.skipSC(),this.isDelim(Mi)||this.isDelim(Wi)){const e=this.source[this.tokenStart];return this.next(),this.isDelim(Bi)?(this.next(),e+"="):e}if(this.isDelim(Bi))return"=";this.error(`Expected ${e?'":", ':""}"<", ">", "=" or ")"`)}function Ui(e="unknown"){const t=this.tokenStart;this.skipSC(),this.eat(Z);const n=Fi.call(this),r=Yi.call(this,"Identifier"===n.type),o=Fi.call(this);let i=null,a=null;return this.lookupNonWSType(0)!==K&&(i=Yi.call(this),a=Fi.call(this)),this.skipSC(),this.eat(K),{type:"FeatureRange",loc:this.getLocation(t,this.tokenStart),kind:e,left:n,leftComparison:r,middle:o,rightComparison:i,right:a}}var $i=Object.freeze({__proto__:null,generate:function(e){this.token(Z,"("),this.node(e.left),this.tokenize(e.leftComparison),this.node(e.middle),e.right&&(this.tokenize(e.rightComparison),this.node(e.right)),this.token(K,")")},name:"FeatureRange",parse:Ui,structure:Ji});const Vi={name:String,children:[[]]};function qi(e,t){const n=this.tokenStart,r=this.consumeFunctionName(),o=r.toLowerCase();let i;return i=t.hasOwnProperty(o)?t[o].call(this,t):e.call(this,t),this.eof||this.eat(K),{type:"Function",loc:this.getLocation(n,this.tokenStart),name:r,children:i}}var Hi=Object.freeze({__proto__:null,generate:function(e){this.token(L,e.name+"("),this.children(e),this.token(K,")")},name:"Function",parse:qi,structure:Vi,walkContext:"function"});const Zi={kind:String,function:[String,null],children:[[]]};function Ki(e){const t=this.tokenStart;let n=null;this.tokenType===L?n=this.consumeFunctionName():this.eat(Z);const r=this.parseWithFallback((()=>{const e=this.tokenIndex,t=this.readSequence(this.scope.Value);return!1===this.eof&&!1===this.isBalanceEdge(e)&&this.error(),t}),(()=>this.createSingleNodeList(this.Raw(null,!1))));return this.eof||this.eat(K),{type:"GeneralEnclosed",loc:this.getLocation(t,this.tokenStart),kind:e,function:n,children:r}}var Gi=Object.freeze({__proto__:null,generate:function(e){e.function?this.token(L,e.function+"("):this.token(Z,"("),this.children(e),this.token(K,")")},name:"GeneralEnclosed",parse:Ki,structure:Zi});const Xi={value:String};function Qi(){const e=this.tokenStart;return this.eat(N),{type:"Hash",loc:this.getLocation(e,this.tokenStart),value:this.substrToCursor(e+1)}}var ea=Object.freeze({__proto__:null,generate:function(e){this.token(N,"#"+e.value)},name:"Hash",parse:Qi,structure:Xi,xxx:"XXX"});const ta={name:String};function na(){return{type:"Identifier",loc:this.getLocation(this.tokenStart,this.tokenEnd),name:this.consume(P)}}var ra=Object.freeze({__proto__:null,generate:function(e){this.token(P,e.name)},name:"Identifier",parse:na,structure:ta});const oa={name:String};function ia(){const e=this.tokenStart;return this.eat(N),{type:"IdSelector",loc:this.getLocation(e,this.tokenStart),name:this.substrToCursor(e+1)}}var aa=Object.freeze({__proto__:null,generate:function(e){this.token(D,"#"+e.name)},name:"IdSelector",parse:ia,structure:oa});const sa={name:String};function la(){let e=this.tokenStart,t=this.consume(P);for(;this.isDelim(46);)this.eat(D),t+="."+this.consume(P);return{type:"Layer",loc:this.getLocation(e,this.tokenStart),name:t}}var ca=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.name)},name:"Layer",parse:la,structure:sa});function ua(){const e=this.createList();for(this.skipSC();!this.eof&&(e.push(this.Layer()),this.lookupTypeNonSC(0)===V);)this.skipSC(),this.next(),this.skipSC();return{type:"LayerList",loc:this.getLocationFromList(e),children:e}}var da=Object.freeze({__proto__:null,generate:function(e){this.children(e,(()=>this.token(V,",")))},name:"LayerList",parse:ua,structure:{children:[["Layer"]]}});const ha={modifier:[String,null],mediaType:[String,null],condition:["Condition",null]};function pa(){const e=this.tokenStart;let t=null,n=null,r=null;if(this.skipSC(),this.tokenType===P&&this.lookupTypeNonSC(1)!==Z){const e=this.consume(P),o=e.toLowerCase();switch("not"===o||"only"===o?(this.skipSC(),t=o,n=this.consume(P)):n=e,this.lookupTypeNonSC(0)){case P:this.skipSC(),this.eatIdent("and"),r=this.Condition("media");break;case G:case $:case V:case 0:break;default:this.error("Identifier or parenthesis is expected")}}else switch(this.tokenType){case P:case Z:case L:r=this.Condition("media");break;case G:case $:case 0:break;default:this.error("Identifier or parenthesis is expected")}return{type:"MediaQuery",loc:this.getLocation(e,this.tokenStart),modifier:t,mediaType:n,condition:r}}var fa=Object.freeze({__proto__:null,generate:function(e){e.mediaType?(e.modifier&&this.token(P,e.modifier),this.token(P,e.mediaType),e.condition&&(this.token(P,"and"),this.node(e.condition))):e.condition&&this.node(e.condition)},name:"MediaQuery",parse:pa,structure:ha});function ma(){const e=this.createList();for(this.skipSC();!this.eof&&(e.push(this.MediaQuery()),this.tokenType===V);)this.next();return{type:"MediaQueryList",loc:this.getLocationFromList(e),children:e}}var ga=Object.freeze({__proto__:null,generate:function(e){this.children(e,(()=>this.token(V,",")))},name:"MediaQueryList",parse:ma,structure:{children:[["MediaQuery"]]}});function ya(){const e=this.tokenStart;return this.eatDelim(38),{type:"NestingSelector",loc:this.getLocation(e,this.tokenStart)}}var ba=Object.freeze({__proto__:null,generate:function(){this.token(D,"&")},name:"NestingSelector",parse:ya,structure:{}});function _a(){this.skipSC();const e=this.tokenStart;let t,n=e,r=null;return t=this.lookupValue(0,"odd")||this.lookupValue(0,"even")?this.Identifier():this.AnPlusB(),n=this.tokenStart,this.skipSC(),this.lookupValue(0,"of")&&(this.next(),r=this.SelectorList(),n=this.tokenStart),{type:"Nth",loc:this.getLocation(e,n),nth:t,selector:r}}var va=Object.freeze({__proto__:null,generate:function(e){this.node(e.nth),null!==e.selector&&(this.token(P,"of"),this.node(e.selector))},name:"Nth",parse:_a,structure:{nth:["AnPlusB","Identifier"],selector:["SelectorList",null]}});const wa={value:String};function ka(){return{type:"Number",loc:this.getLocation(this.tokenStart,this.tokenEnd),value:this.consume(M)}}var xa=Object.freeze({__proto__:null,generate:function(e){this.token(M,e.value)},name:"Number",parse:ka,structure:wa});const Sa={value:String};function Oa(){const e=this.tokenStart;return this.next(),{type:"Operator",loc:this.getLocation(e,this.tokenStart),value:this.substrToCursor(e)}}var Aa=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.value)},name:"Operator",parse:Oa,structure:Sa});function Ea(e,t){const n=this.tokenStart;let r=null;return this.eat(Z),r=e.call(this,t),this.eof||this.eat(K),{type:"Parentheses",loc:this.getLocation(n,this.tokenStart),children:r}}var Ca=Object.freeze({__proto__:null,generate:function(e){this.token(Z,"("),this.children(e),this.token(K,")")},name:"Parentheses",parse:Ea,structure:{children:[[]]}});const Pa={value:String};function La(){return{type:"Percentage",loc:this.getLocation(this.tokenStart,this.tokenEnd),value:this.consumeNumber(B)}}var za=Object.freeze({__proto__:null,generate:function(e){this.token(B,e.value+"%")},name:"Percentage",parse:La,structure:Pa});const Na={name:String,children:[["Raw"],null]};function Ta(){const e=this.tokenStart;let t,n,r=null;return this.eat(U),this.tokenType===L?(t=this.consumeFunctionName(),n=t.toLowerCase(),this.lookupNonWSType(0)==K?r=this.createList():hasOwnProperty.call(this.pseudo,n)?(this.skipSC(),r=this.pseudo[n].call(this),this.skipSC()):(r=this.createList(),r.push(this.Raw(null,!1))),this.eat(K)):t=this.consume(P),{type:"PseudoClassSelector",loc:this.getLocation(e,this.tokenStart),name:t,children:r}}var ja=Object.freeze({__proto__:null,generate:function(e){this.token(U,":"),null===e.children?this.token(P,e.name):(this.token(L,e.name+"("),this.children(e),this.token(K,")"))},name:"PseudoClassSelector",parse:Ta,structure:Na,walkContext:"function"});const Ia={name:String,children:[["Raw"],null]};function Ra(){const e=this.tokenStart;let t,n,r=null;return this.eat(U),this.eat(U),this.tokenType===L?(t=this.consumeFunctionName(),n=t.toLowerCase(),this.lookupNonWSType(0)==K?r=this.createList():hasOwnProperty.call(this.pseudo,n)?(this.skipSC(),r=this.pseudo[n].call(this),this.skipSC()):(r=this.createList(),r.push(this.Raw(null,!1))),this.eat(K)):t=this.consume(P),{type:"PseudoElementSelector",loc:this.getLocation(e,this.tokenStart),name:t,children:r}}var Da=Object.freeze({__proto__:null,generate:function(e){this.token(U,":"),this.token(U,":"),null===e.children?this.token(P,e.name):(this.token(L,e.name+"("),this.children(e),this.token(K,")"))},name:"PseudoElementSelector",parse:Ra,structure:Ia,walkContext:"function"});function Ma(){switch(this.skipSC(),this.tokenType){case M:return this.Number();case L:return this.Function(this.readSequence,this.scope.Value);default:this.error("Number of function is expected")}}function Ba(){const e=this.tokenStart,t=Ma.call(this);let n=null;return this.skipSC(),this.isDelim(47)&&(this.eatDelim(47),n=Ma.call(this)),{type:"Ratio",loc:this.getLocation(e,this.tokenStart),left:t,right:n}}var Wa=Object.freeze({__proto__:null,generate:function(e){this.node(e.left),this.token(D,"/"),e.right?this.node(e.right):this.node(M,1)},name:"Ratio",parse:Ba,structure:{left:["Number","Function"],right:["Number","Function",null]}});function Ja(){return this.tokenIndex>0&&this.lookupType(-1)===J?this.tokenIndex>1?this.getTokenStart(this.tokenIndex-1):this.firstCharOffset:this.tokenStart}const Fa={value:String};function Ya(e,t){const n=this.getTokenStart(this.tokenIndex);let r;return this.skipUntilBalanced(this.tokenIndex,e||this.consumeUntilBalanceEnd),r=t&&this.tokenStart>n?Ja.call(this):this.tokenStart,{type:"Raw",loc:this.getLocation(n,r),value:this.substring(n,r)}}var Ua=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.value)},name:"Raw",parse:Ya,structure:Fa});function $a(){return this.Raw(this.consumeUntilLeftCurlyBracket,!0)}function Va(){const e=this.SelectorList();return"Raw"!==e.type&&!1===this.eof&&this.tokenType!==G&&this.error(),e}function qa(){const e=this.tokenIndex,t=this.tokenStart;let n,r;return n=this.parseRulePrelude?this.parseWithFallback(Va,$a):$a.call(this,e),r=this.Block(!0),{type:"Rule",loc:this.getLocation(t,this.tokenStart),prelude:n,block:r}}var Ha=Object.freeze({__proto__:null,generate:function(e){this.node(e.prelude),this.node(e.block)},name:"Rule",parse:qa,structure:{prelude:["SelectorList","Raw"],block:["Block"]},walkContext:"rule"});function Za(){let e=null,t=null;this.skipSC();const n=this.tokenStart;return this.tokenType===Z&&(this.next(),this.skipSC(),e=this.parseWithFallback(this.SelectorList,(()=>this.Raw(!1,!0))),this.skipSC(),this.eat(K)),this.lookupNonWSType(0)===P&&(this.skipSC(),this.eatIdent("to"),this.skipSC(),this.eat(Z),this.skipSC(),t=this.parseWithFallback(this.SelectorList,(()=>this.Raw(!1,!0))),this.skipSC(),this.eat(K)),{type:"Scope",loc:this.getLocation(n,this.tokenStart),root:e,limit:t}}var Ka=Object.freeze({__proto__:null,generate:function(e){e.root&&(this.token(Z,"("),this.node(e.root),this.token(K,")")),e.limit&&(this.token(P,"to"),this.token(Z,"("),this.node(e.limit),this.token(K,")"))},name:"Scope",parse:Za,structure:{root:["SelectorList","Raw",null],limit:["SelectorList","Raw",null]}});function Ga(){const e=this.readSequence(this.scope.Selector);return null===this.getFirstListNode(e)&&this.error("Selector is expected"),{type:"Selector",loc:this.getLocationFromList(e),children:e}}var Xa=Object.freeze({__proto__:null,generate:function(e){this.children(e)},name:"Selector",parse:Ga,structure:{children:[["TypeSelector","IdSelector","ClassSelector","AttributeSelector","PseudoClassSelector","PseudoElementSelector","Combinator"]]}});function Qa(){const e=this.createList();for(;!this.eof&&(e.push(this.Selector()),this.tokenType===V);)this.next();return{type:"SelectorList",loc:this.getLocationFromList(e),children:e}}var es=Object.freeze({__proto__:null,generate:function(e){this.children(e,(()=>this.token(V,",")))},name:"SelectorList",parse:Qa,structure:{children:[["Selector","Raw"]]},walkContext:"selector"});const ts=92,ns=34,rs=39;function os(e){const t=e.length,n=e.charCodeAt(0),r=n===ns||n===rs?1:0,o=1===r&&t>1&&e.charCodeAt(t-1)===n?t-2:t-1;let i="";for(let n=r;n<=o;n++){let r=e.charCodeAt(n);if(r===ts){if(n===o){n!==t-1&&(i=e.substr(n+1));break}if(r=e.charCodeAt(++n),ce(ts,r)){const t=n-1,r=Oe(e,t);n=r-1,i+=Pe(e.substring(t+1,r))}else 13===r&&10===e.charCodeAt(n+1)&&n++}else i+=e[n]}return i}const is={value:String};function as(){return{type:"String",loc:this.getLocation(this.tokenStart,this.tokenEnd),value:os(this.consume(T))}}var ss=Object.freeze({__proto__:null,generate:function(e){this.token(T,function(e,t){const n=ns;let r="",o=!1;for(let t=0;t<e.length;t++){const i=e.charCodeAt(t);0!==i?i<=31||127===i?(r+="\\"+i.toString(16),o=!0):i===n||i===ts?(r+="\\"+e.charAt(t),o=!1):(o&&(ne(i)||le(i))&&(r+=" "),r+=e.charAt(t),o=!1):r+="�"}return'"'+r+'"'}(e.value))},name:"String",parse:as,structure:is});function ls(){return this.Raw(null,!1)}function cs(){const e=this.tokenStart,t=this.createList();let n;for(;!this.eof;){switch(this.tokenType){case J:this.next();continue;case Q:if(33!==this.charCodeAt(this.tokenStart+2)){this.next();continue}n=this.Comment();break;case F:n=this.CDO();break;case Y:n=this.CDC();break;case z:n=this.parseWithFallback(this.Atrule,ls);break;default:n=this.parseWithFallback(this.Rule,ls)}t.push(n)}return{type:"StyleSheet",loc:this.getLocation(e,this.tokenStart),children:t}}var us=Object.freeze({__proto__:null,generate:function(e){this.children(e)},name:"StyleSheet",parse:cs,structure:{children:[["Comment","CDO","CDC","Atrule","Rule","Raw"]]},walkContext:"stylesheet"});function ds(){const e=this.tokenStart;this.eat(Z),this.skipSC();const t=this.Declaration();return this.eof||this.eat(K),{type:"SupportsDeclaration",loc:this.getLocation(e,this.tokenStart),declaration:t}}var hs=Object.freeze({__proto__:null,generate:function(e){this.token(Z,"("),this.node(e.declaration),this.token(K,")")},name:"SupportsDeclaration",parse:ds,structure:{declaration:"Declaration"}});const ps=42;function fs(){this.tokenType!==P&&!1===this.isDelim(ps)&&this.error("Identifier or asterisk is expected"),this.next()}const ms={name:String};function gs(){const e=this.tokenStart;return this.isDelim(124)?(this.next(),fs.call(this)):(fs.call(this),this.isDelim(124)&&(this.next(),fs.call(this))),{type:"TypeSelector",loc:this.getLocation(e,this.tokenStart),name:this.substrToCursor(e)}}var ys=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.name)},name:"TypeSelector",parse:gs,structure:ms});const bs=43,_s=45,vs=63;function ws(e,t){let n=0;for(let r=this.tokenStart+e;r<this.tokenEnd;r++){const o=this.charCodeAt(r);if(o===_s&&t&&0!==n)return ws.call(this,e+n+1,!1),-1;ne(o)||this.error(t&&0!==n?"Hyphen minus"+(n<6?" or hex digit":"")+" is expected":n<6?"Hex digit is expected":"Unexpected input",r),++n>6&&this.error("Too many hex digits",r)}return this.next(),n}function ks(e){let t=0;for(;this.isDelim(vs);)++t>e&&this.error("Too many question marks"),this.next()}function xs(e){this.charCodeAt(this.tokenStart)!==e&&this.error((e===bs?"Plus sign":"Hyphen minus")+" is expected")}function Ss(){let e=0;switch(this.tokenType){case M:if(e=ws.call(this,1,!0),this.isDelim(vs)){ks.call(this,6-e);break}if(this.tokenType===W||this.tokenType===M){xs.call(this,_s),ws.call(this,1,!1);break}break;case W:e=ws.call(this,1,!0),e>0&&ks.call(this,6-e);break;default:if(this.eatDelim(bs),this.tokenType===P){e=ws.call(this,0,!0),e>0&&ks.call(this,6-e);break}if(this.isDelim(vs)){this.next(),ks.call(this,5);break}this.error("Hex digit or question mark is expected")}}const Os={value:String};function As(){const e=this.tokenStart;return this.eatIdent("u"),Ss.call(this),{type:"UnicodeRange",loc:this.getLocation(e,this.tokenStart),value:this.substrToCursor(e)}}var Es=Object.freeze({__proto__:null,generate:function(e){this.tokenize(e.value)},name:"UnicodeRange",parse:As,structure:Os});const Cs={value:String};function Ps(){const e=this.tokenStart;let t;switch(this.tokenType){case I:t=function(e){const t=e.length;let n=4,r=41===e.charCodeAt(t-1)?t-2:t-1,o="";for(;n<r&&le(e.charCodeAt(n));)n++;for(;n<r&&le(e.charCodeAt(r));)r--;for(let i=n;i<=r;i++){let n=e.charCodeAt(i);if(92===n){if(i===r){i!==t-1&&(o=e.substr(i+1));break}if(n=e.charCodeAt(++i),ce(92,n)){const t=i-1,n=Oe(e,t);i=n-1,o+=Pe(e.substring(t+1,n))}else 13===n&&10===e.charCodeAt(i+1)&&i++}else o+=e[i]}return o}(this.consume(I));break;case L:this.cmpStr(this.tokenStart,this.tokenEnd,"url(")||this.error("Function name must be `url`"),this.eat(L),this.skipSC(),t=os(this.consume(T)),this.skipSC(),this.eof||this.eat(K);break;default:this.error("Url or Function is expected")}return{type:"Url",loc:this.getLocation(e,this.tokenStart),value:t}}var Ls=Object.freeze({__proto__:null,generate:function(e){this.token(I,function(e){let t="",n=!1;for(let r=0;r<e.length;r++){const o=e.charCodeAt(r);0!==o?o<=31||127===o?(t+="\\"+o.toString(16),n=!0):32===o||92===o||34===o||39===o||40===o||41===o?(t+="\\"+e.charAt(r),n=!1):(n&&ne(o)&&(t+=" "),t+=e.charAt(r),n=!1):t+="�"}return"url("+t+")"}(e.value))},name:"Url",parse:Ps,structure:Cs});function zs(){const e=this.tokenStart,t=this.readSequence(this.scope.Value);return{type:"Value",loc:this.getLocation(e,this.tokenStart),children:t}}var Ns=Object.freeze({__proto__:null,generate:function(e){this.children(e)},name:"Value",parse:zs,structure:{children:[[]]}});const Ts=Object.freeze({type:"WhiteSpace",loc:null,value:" "}),js={value:String};function Is(){return this.eat(J),Ts}var Rs=Object.freeze({__proto__:null,generate:function(e){this.token(J,e.value)},name:"WhiteSpace",parse:Is,structure:js}),Ds=Object.freeze({__proto__:null,AnPlusB:yo,Atrule:ko,AtrulePrelude:So,AttributeSelector:Io,Block:Jo,Brackets:Yo,CDC:$o,CDO:qo,ClassSelector:Ko,Combinator:Qo,Comment:ni,Condition:li,Declaration:xi,DeclarationList:Ai,Dimension:Pi,Feature:Ni,FeatureFunction:Ri,FeatureRange:$i,Function:Hi,GeneralEnclosed:Gi,Hash:ea,IdSelector:aa,Identifier:ra,Layer:ca,LayerList:da,MediaQuery:fa,MediaQueryList:ga,NestingSelector:ba,Nth:va,Number:xa,Operator:Aa,Parentheses:Ca,Percentage:za,PseudoClassSelector:ja,PseudoElementSelector:Da,Ratio:Wa,Raw:Ua,Rule:Ha,Scope:Ka,Selector:Xa,SelectorList:es,String:ss,StyleSheet:us,SupportsDeclaration:hs,TypeSelector:ys,UnicodeRange:Es,Url:Ls,Value:Ns,WhiteSpace:Rs}),Ms={generic:!0,cssWideKeywords:nn,generic:!0,cssWideKeywords:["initial","inherit","unset","revert","revert-layer"],units:{angle:["deg","grad","rad","turn"],decibel:["db"],flex:["fr"],frequency:["hz","khz"],length:["cm","mm","q","in","pt","pc","px","em","rem","ex","rex","cap","rcap","ch","rch","ic","ric","lh","rlh","vw","svw","lvw","dvw","vh","svh","lvh","dvh","vi","svi","lvi","dvi","vb","svb","lvb","dvb","vmin","svmin","lvmin","dvmin","vmax","svmax","lvmax","dvmax","cqw","cqh","cqi","cqb","cqmin","cqmax"],resolution:["dpi","dpcm","dppx","x"],semitones:["st"],time:["s","ms"]},types:{"abs()":"abs( <calc-sum> )","absolute-size":"xx-small|x-small|small|medium|large|x-large|xx-large|xxx-large","acos()":"acos( <calc-sum> )","alpha-value":"<number>|<percentage>","angle-percentage":"<angle>|<percentage>","angular-color-hint":"<angle-percentage>","angular-color-stop":"<color>&&<color-stop-angle>?","angular-color-stop-list":"[<angular-color-stop> [, <angular-color-hint>]?]# , <angular-color-stop>","animateable-feature":"scroll-position|contents|<custom-ident>","asin()":"asin( <calc-sum> )","atan()":"atan( <calc-sum> )","atan2()":"atan2( <calc-sum> , <calc-sum> )",attachment:"scroll|fixed|local","attr()":"attr( <attr-name> <type-or-unit>? [, <attr-fallback>]? )","attr-matcher":"['~'|'|'|'^'|'$'|'*']? '='","attr-modifier":"i|s","attribute-selector":"'[' <wq-name> ']'|'[' <wq-name> <attr-matcher> [<string-token>|<ident-token>] <attr-modifier>? ']'","auto-repeat":"repeat( [auto-fill|auto-fit] , [<line-names>? <fixed-size>]+ <line-names>? )","auto-track-list":"[<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>? <auto-repeat> [<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>?",axis:"block|inline|x|y","baseline-position":"[first|last]? baseline","basic-shape":"<inset()>|<xywh()>|<rect()>|<circle()>|<ellipse()>|<polygon()>|<path()>","bg-image":"none|<image>","bg-layer":"<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>","bg-position":"[[left|center|right|top|bottom|<length-percentage>]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]|[center|[left|right] <length-percentage>?]&&[center|[top|bottom] <length-percentage>?]]","bg-size":"[<length-percentage>|auto]{1,2}|cover|contain","blur()":"blur( <length> )","blend-mode":"normal|multiply|screen|overlay|darken|lighten|color-dodge|color-burn|hard-light|soft-light|difference|exclusion|hue|saturation|color|luminosity",box:"border-box|padding-box|content-box","brightness()":"brightness( <number-percentage> )","calc()":"calc( <calc-sum> )","calc-sum":"<calc-product> [['+'|'-'] <calc-product>]*","calc-product":"<calc-value> ['*' <calc-value>|'/' <number>]*","calc-value":"<number>|<dimension>|<percentage>|<calc-constant>|( <calc-sum> )","calc-constant":"e|pi|infinity|-infinity|NaN","cf-final-image":"<image>|<color>","cf-mixing-image":"<percentage>?&&<image>","circle()":"circle( [<shape-radius>]? [at <position>]? )","clamp()":"clamp( <calc-sum>#{3} )","class-selector":"'.' <ident-token>","clip-source":"<url>",color:"<color-base>|currentColor|<system-color>|<device-cmyk()>|<light-dark()>|<-non-standard-color>","color-stop":"<color-stop-length>|<color-stop-angle>","color-stop-angle":"<angle-percentage>{1,2}","color-stop-length":"<length-percentage>{1,2}","color-stop-list":"[<linear-color-stop> [, <linear-color-hint>]?]# , <linear-color-stop>","color-interpolation-method":"in [<rectangular-color-space>|<polar-color-space> <hue-interpolation-method>?|<custom-color-space>]",combinator:"'>'|'+'|'~'|['|' '|']","common-lig-values":"[common-ligatures|no-common-ligatures]","compat-auto":"searchfield|textarea|push-button|slider-horizontal|checkbox|radio|square-button|menulist|listbox|meter|progress-bar|button","composite-style":"clear|copy|source-over|source-in|source-out|source-atop|destination-over|destination-in|destination-out|destination-atop|xor","compositing-operator":"add|subtract|intersect|exclude","compound-selector":"[<type-selector>? <subclass-selector>*]!","compound-selector-list":"<compound-selector>#","complex-selector":"<complex-selector-unit> [<combinator>? <complex-selector-unit>]*","complex-selector-list":"<complex-selector>#","conic-gradient()":"conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )","contextual-alt-values":"[contextual|no-contextual]","content-distribution":"space-between|space-around|space-evenly|stretch","content-list":"[<string>|contents|<image>|<counter>|<quote>|<target>|<leader()>|<attr()>]+","content-position":"center|start|end|flex-start|flex-end","content-replacement":"<image>","contrast()":"contrast( [<number-percentage>] )","cos()":"cos( <calc-sum> )",counter:"<counter()>|<counters()>","counter()":"counter( <counter-name> , <counter-style>? )","counter-name":"<custom-ident>","counter-style":"<counter-style-name>|symbols( )","counter-style-name":"<custom-ident>","counters()":"counters( <counter-name> , <string> , <counter-style>? )","cross-fade()":"cross-fade( <cf-mixing-image> , <cf-final-image>? )","cubic-bezier-timing-function":"ease|ease-in|ease-out|ease-in-out|cubic-bezier( <number [0,1]> , <number> , <number [0,1]> , <number> )","deprecated-system-color":"ActiveBorder|ActiveCaption|AppWorkspace|Background|ButtonFace|ButtonHighlight|ButtonShadow|ButtonText|CaptionText|GrayText|Highlight|HighlightText|InactiveBorder|InactiveCaption|InactiveCaptionText|InfoBackground|InfoText|Menu|MenuText|Scrollbar|ThreeDDarkShadow|ThreeDFace|ThreeDHighlight|ThreeDLightShadow|ThreeDShadow|Window|WindowFrame|WindowText","discretionary-lig-values":"[discretionary-ligatures|no-discretionary-ligatures]","display-box":"contents|none","display-inside":"flow|flow-root|table|flex|grid|ruby","display-internal":"table-row-group|table-header-group|table-footer-group|table-row|table-cell|table-column-group|table-column|table-caption|ruby-base|ruby-text|ruby-base-container|ruby-text-container","display-legacy":"inline-block|inline-list-item|inline-table|inline-flex|inline-grid","display-listitem":"<display-outside>?&&[flow|flow-root]?&&list-item","display-outside":"block|inline|run-in","drop-shadow()":"drop-shadow( <length>{2,3} <color>? )","east-asian-variant-values":"[jis78|jis83|jis90|jis04|simplified|traditional]","east-asian-width-values":"[full-width|proportional-width]","element()":"element( <custom-ident> , [first|start|last|first-except]? )|element( <id-selector> )","ellipse()":"ellipse( [<shape-radius>{2}]? [at <position>]? )","ending-shape":"circle|ellipse","env()":"env( <custom-ident> , <declaration-value>? )","exp()":"exp( <calc-sum> )","explicit-track-list":"[<line-names>? <track-size>]+ <line-names>?","family-name":"<string>|<custom-ident>+","feature-tag-value":"<string> [<integer>|on|off]?","feature-type":"@stylistic|@historical-forms|@styleset|@character-variant|@swash|@ornaments|@annotation","feature-value-block":"<feature-type> '{' <feature-value-declaration-list> '}'","feature-value-block-list":"<feature-value-block>+","feature-value-declaration":"<custom-ident> : <integer>+ ;","feature-value-declaration-list":"<feature-value-declaration>","feature-value-name":"<custom-ident>","fill-rule":"nonzero|evenodd","filter-function":"<blur()>|<brightness()>|<contrast()>|<drop-shadow()>|<grayscale()>|<hue-rotate()>|<invert()>|<opacity()>|<saturate()>|<sepia()>","filter-function-list":"[<filter-function>|<url>]+","final-bg-layer":"<'background-color'>||<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>","fixed-breadth":"<length-percentage>","fixed-repeat":"repeat( [<integer [1,∞]>] , [<line-names>? <fixed-size>]+ <line-names>? )","fixed-size":"<fixed-breadth>|minmax( <fixed-breadth> , <track-breadth> )|minmax( <inflexible-breadth> , <fixed-breadth> )","font-stretch-absolute":"normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded|<percentage>","font-variant-css21":"[normal|small-caps]","font-weight-absolute":"normal|bold|<number [1,1000]>","frequency-percentage":"<frequency>|<percentage>","general-enclosed":"[<function-token> <any-value>? )]|[( <any-value>? )]","generic-family":"<generic-script-specific>|<generic-complete>|<generic-incomplete>|<-non-standard-generic-family>","generic-name":"serif|sans-serif|cursive|fantasy|monospace","geometry-box":"<shape-box>|fill-box|stroke-box|view-box",gradient:"<linear-gradient()>|<repeating-linear-gradient()>|<radial-gradient()>|<repeating-radial-gradient()>|<conic-gradient()>|<repeating-conic-gradient()>|<-legacy-gradient>","grayscale()":"grayscale( <number-percentage> )","grid-line":"auto|<custom-ident>|[<integer>&&<custom-ident>?]|[span&&[<integer>||<custom-ident>]]","historical-lig-values":"[historical-ligatures|no-historical-ligatures]","hsl()":"hsl( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsl( <hue> , <percentage> , <percentage> , <alpha-value>? )","hsla()":"hsla( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsla( <hue> , <percentage> , <percentage> , <alpha-value>? )",hue:"<number>|<angle>","hue-rotate()":"hue-rotate( <angle> )","hue-interpolation-method":"[shorter|longer|increasing|decreasing] hue","hwb()":"hwb( [<hue>|none] [<percentage>|none] [<percentage>|none] [/ [<alpha-value>|none]]? )","hypot()":"hypot( <calc-sum># )",image:"<url>|<image()>|<image-set()>|<element()>|<paint()>|<cross-fade()>|<gradient>","image()":"image( <image-tags>? [<image-src>? , <color>?]! )","image-set()":"image-set( <image-set-option># )","image-set-option":"[<image>|<string>] [<resolution>||type( <string> )]","image-src":"<url>|<string>","image-tags":"ltr|rtl","inflexible-breadth":"<length-percentage>|min-content|max-content|auto","inset()":"inset( <length-percentage>{1,4} [round <'border-radius'>]? )","invert()":"invert( <number-percentage> )","keyframes-name":"<custom-ident>|<string>","keyframe-block":"<keyframe-selector># { <declaration-list> }","keyframe-block-list":"<keyframe-block>+","keyframe-selector":"from|to|<percentage>|<timeline-range-name> <percentage>","lab()":"lab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )","layer()":"layer( <layer-name> )","layer-name":"<ident> ['.' <ident>]*","lch()":"lch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )","leader()":"leader( <leader-type> )","leader-type":"dotted|solid|space|<string>","length-percentage":"<length>|<percentage>","light-dark()":"light-dark( <color> , <color> )","line-names":"'[' <custom-ident>* ']'","line-name-list":"[<line-names>|<name-repeat>]+","line-style":"none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset","line-width":"<length>|thin|medium|thick","linear-color-hint":"<length-percentage>","linear-color-stop":"<color> <color-stop-length>?","linear-gradient()":"linear-gradient( [[<angle>|to <side-or-corner>]||<color-interpolation-method>]? , <color-stop-list> )","log()":"log( <calc-sum> , <calc-sum>? )","mask-layer":"<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||<geometry-box>||[<geometry-box>|no-clip]||<compositing-operator>||<masking-mode>","mask-position":"[<length-percentage>|left|center|right] [<length-percentage>|top|center|bottom]?","mask-reference":"none|<image>|<mask-source>","mask-source":"<url>","masking-mode":"alpha|luminance|match-source","matrix()":"matrix( <number>#{6} )","matrix3d()":"matrix3d( <number>#{16} )","max()":"max( <calc-sum># )","media-and":"<media-in-parens> [and <media-in-parens>]+","media-condition":"<media-not>|<media-and>|<media-or>|<media-in-parens>","media-condition-without-or":"<media-not>|<media-and>|<media-in-parens>","media-feature":"( [<mf-plain>|<mf-boolean>|<mf-range>] )","media-in-parens":"( <media-condition> )|<media-feature>|<general-enclosed>","media-not":"not <media-in-parens>","media-or":"<media-in-parens> [or <media-in-parens>]+","media-query":"<media-condition>|[not|only]? <media-type> [and <media-condition-without-or>]?","media-query-list":"<media-query>#","media-type":"<ident>","mf-boolean":"<mf-name>","mf-name":"<ident>","mf-plain":"<mf-name> : <mf-value>","mf-range":"<mf-name> ['<'|'>']? '='? <mf-value>|<mf-value> ['<'|'>']? '='? <mf-name>|<mf-value> '<' '='? <mf-name> '<' '='? <mf-value>|<mf-value> '>' '='? <mf-name> '>' '='? <mf-value>","mf-value":"<number>|<dimension>|<ident>|<ratio>","min()":"min( <calc-sum># )","minmax()":"minmax( [<length-percentage>|min-content|max-content|auto] , [<length-percentage>|<flex>|min-content|max-content|auto] )","mod()":"mod( <calc-sum> , <calc-sum> )","name-repeat":"repeat( [<integer [1,∞]>|auto-fill] , <line-names>+ )","named-color":"transparent|aliceblue|antiquewhite|aqua|aquamarine|azure|beige|bisque|black|blanchedalmond|blue|blueviolet|brown|burlywood|cadetblue|chartreuse|chocolate|coral|cornflowerblue|cornsilk|crimson|cyan|darkblue|darkcyan|darkgoldenrod|darkgray|darkgreen|darkgrey|darkkhaki|darkmagenta|darkolivegreen|darkorange|darkorchid|darkred|darksalmon|darkseagreen|darkslateblue|darkslategray|darkslategrey|darkturquoise|darkviolet|deeppink|deepskyblue|dimgray|dimgrey|dodgerblue|firebrick|floralwhite|forestgreen|fuchsia|gainsboro|ghostwhite|gold|goldenrod|gray|green|greenyellow|grey|honeydew|hotpink|indianred|indigo|ivory|khaki|lavender|lavenderblush|lawngreen|lemonchiffon|lightblue|lightcoral|lightcyan|lightgoldenrodyellow|lightgray|lightgreen|lightgrey|lightpink|lightsalmon|lightseagreen|lightskyblue|lightslategray|lightslategrey|lightsteelblue|lightyellow|lime|limegreen|linen|magenta|maroon|mediumaquamarine|mediumblue|mediumorchid|mediumpurple|mediumseagreen|mediumslateblue|mediumspringgreen|mediumturquoise|mediumvioletred|midnightblue|mintcream|mistyrose|moccasin|navajowhite|navy|oldlace|olive|olivedrab|orange|orangered|orchid|palegoldenrod|palegreen|paleturquoise|palevioletred|papayawhip|peachpuff|peru|pink|plum|powderblue|purple|rebeccapurple|red|rosybrown|royalblue|saddlebrown|salmon|sandybrown|seagreen|seashell|sienna|silver|skyblue|slateblue|slategray|slategrey|snow|springgreen|steelblue|tan|teal|thistle|tomato|turquoise|violet|wheat|white|whitesmoke|yellow|yellowgreen","namespace-prefix":"<ident>","ns-prefix":"[<ident-token>|'*']? '|'","number-percentage":"<number>|<percentage>","numeric-figure-values":"[lining-nums|oldstyle-nums]","numeric-fraction-values":"[diagonal-fractions|stacked-fractions]","numeric-spacing-values":"[proportional-nums|tabular-nums]",nth:"<an-plus-b>|even|odd","opacity()":"opacity( [<number-percentage>] )","overflow-position":"unsafe|safe","outline-radius":"<length>|<percentage>","page-body":"<declaration>? [; <page-body>]?|<page-margin-box> <page-body>","page-margin-box":"<page-margin-box-type> '{' <declaration-list> '}'","page-margin-box-type":"@top-left-corner|@top-left|@top-center|@top-right|@top-right-corner|@bottom-left-corner|@bottom-left|@bottom-center|@bottom-right|@bottom-right-corner|@left-top|@left-middle|@left-bottom|@right-top|@right-middle|@right-bottom","page-selector-list":"[<page-selector>#]?","page-selector":"<pseudo-page>+|<ident> <pseudo-page>*","page-size":"A5|A4|A3|B5|B4|JIS-B5|JIS-B4|letter|legal|ledger","path()":"path( [<fill-rule> ,]? <string> )","paint()":"paint( <ident> , <declaration-value>? )","perspective()":"perspective( [<length [0,∞]>|none] )","polygon()":"polygon( <fill-rule>? , [<length-percentage> <length-percentage>]# )","polar-color-space":"hsl|hwb|lch|oklch",position:"[[left|center|right]||[top|center|bottom]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]?|[[left|right] <length-percentage>]&&[[top|bottom] <length-percentage>]]","pow()":"pow( <calc-sum> , <calc-sum> )","pseudo-class-selector":"':' <ident-token>|':' <function-token> <any-value> ')'","pseudo-element-selector":"':' <pseudo-class-selector>|<legacy-pseudo-element-selector>","pseudo-page":": [left|right|first|blank]",quote:"open-quote|close-quote|no-open-quote|no-close-quote","radial-gradient()":"radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",ratio:"<number [0,∞]> [/ <number [0,∞]>]?","ray()":"ray( <angle>&&<ray-size>?&&contain?&&[at <position>]? )","ray-size":"closest-side|closest-corner|farthest-side|farthest-corner|sides","rectangular-color-space":"srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020|lab|oklab|xyz|xyz-d50|xyz-d65","relative-selector":"<combinator>? <complex-selector>","relative-selector-list":"<relative-selector>#","relative-size":"larger|smaller","rem()":"rem( <calc-sum> , <calc-sum> )","repeat-style":"repeat-x|repeat-y|[repeat|space|round|no-repeat]{1,2}","repeating-conic-gradient()":"repeating-conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )","repeating-linear-gradient()":"repeating-linear-gradient( [<angle>|to <side-or-corner>]? , <color-stop-list> )","repeating-radial-gradient()":"repeating-radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )","reversed-counter-name":"reversed( <counter-name> )","rgb()":"rgb( <percentage>{3} [/ <alpha-value>]? )|rgb( <number>{3} [/ <alpha-value>]? )|rgb( <percentage>#{3} , <alpha-value>? )|rgb( <number>#{3} , <alpha-value>? )","rgba()":"rgba( <percentage>{3} [/ <alpha-value>]? )|rgba( <number>{3} [/ <alpha-value>]? )|rgba( <percentage>#{3} , <alpha-value>? )|rgba( <number>#{3} , <alpha-value>? )","rotate()":"rotate( [<angle>|<zero>] )","rotate3d()":"rotate3d( <number> , <number> , <number> , [<angle>|<zero>] )","rotateX()":"rotateX( [<angle>|<zero>] )","rotateY()":"rotateY( [<angle>|<zero>] )","rotateZ()":"rotateZ( [<angle>|<zero>] )","round()":"round( <rounding-strategy>? , <calc-sum> , <calc-sum> )","rounding-strategy":"nearest|up|down|to-zero","saturate()":"saturate( <number-percentage> )","scale()":"scale( [<number>|<percentage>]#{1,2} )","scale3d()":"scale3d( [<number>|<percentage>]#{3} )","scaleX()":"scaleX( [<number>|<percentage>] )","scaleY()":"scaleY( [<number>|<percentage>] )","scaleZ()":"scaleZ( [<number>|<percentage>] )","scroll()":"scroll( [<axis>||<scroller>]? )",scroller:"root|nearest|self","self-position":"center|start|end|self-start|self-end|flex-start|flex-end","shape-radius":"<length-percentage>|closest-side|farthest-side","sign()":"sign( <calc-sum> )","skew()":"skew( [<angle>|<zero>] , [<angle>|<zero>]? )","skewX()":"skewX( [<angle>|<zero>] )","skewY()":"skewY( [<angle>|<zero>] )","sepia()":"sepia( <number-percentage> )",shadow:"inset?&&<length>{2,4}&&<color>?","shadow-t":"[<length>{2,3}&&<color>?]",shape:"rect( <top> , <right> , <bottom> , <left> )|rect( <top> <right> <bottom> <left> )","shape-box":"<box>|margin-box","side-or-corner":"[left|right]||[top|bottom]","sin()":"sin( <calc-sum> )","single-animation":"<'animation-duration'>||<easing-function>||<'animation-delay'>||<single-animation-iteration-count>||<single-animation-direction>||<single-animation-fill-mode>||<single-animation-play-state>||[none|<keyframes-name>]||<single-animation-timeline>","single-animation-direction":"normal|reverse|alternate|alternate-reverse","single-animation-fill-mode":"none|forwards|backwards|both","single-animation-iteration-count":"infinite|<number>","single-animation-play-state":"running|paused","single-animation-timeline":"auto|none|<dashed-ident>|<scroll()>|<view()>","single-transition":"[none|<single-transition-property>]||<time>||<easing-function>||<time>||<transition-behavior-value>","single-transition-property":"all|<custom-ident>",size:"closest-side|farthest-side|closest-corner|farthest-corner|<length>|<length-percentage>{2}","sqrt()":"sqrt( <calc-sum> )","step-position":"jump-start|jump-end|jump-none|jump-both|start|end","step-timing-function":"step-start|step-end|steps( <integer> [, <step-position>]? )","subclass-selector":"<id-selector>|<class-selector>|<attribute-selector>|<pseudo-class-selector>","supports-condition":"not <supports-in-parens>|<supports-in-parens> [and <supports-in-parens>]*|<supports-in-parens> [or <supports-in-parens>]*","supports-in-parens":"( <supports-condition> )|<supports-feature>|<general-enclosed>","supports-feature":"<supports-decl>|<supports-selector-fn>","supports-decl":"( <declaration> )","supports-selector-fn":"selector( <complex-selector> )",symbol:"<string>|<image>|<custom-ident>","system-color":"AccentColor|AccentColorText|ActiveText|ButtonBorder|ButtonFace|ButtonText|Canvas|CanvasText|Field|FieldText|GrayText|Highlight|HighlightText|LinkText|Mark|MarkText|SelectedItem|SelectedItemText|VisitedText","tan()":"tan( <calc-sum> )",target:"<target-counter()>|<target-counters()>|<target-text()>","target-counter()":"target-counter( [<string>|<url>] , <custom-ident> , <counter-style>? )","target-counters()":"target-counters( [<string>|<url>] , <custom-ident> , <string> , <counter-style>? )","target-text()":"target-text( [<string>|<url>] , [content|before|after|first-letter]? )","time-percentage":"<time>|<percentage>","timeline-range-name":"cover|contain|entry|exit|entry-crossing|exit-crossing","easing-function":"linear|<cubic-bezier-timing-function>|<step-timing-function>","track-breadth":"<length-percentage>|<flex>|min-content|max-content|auto","track-list":"[<line-names>? [<track-size>|<track-repeat>]]+ <line-names>?","track-repeat":"repeat( [<integer [1,∞]>] , [<line-names>? <track-size>]+ <line-names>? )","track-size":"<track-breadth>|minmax( <inflexible-breadth> , <track-breadth> )|fit-content( <length-percentage> )","transform-function":"<matrix()>|<translate()>|<translateX()>|<translateY()>|<scale()>|<scaleX()>|<scaleY()>|<rotate()>|<skew()>|<skewX()>|<skewY()>|<matrix3d()>|<translate3d()>|<translateZ()>|<scale3d()>|<scaleZ()>|<rotate3d()>|<rotateX()>|<rotateY()>|<rotateZ()>|<perspective()>","transform-list":"<transform-function>+","transition-behavior-value":"normal|allow-discrete","translate()":"translate( <length-percentage> , <length-percentage>? )","translate3d()":"translate3d( <length-percentage> , <length-percentage> , <length> )","translateX()":"translateX( <length-percentage> )","translateY()":"translateY( <length-percentage> )","translateZ()":"translateZ( <length> )","type-or-unit":"string|color|url|integer|number|length|angle|time|frequency|cap|ch|em|ex|ic|lh|rlh|rem|vb|vi|vw|vh|vmin|vmax|mm|Q|cm|in|pt|pc|px|deg|grad|rad|turn|ms|s|Hz|kHz|%","type-selector":"<wq-name>|<ns-prefix>? '*'","var()":"var( <custom-property-name> , <declaration-value>? )","view()":"view( [<axis>||<'view-timeline-inset'>]? )","viewport-length":"auto|<length-percentage>","visual-box":"content-box|padding-box|border-box","wq-name":"<ns-prefix>? <ident-token>","-legacy-gradient":"<-webkit-gradient()>|<-legacy-linear-gradient>|<-legacy-repeating-linear-gradient>|<-legacy-radial-gradient>|<-legacy-repeating-radial-gradient>","-legacy-linear-gradient":"-moz-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-linear-gradient( <-legacy-linear-gradient-arguments> )","-legacy-repeating-linear-gradient":"-moz-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )","-legacy-linear-gradient-arguments":"[<angle>|<side-or-corner>]? , <color-stop-list>","-legacy-radial-gradient":"-moz-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-radial-gradient( <-legacy-radial-gradient-arguments> )","-legacy-repeating-radial-gradient":"-moz-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )","-legacy-radial-gradient-arguments":"[<position> ,]? [[[<-legacy-radial-gradient-shape>||<-legacy-radial-gradient-size>]|[<length>|<percentage>]{2}] ,]? <color-stop-list>","-legacy-radial-gradient-size":"closest-side|closest-corner|farthest-side|farthest-corner|contain|cover","-legacy-radial-gradient-shape":"circle|ellipse","-non-standard-font":"-apple-system-body|-apple-system-headline|-apple-system-subheadline|-apple-system-caption1|-apple-system-caption2|-apple-system-footnote|-apple-system-short-body|-apple-system-short-headline|-apple-system-short-subheadline|-apple-system-short-caption1|-apple-system-short-footnote|-apple-system-tall-body","-non-standard-color":"-moz-ButtonDefault|-moz-ButtonHoverFace|-moz-ButtonHoverText|-moz-CellHighlight|-moz-CellHighlightText|-moz-Combobox|-moz-ComboboxText|-moz-Dialog|-moz-DialogText|-moz-dragtargetzone|-moz-EvenTreeRow|-moz-Field|-moz-FieldText|-moz-html-CellHighlight|-moz-html-CellHighlightText|-moz-mac-accentdarkestshadow|-moz-mac-accentdarkshadow|-moz-mac-accentface|-moz-mac-accentlightesthighlight|-moz-mac-accentlightshadow|-moz-mac-accentregularhighlight|-moz-mac-accentregularshadow|-moz-mac-chrome-active|-moz-mac-chrome-inactive|-moz-mac-focusring|-moz-mac-menuselect|-moz-mac-menushadow|-moz-mac-menutextselect|-moz-MenuHover|-moz-MenuHoverText|-moz-MenuBarText|-moz-MenuBarHoverText|-moz-nativehyperlinktext|-moz-OddTreeRow|-moz-win-communicationstext|-moz-win-mediatext|-moz-activehyperlinktext|-moz-default-background-color|-moz-default-color|-moz-hyperlinktext|-moz-visitedhyperlinktext|-webkit-activelink|-webkit-focus-ring-color|-webkit-link|-webkit-text","-non-standard-image-rendering":"optimize-contrast|-moz-crisp-edges|-o-crisp-edges|-webkit-optimize-contrast","-non-standard-overflow":"overlay|-moz-scrollbars-none|-moz-scrollbars-horizontal|-moz-scrollbars-vertical|-moz-hidden-unscrollable","-non-standard-size":"intrinsic|min-intrinsic|-webkit-fill-available|-webkit-fit-content|-webkit-min-content|-webkit-max-content|-moz-available|-moz-fit-content|-moz-min-content|-moz-max-content","-webkit-gradient()":"-webkit-gradient( <-webkit-gradient-type> , <-webkit-gradient-point> [, <-webkit-gradient-point>|, <-webkit-gradient-radius> , <-webkit-gradient-point>] [, <-webkit-gradient-radius>]? [, <-webkit-gradient-color-stop>]* )","-webkit-gradient-color-stop":"from( <color> )|color-stop( [<number-zero-one>|<percentage>] , <color> )|to( <color> )","-webkit-gradient-point":"[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]","-webkit-gradient-radius":"<length>|<percentage>","-webkit-gradient-type":"linear|radial","-webkit-mask-box-repeat":"repeat|stretch|round","-ms-filter-function-list":"<-ms-filter-function>+","-ms-filter-function":"<-ms-filter-function-progid>|<-ms-filter-function-legacy>","-ms-filter-function-progid":"'progid:' [<ident-token> '.']* [<ident-token>|<function-token> <any-value>? )]","-ms-filter-function-legacy":"<ident-token>|<function-token> <any-value>? )","absolute-color-base":"<hex-color>|<absolute-color-function>|<named-color>|transparent","absolute-color-function":"<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>",age:"child|young|old","anchor-name":"<dashed-ident>","attr-name":"<wq-name>","attr-fallback":"<any-value>","bg-clip":"<box>|border|text",bottom:"<length>|auto","container-name":"<custom-ident>","container-condition":"not <query-in-parens>|<query-in-parens> [[and <query-in-parens>]*|[or <query-in-parens>]*]","coord-box":"content-box|padding-box|border-box|fill-box|stroke-box|view-box","generic-voice":"[<age>? <gender> <integer>?]",gender:"male|female|neutral","generic-script-specific":"generic( kai )|generic( fangsong )|generic( nastaliq )","generic-complete":"serif|sans-serif|system-ui|cursive|fantasy|math|monospace","generic-incomplete":"ui-serif|ui-sans-serif|ui-monospace|ui-rounded","-non-standard-generic-family":"-apple-system|BlinkMacSystemFont",left:"<length>|auto","color-base":"<hex-color>|<color-function>|<named-color>|<color-mix()>|transparent","color-function":"<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>","device-cmyk()":"<legacy-device-cmyk-syntax>|<modern-device-cmyk-syntax>","legacy-device-cmyk-syntax":"device-cmyk( <number>#{4} )","modern-device-cmyk-syntax":"device-cmyk( <cmyk-component>{4} [/ [<alpha-value>|none]]? )","cmyk-component":"<number>|<percentage>|none","color-mix()":"color-mix( <color-interpolation-method> , [<color>&&<percentage [0,100]>?]#{2} )","color-space":"<rectangular-color-space>|<polar-color-space>|<custom-color-space>","custom-color-space":"<dashed-ident>",paint:"none|<color>|<url> [none|<color>]?|context-fill|context-stroke","palette-identifier":"<dashed-ident>",right:"<length>|auto","scope-start":"<forgiving-selector-list>","scope-end":"<forgiving-selector-list>","forgiving-selector-list":"<complex-real-selector-list>","forgiving-relative-selector-list":"<relative-real-selector-list>","selector-list":"<complex-selector-list>","complex-real-selector-list":"<complex-real-selector>#","simple-selector-list":"<simple-selector>#","relative-real-selector-list":"<relative-real-selector>#","complex-selector-unit":"[<compound-selector>? <pseudo-compound-selector>*]!","complex-real-selector":"<compound-selector> [<combinator>? <compound-selector>]*","relative-real-selector":"<combinator>? <complex-real-selector>","pseudo-compound-selector":"<pseudo-element-selector> <pseudo-class-selector>*","simple-selector":"<type-selector>|<subclass-selector>","legacy-pseudo-element-selector":"':' [before|after|first-line|first-letter]","single-animation-composition":"replace|add|accumulate","svg-length":"<percentage>|<length>|<number>","svg-writing-mode":"lr-tb|rl-tb|tb-rl|lr|rl|tb",top:"<length>|auto",x:"<number>",y:"<number>",declaration:"<ident-token> : <declaration-value>? ['!' important]?","declaration-list":"[<declaration>? ';']* <declaration>?",url:"url( <string> <url-modifier>* )|<url-token>","url-modifier":"<ident>|<function-token> <any-value> )","number-zero-one":"<number [0,1]>","number-one-or-greater":"<number [1,∞]>","color()":"color( <colorspace-params> [/ [<alpha-value>|none]]? )","colorspace-params":"[<predefined-rgb-params>|<xyz-params>]","predefined-rgb-params":"<predefined-rgb> [<number>|<percentage>|none]{3}","predefined-rgb":"srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020","xyz-params":"<xyz-space> [<number>|<percentage>|none]{3}","xyz-space":"xyz|xyz-d50|xyz-d65","oklab()":"oklab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )","oklch()":"oklch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )","offset-path":"<ray()>|<url>|<basic-shape>","rect()":"rect( [<length-percentage>|auto]{4} [round <'border-radius'>]? )","xywh()":"xywh( <length-percentage>{2} <length-percentage [0,∞]>{2} [round <'border-radius'>]? )","query-in-parens":"( <container-condition> )|( <size-feature> )|style( <style-query> )|<general-enclosed>","size-feature":"<mf-plain>|<mf-boolean>|<mf-range>","style-feature":"<declaration>","style-query":"<style-condition>|<style-feature>","style-condition":"not <style-in-parens>|<style-in-parens> [[and <style-in-parens>]*|[or <style-in-parens>]*]","style-in-parens":"( <style-condition> )|( <style-feature> )|<general-enclosed>","-non-standard-display":"-ms-inline-flexbox|-ms-grid|-ms-inline-grid|-webkit-flex|-webkit-inline-flex|-webkit-box|-webkit-inline-box|-moz-inline-stack|-moz-box|-moz-inline-box","inset-area":"[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]","position-area":"[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|center|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|center|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]","anchor()":"anchor( <anchor-element>?&&<anchor-side> , <length-percentage>? )","anchor-side":"inside|outside|top|left|right|bottom|start|end|self-start|self-end|<percentage>|center","anchor-size()":"anchor-size( [<anchor-element>||<anchor-size>]? , <length-percentage>? )","anchor-size":"width|height|block|inline|self-block|self-inline","anchor-element":"<dashed-ident>","try-size":"most-width|most-height|most-block-size|most-inline-size","try-tactic":"flip-block||flip-inline||flip-start","font-variant-css2":"normal|small-caps","font-width-css3":"normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded","system-family-name":"caption|icon|menu|message-box|small-caption|status-bar"},properties:{"--*":"<declaration-value>","-ms-accelerator":"false|true","-ms-block-progression":"tb|rl|bt|lr","-ms-content-zoom-chaining":"none|chained","-ms-content-zooming":"none|zoom","-ms-content-zoom-limit":"<'-ms-content-zoom-limit-min'> <'-ms-content-zoom-limit-max'>","-ms-content-zoom-limit-max":"<percentage>","-ms-content-zoom-limit-min":"<percentage>","-ms-content-zoom-snap":"<'-ms-content-zoom-snap-type'>||<'-ms-content-zoom-snap-points'>","-ms-content-zoom-snap-points":"snapInterval( <percentage> , <percentage> )|snapList( <percentage># )","-ms-content-zoom-snap-type":"none|proximity|mandatory","-ms-filter":"<string>","-ms-flow-from":"[none|<custom-ident>]#","-ms-flow-into":"[none|<custom-ident>]#","-ms-grid-columns":"none|<track-list>|<auto-track-list>","-ms-grid-rows":"none|<track-list>|<auto-track-list>","-ms-high-contrast-adjust":"auto|none","-ms-hyphenate-limit-chars":"auto|<integer>{1,3}","-ms-hyphenate-limit-lines":"no-limit|<integer>","-ms-hyphenate-limit-zone":"<percentage>|<length>","-ms-ime-align":"auto|after","-ms-overflow-style":"auto|none|scrollbar|-ms-autohiding-scrollbar","-ms-scrollbar-3dlight-color":"<color>","-ms-scrollbar-arrow-color":"<color>","-ms-scrollbar-base-color":"<color>","-ms-scrollbar-darkshadow-color":"<color>","-ms-scrollbar-face-color":"<color>","-ms-scrollbar-highlight-color":"<color>","-ms-scrollbar-shadow-color":"<color>","-ms-scrollbar-track-color":"<color>","-ms-scroll-chaining":"chained|none","-ms-scroll-limit":"<'-ms-scroll-limit-x-min'> <'-ms-scroll-limit-y-min'> <'-ms-scroll-limit-x-max'> <'-ms-scroll-limit-y-max'>","-ms-scroll-limit-x-max":"auto|<length>","-ms-scroll-limit-x-min":"<length>","-ms-scroll-limit-y-max":"auto|<length>","-ms-scroll-limit-y-min":"<length>","-ms-scroll-rails":"none|railed","-ms-scroll-snap-points-x":"snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )","-ms-scroll-snap-points-y":"snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )","-ms-scroll-snap-type":"none|proximity|mandatory","-ms-scroll-snap-x":"<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-x'>","-ms-scroll-snap-y":"<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-y'>","-ms-scroll-translation":"none|vertical-to-horizontal","-ms-text-autospace":"none|ideograph-alpha|ideograph-numeric|ideograph-parenthesis|ideograph-space","-ms-touch-select":"grippers|none","-ms-user-select":"none|element|text","-ms-wrap-flow":"auto|both|start|end|maximum|clear","-ms-wrap-margin":"<length>","-ms-wrap-through":"wrap|none","-moz-appearance":"none|button|button-arrow-down|button-arrow-next|button-arrow-previous|button-arrow-up|button-bevel|button-focus|caret|checkbox|checkbox-container|checkbox-label|checkmenuitem|dualbutton|groupbox|listbox|listitem|menuarrow|menubar|menucheckbox|menuimage|menuitem|menuitemtext|menulist|menulist-button|menulist-text|menulist-textfield|menupopup|menuradio|menuseparator|meterbar|meterchunk|progressbar|progressbar-vertical|progresschunk|progresschunk-vertical|radio|radio-container|radio-label|radiomenuitem|range|range-thumb|resizer|resizerpanel|scale-horizontal|scalethumbend|scalethumb-horizontal|scalethumbstart|scalethumbtick|scalethumb-vertical|scale-vertical|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|separator|sheet|spinner|spinner-downbutton|spinner-textfield|spinner-upbutton|splitter|statusbar|statusbarpanel|tab|tabpanel|tabpanels|tab-scroll-arrow-back|tab-scroll-arrow-forward|textfield|textfield-multiline|toolbar|toolbarbutton|toolbarbutton-dropdown|toolbargripper|toolbox|tooltip|treeheader|treeheadercell|treeheadersortarrow|treeitem|treeline|treetwisty|treetwistyopen|treeview|-moz-mac-unified-toolbar|-moz-win-borderless-glass|-moz-win-browsertabbar-toolbox|-moz-win-communicationstext|-moz-win-communications-toolbox|-moz-win-exclude-glass|-moz-win-glass|-moz-win-mediatext|-moz-win-media-toolbox|-moz-window-button-box|-moz-window-button-box-maximized|-moz-window-button-close|-moz-window-button-maximize|-moz-window-button-minimize|-moz-window-button-restore|-moz-window-frame-bottom|-moz-window-frame-left|-moz-window-frame-right|-moz-window-titlebar|-moz-window-titlebar-maximized","-moz-binding":"<url>|none","-moz-border-bottom-colors":"<color>+|none","-moz-border-left-colors":"<color>+|none","-moz-border-right-colors":"<color>+|none","-moz-border-top-colors":"<color>+|none","-moz-context-properties":"none|[fill|fill-opacity|stroke|stroke-opacity]#","-moz-float-edge":"border-box|content-box|margin-box|padding-box","-moz-force-broken-image-icon":"0|1","-moz-image-region":"<shape>|auto","-moz-orient":"inline|block|horizontal|vertical","-moz-outline-radius":"<outline-radius>{1,4} [/ <outline-radius>{1,4}]?","-moz-outline-radius-bottomleft":"<outline-radius>","-moz-outline-radius-bottomright":"<outline-radius>","-moz-outline-radius-topleft":"<outline-radius>","-moz-outline-radius-topright":"<outline-radius>","-moz-stack-sizing":"ignore|stretch-to-fit","-moz-text-blink":"none|blink","-moz-user-focus":"ignore|normal|select-after|select-before|select-menu|select-same|select-all|none","-moz-user-input":"auto|none|enabled|disabled","-moz-user-modify":"read-only|read-write|write-only","-moz-window-dragging":"drag|no-drag","-moz-window-shadow":"default|menu|tooltip|sheet|none","-webkit-appearance":"none|button|button-bevel|caps-lock-indicator|caret|checkbox|default-button|inner-spin-button|listbox|listitem|media-controls-background|media-controls-fullscreen-background|media-current-time-display|media-enter-fullscreen-button|media-exit-fullscreen-button|media-fullscreen-button|media-mute-button|media-overlay-play-button|media-play-button|media-seek-back-button|media-seek-forward-button|media-slider|media-sliderthumb|media-time-remaining-display|media-toggle-closed-captions-button|media-volume-slider|media-volume-slider-container|media-volume-sliderthumb|menulist|menulist-button|menulist-text|menulist-textfield|meter|progress-bar|progress-bar-value|push-button|radio|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbargripper-horizontal|scrollbargripper-vertical|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|searchfield-cancel-button|searchfield-decoration|searchfield-results-button|searchfield-results-decoration|slider-horizontal|slider-vertical|sliderthumb-horizontal|sliderthumb-vertical|square-button|textarea|textfield|-apple-pay-button","-webkit-border-before":"<'border-width'>||<'border-style'>||<color>","-webkit-border-before-color":"<color>","-webkit-border-before-style":"<'border-style'>","-webkit-border-before-width":"<'border-width'>","-webkit-box-reflect":"[above|below|right|left]? <length>? <image>?","-webkit-line-clamp":"none|<integer>","-webkit-mask":"[<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||[<box>|border|padding|content|text]||[<box>|border|padding|content]]#","-webkit-mask-attachment":"<attachment>#","-webkit-mask-clip":"[<box>|border|padding|content|text]#","-webkit-mask-composite":"<composite-style>#","-webkit-mask-image":"<mask-reference>#","-webkit-mask-origin":"[<box>|border|padding|content]#","-webkit-mask-position":"<position>#","-webkit-mask-position-x":"[<length-percentage>|left|center|right]#","-webkit-mask-position-y":"[<length-percentage>|top|center|bottom]#","-webkit-mask-repeat":"<repeat-style>#","-webkit-mask-repeat-x":"repeat|no-repeat|space|round","-webkit-mask-repeat-y":"repeat|no-repeat|space|round","-webkit-mask-size":"<bg-size>#","-webkit-overflow-scrolling":"auto|touch","-webkit-tap-highlight-color":"<color>","-webkit-text-fill-color":"<color>","-webkit-text-stroke":"<length>||<color>","-webkit-text-stroke-color":"<color>","-webkit-text-stroke-width":"<length>","-webkit-touch-callout":"default|none","-webkit-user-modify":"read-only|read-write|read-write-plaintext-only","accent-color":"auto|<color>","align-content":"normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>","align-items":"normal|stretch|<baseline-position>|[<overflow-position>? <self-position>]","align-self":"auto|normal|stretch|<baseline-position>|<overflow-position>? <self-position>","align-tracks":"[normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>]#",all:"initial|inherit|unset|revert|revert-layer","anchor-name":"none|<dashed-ident>#","anchor-scope":"none|all|<dashed-ident>#",animation:"<single-animation>#","animation-composition":"<single-animation-composition>#","animation-delay":"<time>#","animation-direction":"<single-animation-direction>#","animation-duration":"<time>#","animation-fill-mode":"<single-animation-fill-mode>#","animation-iteration-count":"<single-animation-iteration-count>#","animation-name":"[none|<keyframes-name>]#","animation-play-state":"<single-animation-play-state>#","animation-range":"[<'animation-range-start'> <'animation-range-end'>?]#","animation-range-end":"[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#","animation-range-start":"[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#","animation-timing-function":"<easing-function>#","animation-timeline":"<single-animation-timeline>#",appearance:"none|auto|textfield|menulist-button|<compat-auto>","aspect-ratio":"auto||<ratio>",azimuth:"<angle>|[[left-side|far-left|left|center-left|center|center-right|right|far-right|right-side]||behind]|leftwards|rightwards","backdrop-filter":"none|<filter-function-list>","backface-visibility":"visible|hidden",background:"[<bg-layer> ,]* <final-bg-layer>","background-attachment":"<attachment>#","background-blend-mode":"<blend-mode>#","background-clip":"<bg-clip>#","background-color":"<color>","background-image":"<bg-image>#","background-origin":"<box>#","background-position":"<bg-position>#","background-position-x":"[center|[[left|right|x-start|x-end]? <length-percentage>?]!]#","background-position-y":"[center|[[top|bottom|y-start|y-end]? <length-percentage>?]!]#","background-repeat":"<repeat-style>#","background-size":"<bg-size>#","block-size":"<'width'>",border:"<line-width>||<line-style>||<color>","border-block":"<'border-top-width'>||<'border-top-style'>||<color>","border-block-color":"<'border-top-color'>{1,2}","border-block-style":"<'border-top-style'>","border-block-width":"<'border-top-width'>","border-block-end":"<'border-top-width'>||<'border-top-style'>||<color>","border-block-end-color":"<'border-top-color'>","border-block-end-style":"<'border-top-style'>","border-block-end-width":"<'border-top-width'>","border-block-start":"<'border-top-width'>||<'border-top-style'>||<color>","border-block-start-color":"<'border-top-color'>","border-block-start-style":"<'border-top-style'>","border-block-start-width":"<'border-top-width'>","border-bottom":"<line-width>||<line-style>||<color>","border-bottom-color":"<'border-top-color'>","border-bottom-left-radius":"<length-percentage>{1,2}","border-bottom-right-radius":"<length-percentage>{1,2}","border-bottom-style":"<line-style>","border-bottom-width":"<line-width>","border-collapse":"collapse|separate","border-color":"<color>{1,4}","border-end-end-radius":"<length-percentage>{1,2}","border-end-start-radius":"<length-percentage>{1,2}","border-image":"<'border-image-source'>||<'border-image-slice'> [/ <'border-image-width'>|/ <'border-image-width'>? / <'border-image-outset'>]?||<'border-image-repeat'>","border-image-outset":"[<length>|<number>]{1,4}","border-image-repeat":"[stretch|repeat|round|space]{1,2}","border-image-slice":"<number-percentage>{1,4}&&fill?","border-image-source":"none|<image>","border-image-width":"[<length-percentage>|<number>|auto]{1,4}","border-inline":"<'border-top-width'>||<'border-top-style'>||<color>","border-inline-end":"<'border-top-width'>||<'border-top-style'>||<color>","border-inline-color":"<'border-top-color'>{1,2}","border-inline-style":"<'border-top-style'>","border-inline-width":"<'border-top-width'>","border-inline-end-color":"<'border-top-color'>","border-inline-end-style":"<'border-top-style'>","border-inline-end-width":"<'border-top-width'>","border-inline-start":"<'border-top-width'>||<'border-top-style'>||<color>","border-inline-start-color":"<'border-top-color'>","border-inline-start-style":"<'border-top-style'>","border-inline-start-width":"<'border-top-width'>","border-left":"<line-width>||<line-style>||<color>","border-left-color":"<color>","border-left-style":"<line-style>","border-left-width":"<line-width>","border-radius":"<length-percentage>{1,4} [/ <length-percentage>{1,4}]?","border-right":"<line-width>||<line-style>||<color>","border-right-color":"<color>","border-right-style":"<line-style>","border-right-width":"<line-width>","border-spacing":"<length> <length>?","border-start-end-radius":"<length-percentage>{1,2}","border-start-start-radius":"<length-percentage>{1,2}","border-style":"<line-style>{1,4}","border-top":"<line-width>||<line-style>||<color>","border-top-color":"<color>","border-top-left-radius":"<length-percentage>{1,2}","border-top-right-radius":"<length-percentage>{1,2}","border-top-style":"<line-style>","border-top-width":"<line-width>","border-width":"<line-width>{1,4}",bottom:"<length>|<percentage>|auto","box-align":"start|center|end|baseline|stretch","box-decoration-break":"slice|clone","box-direction":"normal|reverse|inherit","box-flex":"<number>","box-flex-group":"<integer>","box-lines":"single|multiple","box-ordinal-group":"<integer>","box-orient":"horizontal|vertical|inline-axis|block-axis|inherit","box-pack":"start|center|end|justify","box-shadow":"none|<shadow>#","box-sizing":"content-box|border-box","break-after":"auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region","break-before":"auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region","break-inside":"auto|avoid|avoid-page|avoid-column|avoid-region","caption-side":"top|bottom|block-start|block-end|inline-start|inline-end",caret:"<'caret-color'>||<'caret-shape'>","caret-color":"auto|<color>","caret-shape":"auto|bar|block|underscore",clear:"none|left|right|both|inline-start|inline-end",clip:"<shape>|auto","clip-path":"<clip-source>|[<basic-shape>||<geometry-box>]|none","clip-rule":"nonzero|evenodd",color:"<color>","color-interpolation-filters":"auto|sRGB|linearRGB","color-scheme":"normal|[light|dark|<custom-ident>]+&&only?","column-count":"<integer>|auto","column-fill":"auto|balance","column-gap":"normal|<length-percentage>","column-rule":"<'column-rule-width'>||<'column-rule-style'>||<'column-rule-color'>","column-rule-color":"<color>","column-rule-style":"<'border-style'>","column-rule-width":"<'border-width'>","column-span":"none|all","column-width":"<length>|auto",columns:"<'column-width'>||<'column-count'>",contain:"none|strict|content|[[size||inline-size]||layout||style||paint]","contain-intrinsic-size":"[auto? [none|<length>]]{1,2}","contain-intrinsic-block-size":"auto? [none|<length>]","contain-intrinsic-height":"auto? [none|<length>]","contain-intrinsic-inline-size":"auto? [none|<length>]","contain-intrinsic-width":"auto? [none|<length>]",container:"<'container-name'> [/ <'container-type'>]?","container-name":"none|<custom-ident>+","container-type":"normal||[size|inline-size]",content:"normal|none|[<content-replacement>|<content-list>] [/ [<string>|<counter>]+]?","content-visibility":"visible|auto|hidden","counter-increment":"[<counter-name> <integer>?]+|none","counter-reset":"[<counter-name> <integer>?|<reversed-counter-name> <integer>?]+|none","counter-set":"[<counter-name> <integer>?]+|none",cursor:"[[<url> [<x> <y>]? ,]* [auto|default|none|context-menu|help|pointer|progress|wait|cell|crosshair|text|vertical-text|alias|copy|move|no-drop|not-allowed|e-resize|n-resize|ne-resize|nw-resize|s-resize|se-resize|sw-resize|w-resize|ew-resize|ns-resize|nesw-resize|nwse-resize|col-resize|row-resize|all-scroll|zoom-in|zoom-out|grab|grabbing|hand|-webkit-grab|-webkit-grabbing|-webkit-zoom-in|-webkit-zoom-out|-moz-grab|-moz-grabbing|-moz-zoom-in|-moz-zoom-out]]",d:"none|path( <string> )",cx:"<length>|<percentage>",cy:"<length>|<percentage>",direction:"ltr|rtl",display:"[<display-outside>||<display-inside>]|<display-listitem>|<display-internal>|<display-box>|<display-legacy>|<-non-standard-display>","dominant-baseline":"auto|use-script|no-change|reset-size|ideographic|alphabetic|hanging|mathematical|central|middle|text-after-edge|text-before-edge","empty-cells":"show|hide","field-sizing":"content|fixed",fill:"<paint>","fill-opacity":"<number-zero-one>","fill-rule":"nonzero|evenodd",filter:"none|<filter-function-list>|<-ms-filter-function-list>",flex:"none|[<'flex-grow'> <'flex-shrink'>?||<'flex-basis'>]","flex-basis":"content|<'width'>","flex-direction":"row|row-reverse|column|column-reverse","flex-flow":"<'flex-direction'>||<'flex-wrap'>","flex-grow":"<number>","flex-shrink":"<number>","flex-wrap":"nowrap|wrap|wrap-reverse",float:"left|right|none|inline-start|inline-end",font:"[[<'font-style'>||<font-variant-css2>||<'font-weight'>||<font-width-css3>]? <'font-size'> [/ <'line-height'>]? <'font-family'>#]|<system-family-name>|<-non-standard-font>","font-family":"[<family-name>|<generic-family>]#","font-feature-settings":"normal|<feature-tag-value>#","font-kerning":"auto|normal|none","font-language-override":"normal|<string>","font-optical-sizing":"auto|none","font-palette":"normal|light|dark|<palette-identifier>","font-variation-settings":"normal|[<string> <number>]#","font-size":"<absolute-size>|<relative-size>|<length-percentage>","font-size-adjust":"none|[ex-height|cap-height|ch-width|ic-width|ic-height]? [from-font|<number>]","font-smooth":"auto|never|always|<absolute-size>|<length>","font-stretch":"<font-stretch-absolute>","font-style":"normal|italic|oblique <angle>?","font-synthesis":"none|[weight||style||small-caps||position]","font-synthesis-position":"auto|none","font-synthesis-small-caps":"auto|none","font-synthesis-style":"auto|none","font-synthesis-weight":"auto|none","font-variant":"normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>||stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )||[small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps]||<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero||<east-asian-variant-values>||<east-asian-width-values>||ruby]","font-variant-alternates":"normal|[stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )]","font-variant-caps":"normal|small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps","font-variant-east-asian":"normal|[<east-asian-variant-values>||<east-asian-width-values>||ruby]","font-variant-emoji":"normal|text|emoji|unicode","font-variant-ligatures":"normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>]","font-variant-numeric":"normal|[<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero]","font-variant-position":"normal|sub|super","font-weight":"<font-weight-absolute>|bolder|lighter","forced-color-adjust":"auto|none|preserve-parent-color",gap:"<'row-gap'> <'column-gap'>?",grid:"<'grid-template'>|<'grid-template-rows'> / [auto-flow&&dense?] <'grid-auto-columns'>?|[auto-flow&&dense?] <'grid-auto-rows'>? / <'grid-template-columns'>","grid-area":"<grid-line> [/ <grid-line>]{0,3}","grid-auto-columns":"<track-size>+","grid-auto-flow":"[row|column]||dense","grid-auto-rows":"<track-size>+","grid-column":"<grid-line> [/ <grid-line>]?","grid-column-end":"<grid-line>","grid-column-gap":"<length-percentage>","grid-column-start":"<grid-line>","grid-gap":"<'grid-row-gap'> <'grid-column-gap'>?","grid-row":"<grid-line> [/ <grid-line>]?","grid-row-end":"<grid-line>","grid-row-gap":"<length-percentage>","grid-row-start":"<grid-line>","grid-template":"none|[<'grid-template-rows'> / <'grid-template-columns'>]|[<line-names>? <string> <track-size>? <line-names>?]+ [/ <explicit-track-list>]?","grid-template-areas":"none|<string>+","grid-template-columns":"none|<track-list>|<auto-track-list>|subgrid <line-name-list>?","grid-template-rows":"none|<track-list>|<auto-track-list>|subgrid <line-name-list>?","hanging-punctuation":"none|[first||[force-end|allow-end]||last]",height:"auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","hyphenate-character":"auto|<string>","hyphenate-limit-chars":"[auto|<integer>]{1,3}",hyphens:"none|manual|auto","image-orientation":"from-image|<angle>|[<angle>? flip]","image-rendering":"auto|crisp-edges|pixelated|optimizeSpeed|optimizeQuality|<-non-standard-image-rendering>","image-resolution":"[from-image||<resolution>]&&snap?","ime-mode":"auto|normal|active|inactive|disabled","initial-letter":"normal|[<number> <integer>?]","initial-letter-align":"[auto|alphabetic|hanging|ideographic]","inline-size":"<'width'>","input-security":"auto|none",inset:"<'top'>{1,4}","inset-block":"<'top'>{1,2}","inset-block-end":"<'top'>","inset-block-start":"<'top'>","inset-inline":"<'top'>{1,2}","inset-inline-end":"<'top'>","inset-inline-start":"<'top'>","interpolate-size":"numeric-only|allow-keywords",isolation:"auto|isolate","justify-content":"normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]","justify-items":"normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]|legacy|legacy&&[left|right|center]","justify-self":"auto|normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]","justify-tracks":"[normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]]#",left:"<length>|<percentage>|auto","letter-spacing":"normal|<length-percentage>","line-break":"auto|loose|normal|strict|anywhere","line-clamp":"none|<integer>","line-height":"normal|<number>|<length>|<percentage>","line-height-step":"<length>","list-style":"<'list-style-type'>||<'list-style-position'>||<'list-style-image'>","list-style-image":"<image>|none","list-style-position":"inside|outside","list-style-type":"<counter-style>|<string>|none",margin:"[<length>|<percentage>|auto]{1,4}","margin-block":"<'margin-left'>{1,2}","margin-block-end":"<'margin-left'>","margin-block-start":"<'margin-left'>","margin-bottom":"<length>|<percentage>|auto","margin-inline":"<'margin-left'>{1,2}","margin-inline-end":"<'margin-left'>","margin-inline-start":"<'margin-left'>","margin-left":"<length>|<percentage>|auto","margin-right":"<length>|<percentage>|auto","margin-top":"<length>|<percentage>|auto","margin-trim":"none|in-flow|all",marker:"none|<url>","marker-end":"none|<url>","marker-mid":"none|<url>","marker-start":"none|<url>",mask:"<mask-layer>#","mask-border":"<'mask-border-source'>||<'mask-border-slice'> [/ <'mask-border-width'>? [/ <'mask-border-outset'>]?]?||<'mask-border-repeat'>||<'mask-border-mode'>","mask-border-mode":"luminance|alpha","mask-border-outset":"[<length>|<number>]{1,4}","mask-border-repeat":"[stretch|repeat|round|space]{1,2}","mask-border-slice":"<number-percentage>{1,4} fill?","mask-border-source":"none|<image>","mask-border-width":"[<length-percentage>|<number>|auto]{1,4}","mask-clip":"[<geometry-box>|no-clip]#","mask-composite":"<compositing-operator>#","mask-image":"<mask-reference>#","mask-mode":"<masking-mode>#","mask-origin":"<geometry-box>#","mask-position":"<position>#","mask-repeat":"<repeat-style>#","mask-size":"<bg-size>#","mask-type":"luminance|alpha","masonry-auto-flow":"[pack|next]||[definite-first|ordered]","math-depth":"auto-add|add( <integer> )|<integer>","math-shift":"normal|compact","math-style":"normal|compact","max-block-size":"<'max-width'>","max-height":"none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","max-inline-size":"<'max-width'>","max-lines":"none|<integer>","max-width":"none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","min-block-size":"<'min-width'>","min-height":"auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","min-inline-size":"<'min-width'>","min-width":"auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","mix-blend-mode":"<blend-mode>|plus-lighter","object-fit":"fill|contain|cover|none|scale-down","object-position":"<position>",offset:"[<'offset-position'>? [<'offset-path'> [<'offset-distance'>||<'offset-rotate'>]?]?]! [/ <'offset-anchor'>]?","offset-anchor":"auto|<position>","offset-distance":"<length-percentage>","offset-path":"none|<offset-path>||<coord-box>","offset-position":"normal|auto|<position>","offset-rotate":"[auto|reverse]||<angle>",opacity:"<alpha-value>",order:"<integer>",orphans:"<integer>",outline:"[<'outline-width'>||<'outline-style'>||<'outline-color'>]","outline-color":"auto|<color>","outline-offset":"<length>","outline-style":"auto|<'border-style'>","outline-width":"<line-width>",overflow:"[visible|hidden|clip|scroll|auto]{1,2}|<-non-standard-overflow>","overflow-anchor":"auto|none","overflow-block":"visible|hidden|clip|scroll|auto","overflow-clip-box":"padding-box|content-box","overflow-clip-margin":"<visual-box>||<length [0,∞]>","overflow-inline":"visible|hidden|clip|scroll|auto","overflow-wrap":"normal|break-word|anywhere","overflow-x":"visible|hidden|clip|scroll|auto","overflow-y":"visible|hidden|clip|scroll|auto",overlay:"none|auto","overscroll-behavior":"[contain|none|auto]{1,2}","overscroll-behavior-block":"contain|none|auto","overscroll-behavior-inline":"contain|none|auto","overscroll-behavior-x":"contain|none|auto","overscroll-behavior-y":"contain|none|auto",padding:"[<length>|<percentage>]{1,4}","padding-block":"<'padding-left'>{1,2}","padding-block-end":"<'padding-left'>","padding-block-start":"<'padding-left'>","padding-bottom":"<length>|<percentage>","padding-inline":"<'padding-left'>{1,2}","padding-inline-end":"<'padding-left'>","padding-inline-start":"<'padding-left'>","padding-left":"<length>|<percentage>","padding-right":"<length>|<percentage>","padding-top":"<length>|<percentage>",page:"auto|<custom-ident>","page-break-after":"auto|always|avoid|left|right|recto|verso","page-break-before":"auto|always|avoid|left|right|recto|verso","page-break-inside":"auto|avoid","paint-order":"normal|[fill||stroke||markers]",perspective:"none|<length>","perspective-origin":"<position>","place-content":"<'align-content'> <'justify-content'>?","place-items":"<'align-items'> <'justify-items'>?","place-self":"<'align-self'> <'justify-self'>?","pointer-events":"auto|none|visiblePainted|visibleFill|visibleStroke|visible|painted|fill|stroke|all|inherit",position:"static|relative|absolute|sticky|fixed|-webkit-sticky","position-anchor":"auto|<anchor-name>","position-area":"none|<position-area>","position-try":"<'position-try-order'>? <'position-try-fallbacks'>","position-try-fallbacks":"none|[[<dashed-ident>||<try-tactic>]|<'position-area'>]#","position-try-order":"normal|<try-size>","position-visibility":"always|[anchors-valid||anchors-visible||no-overflow]","print-color-adjust":"economy|exact",quotes:"none|auto|[<string> <string>]+",r:"<length>|<percentage>",resize:"none|both|horizontal|vertical|block|inline",right:"<length>|<percentage>|auto",rotate:"none|<angle>|[x|y|z|<number>{3}]&&<angle>","row-gap":"normal|<length-percentage>","ruby-align":"start|center|space-between|space-around","ruby-merge":"separate|collapse|auto","ruby-position":"[alternate||[over|under]]|inter-character",rx:"<length>|<percentage>",ry:"<length>|<percentage>",scale:"none|[<number>|<percentage>]{1,3}","scrollbar-color":"auto|<color>{2}","scrollbar-gutter":"auto|stable&&both-edges?","scrollbar-width":"auto|thin|none","scroll-behavior":"auto|smooth","scroll-margin":"<length>{1,4}","scroll-margin-block":"<length>{1,2}","scroll-margin-block-start":"<length>","scroll-margin-block-end":"<length>","scroll-margin-bottom":"<length>","scroll-margin-inline":"<length>{1,2}","scroll-margin-inline-start":"<length>","scroll-margin-inline-end":"<length>","scroll-margin-left":"<length>","scroll-margin-right":"<length>","scroll-margin-top":"<length>","scroll-padding":"[auto|<length-percentage>]{1,4}","scroll-padding-block":"[auto|<length-percentage>]{1,2}","scroll-padding-block-start":"auto|<length-percentage>","scroll-padding-block-end":"auto|<length-percentage>","scroll-padding-bottom":"auto|<length-percentage>","scroll-padding-inline":"[auto|<length-percentage>]{1,2}","scroll-padding-inline-start":"auto|<length-percentage>","scroll-padding-inline-end":"auto|<length-percentage>","scroll-padding-left":"auto|<length-percentage>","scroll-padding-right":"auto|<length-percentage>","scroll-padding-top":"auto|<length-percentage>","scroll-snap-align":"[none|start|end|center]{1,2}","scroll-snap-coordinate":"none|<position>#","scroll-snap-destination":"<position>","scroll-snap-points-x":"none|repeat( <length-percentage> )","scroll-snap-points-y":"none|repeat( <length-percentage> )","scroll-snap-stop":"normal|always","scroll-snap-type":"none|[x|y|block|inline|both] [mandatory|proximity]?","scroll-snap-type-x":"none|mandatory|proximity","scroll-snap-type-y":"none|mandatory|proximity","scroll-timeline":"[<'scroll-timeline-name'>||<'scroll-timeline-axis'>]#","scroll-timeline-axis":"[block|inline|x|y]#","scroll-timeline-name":"[none|<dashed-ident>]#","shape-image-threshold":"<alpha-value>","shape-margin":"<length-percentage>","shape-outside":"none|[<shape-box>||<basic-shape>]|<image>","shape-rendering":"auto|optimizeSpeed|crispEdges|geometricPrecision",stroke:"<paint>","stroke-dasharray":"none|[<svg-length>+]#","stroke-dashoffset":"<svg-length>","stroke-linecap":"butt|round|square","stroke-linejoin":"miter|round|bevel","stroke-miterlimit":"<number-one-or-greater>","stroke-opacity":"<'opacity'>","stroke-width":"<svg-length>","tab-size":"<integer>|<length>","table-layout":"auto|fixed","text-align":"start|end|left|right|center|justify|match-parent","text-align-last":"auto|start|end|left|right|center|justify","text-anchor":"start|middle|end","text-combine-upright":"none|all|[digits <integer>?]","text-decoration":"<'text-decoration-line'>||<'text-decoration-style'>||<'text-decoration-color'>||<'text-decoration-thickness'>","text-decoration-color":"<color>","text-decoration-line":"none|[underline||overline||line-through||blink]|spelling-error|grammar-error","text-decoration-skip":"none|[objects||[spaces|[leading-spaces||trailing-spaces]]||edges||box-decoration]","text-decoration-skip-ink":"auto|all|none","text-decoration-style":"solid|double|dotted|dashed|wavy","text-decoration-thickness":"auto|from-font|<length>|<percentage>","text-emphasis":"<'text-emphasis-style'>||<'text-emphasis-color'>","text-emphasis-color":"<color>","text-emphasis-position":"auto|[over|under]&&[right|left]?","text-emphasis-style":"none|[[filled|open]||[dot|circle|double-circle|triangle|sesame]]|<string>","text-indent":"<length-percentage>&&hanging?&&each-line?","text-justify":"auto|inter-character|inter-word|none","text-orientation":"mixed|upright|sideways","text-overflow":"[clip|ellipsis|<string>]{1,2}","text-rendering":"auto|optimizeSpeed|optimizeLegibility|geometricPrecision","text-shadow":"none|<shadow-t>#","text-size-adjust":"none|auto|<percentage>","text-spacing-trim":"space-all|normal|space-first|trim-start|trim-both|trim-all|auto","text-transform":"none|capitalize|uppercase|lowercase|full-width|full-size-kana","text-underline-offset":"auto|<length>|<percentage>","text-underline-position":"auto|from-font|[under||[left|right]]","text-wrap":"<'text-wrap-mode'>||<'text-wrap-style'>","text-wrap-mode":"auto|wrap|nowrap","text-wrap-style":"auto|balance|stable|pretty","timeline-scope":"none|<dashed-ident>#",top:"<length>|<percentage>|auto","touch-action":"auto|none|[[pan-x|pan-left|pan-right]||[pan-y|pan-up|pan-down]||pinch-zoom]|manipulation",transform:"none|<transform-list>","transform-box":"content-box|border-box|fill-box|stroke-box|view-box","transform-origin":"[<length-percentage>|left|center|right|top|bottom]|[[<length-percentage>|left|center|right]&&[<length-percentage>|top|center|bottom]] <length>?","transform-style":"flat|preserve-3d",transition:"<single-transition>#","transition-behavior":"<transition-behavior-value>#","transition-delay":"<time>#","transition-duration":"<time>#","transition-property":"none|<single-transition-property>#","transition-timing-function":"<easing-function>#",translate:"none|<length-percentage> [<length-percentage> <length>?]?","unicode-bidi":"normal|embed|isolate|bidi-override|isolate-override|plaintext|-moz-isolate|-moz-isolate-override|-moz-plaintext|-webkit-isolate|-webkit-isolate-override|-webkit-plaintext","user-select":"auto|text|none|contain|all","vector-effect":"none|non-scaling-stroke|non-scaling-size|non-rotation|fixed-position","vertical-align":"baseline|sub|super|text-top|text-bottom|middle|top|bottom|<percentage>|<length>","view-timeline":"[<'view-timeline-name'> <'view-timeline-axis'>?]#","view-timeline-axis":"[block|inline|x|y]#","view-timeline-inset":"[[auto|<length-percentage>]{1,2}]#","view-timeline-name":"none|<dashed-ident>#","view-transition-name":"none|<custom-ident>",visibility:"visible|hidden|collapse","white-space":"normal|pre|nowrap|pre-wrap|pre-line|break-spaces|[<'white-space-collapse'>||<'text-wrap'>||<'white-space-trim'>]","white-space-collapse":"collapse|discard|preserve|preserve-breaks|preserve-spaces|break-spaces",widows:"<integer>",width:"auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>","will-change":"auto|<animateable-feature>#","word-break":"normal|break-all|keep-all|break-word|auto-phrase","word-spacing":"normal|<length>","word-wrap":"normal|break-word","writing-mode":"horizontal-tb|vertical-rl|vertical-lr|sideways-rl|sideways-lr|<svg-writing-mode>",x:"<length>|<percentage>",y:"<length>|<percentage>","z-index":"auto|<integer>",zoom:"normal|reset|<number>|<percentage>","-moz-background-clip":"padding|border","-moz-border-radius-bottomleft":"<'border-bottom-left-radius'>","-moz-border-radius-bottomright":"<'border-bottom-right-radius'>","-moz-border-radius-topleft":"<'border-top-left-radius'>","-moz-border-radius-topright":"<'border-bottom-right-radius'>","-moz-control-character-visibility":"visible|hidden","-moz-osx-font-smoothing":"auto|grayscale","-moz-user-select":"none|text|all|-moz-none","-ms-flex-align":"start|end|center|baseline|stretch","-ms-flex-item-align":"auto|start|end|center|baseline|stretch","-ms-flex-line-pack":"start|end|center|justify|distribute|stretch","-ms-flex-negative":"<'flex-shrink'>","-ms-flex-pack":"start|end|center|justify|distribute","-ms-flex-order":"<integer>","-ms-flex-positive":"<'flex-grow'>","-ms-flex-preferred-size":"<'flex-basis'>","-ms-interpolation-mode":"nearest-neighbor|bicubic","-ms-grid-column-align":"start|end|center|stretch","-ms-grid-row-align":"start|end|center|stretch","-ms-hyphenate-limit-last":"none|always|column|page|spread","-webkit-background-clip":"[<box>|border|padding|content|text]#","-webkit-column-break-after":"always|auto|avoid","-webkit-column-break-before":"always|auto|avoid","-webkit-column-break-inside":"always|auto|avoid","-webkit-font-smoothing":"auto|none|antialiased|subpixel-antialiased","-webkit-mask-box-image":"[<url>|<gradient>|none] [<length-percentage>{4} <-webkit-mask-box-repeat>{2}]?","-webkit-print-color-adjust":"economy|exact","-webkit-text-security":"none|circle|disc|square","-webkit-user-drag":"none|element|auto","-webkit-user-select":"auto|none|text|all","alignment-baseline":"auto|baseline|before-edge|text-before-edge|middle|central|after-edge|text-after-edge|ideographic|alphabetic|hanging|mathematical","baseline-shift":"baseline|sub|super|<svg-length>",behavior:"<url>+",cue:"<'cue-before'> <'cue-after'>?","cue-after":"<url> <decibel>?|none","cue-before":"<url> <decibel>?|none","glyph-orientation-horizontal":"<angle>","glyph-orientation-vertical":"<angle>",kerning:"auto|<svg-length>",pause:"<'pause-before'> <'pause-after'>?","pause-after":"<time>|none|x-weak|weak|medium|strong|x-strong","pause-before":"<time>|none|x-weak|weak|medium|strong|x-strong",rest:"<'rest-before'> <'rest-after'>?","rest-after":"<time>|none|x-weak|weak|medium|strong|x-strong","rest-before":"<time>|none|x-weak|weak|medium|strong|x-strong",src:"[<url> [format( <string># )]?|local( <family-name> )]#",speak:"auto|never|always","speak-as":"normal|spell-out||digits||[literal-punctuation|no-punctuation]","unicode-range":"<urange>#","voice-balance":"<number>|left|center|right|leftwards|rightwards","voice-duration":"auto|<time>","voice-family":"[[<family-name>|<generic-voice>] ,]* [<family-name>|<generic-voice>]|preserve","voice-pitch":"<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]","voice-range":"<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]","voice-rate":"[normal|x-slow|slow|medium|fast|x-fast]||<percentage>","voice-stress":"normal|strong|moderate|none|reduced","voice-volume":"silent|[[x-soft|soft|medium|loud|x-loud]||<decibel>]","white-space-trim":"none|discard-before||discard-after||discard-inner"},atrules:{charset:{prelude:"<string>",descriptors:null},"counter-style":{prelude:"<counter-style-name>",descriptors:{"additive-symbols":"[<integer>&&<symbol>]#",fallback:"<counter-style-name>",negative:"<symbol> <symbol>?",pad:"<integer>&&<symbol>",prefix:"<symbol>",range:"[[<integer>|infinite]{2}]#|auto","speak-as":"auto|bullets|numbers|words|spell-out|<counter-style-name>",suffix:"<symbol>",symbols:"<symbol>+",system:"cyclic|numeric|alphabetic|symbolic|additive|[fixed <integer>?]|[extends <counter-style-name>]"}},document:{prelude:"[<url>|url-prefix( <string> )|domain( <string> )|media-document( <string> )|regexp( <string> )]#",descriptors:null},"font-palette-values":{prelude:"<dashed-ident>",descriptors:{"base-palette":"light|dark|<integer [0,∞]>","font-family":"<family-name>#","override-colors":"[<integer [0,∞]> <absolute-color-base>]#"}},"font-face":{prelude:null,descriptors:{"ascent-override":"normal|<percentage>","descent-override":"normal|<percentage>","font-display":"[auto|block|swap|fallback|optional]","font-family":"<family-name>","font-feature-settings":"normal|<feature-tag-value>#","font-variation-settings":"normal|[<string> <number>]#","font-stretch":"<font-stretch-absolute>{1,2}","font-style":"normal|italic|oblique <angle>{0,2}","font-weight":"<font-weight-absolute>{1,2}","line-gap-override":"normal|<percentage>","size-adjust":"<percentage>",src:"[<url> [format( <string># )]?|local( <family-name> )]#","unicode-range":"<urange>#"}},"font-feature-values":{prelude:"<family-name>#",descriptors:null},import:{prelude:"[<string>|<url>] [layer|layer( <layer-name> )]? [supports( [<supports-condition>|<declaration>] )]? <media-query-list>?",descriptors:null},keyframes:{prelude:"<keyframes-name>",descriptors:null},layer:{prelude:"[<layer-name>#|<layer-name>?]",descriptors:null},media:{prelude:"<media-query-list>",descriptors:null},namespace:{prelude:"<namespace-prefix>? [<string>|<url>]",descriptors:null},page:{prelude:"<page-selector-list>",descriptors:{bleed:"auto|<length>",marks:"none|[crop||cross]","page-orientation":"upright|rotate-left|rotate-right",size:"<length>{1,2}|auto|[<page-size>||[portrait|landscape]]"}},"position-try":{prelude:"<dashed-ident>",descriptors:{top:"<'top'>",left:"<'left'>",bottom:"<'bottom'>",right:"<'right'>","inset-block-start":"<'inset-block-start'>","inset-block-end":"<'inset-block-end'>","inset-inline-start":"<'inset-inline-start'>","inset-inline-end":"<'inset-inline-end'>","inset-block":"<'inset-block'>","inset-inline":"<'inset-inline'>",inset:"<'inset'>","margin-top":"<'margin-top'>","margin-left":"<'margin-left'>","margin-bottom":"<'margin-bottom'>","margin-right":"<'margin-right'>","margin-block-start":"<'margin-block-start'>","margin-block-end":"<'margin-block-end'>","margin-inline-start":"<'margin-inline-start'>","margin-inline-end":"<'margin-inline-end'>",margin:"<'margin'>","margin-block":"<'margin-block'>","margin-inline":"<'margin-inline'>",width:"<'width'>",height:"<'height'>","min-width":"<'min-width'>","min-height":"<'min-height'>","max-width":"<'max-width'>","max-height":"<'max-height'>","block-size":"<'block-size'>","inline-size":"<'inline-size'>","min-block-size":"<'min-block-size'>","min-inline-size":"<'min-inline-size'>","max-block-size":"<'max-block-size'>","max-inline-size":"<'max-inline-size'>","align-self":"<'align-self'>|anchor-center","justify-self":"<'justify-self'>|anchor-center"}},property:{prelude:"<custom-property-name>",descriptors:{syntax:"<string>",inherits:"true|false","initial-value":"<declaration-value>?"}},scope:{prelude:"[( <scope-start> )]? [to ( <scope-end> )]?",descriptors:null},"starting-style":{prelude:null,descriptors:null},supports:{prelude:"<supports-condition>",descriptors:null},container:{prelude:"[<container-name>]? <container-condition>",descriptors:null},nest:{prelude:"<complex-selector-list>",descriptors:null}},node:Ds};function Bs(e){switch(this.tokenType){case N:return this.Hash();case V:return this.Operator();case Z:return this.Parentheses(this.readSequence,e.recognizer);case q:return this.Brackets(this.readSequence,e.recognizer);case T:return this.String();case W:return this.Dimension();case B:return this.Percentage();case M:return this.Number();case L:return this.cmpStr(this.tokenStart,this.tokenEnd,"url(")?this.Url():this.Function(this.readSequence,e.recognizer);case I:return this.Url();case P:return this.cmpChar(this.tokenStart,117)&&this.cmpChar(this.tokenStart+1,43)?this.UnicodeRange():this.Identifier();case D:{const e=this.charCodeAt(this.tokenStart);if(47===e||42===e||43===e||45===e)return this.Operator();35===e&&this.error("Hex or identifier is expected",this.tokenStart+1);break}}}var Ws={getNode:Bs},Js={onWhiteSpace:function(e,t){null!==t.last&&"Combinator"!==t.last.type&&null!==e&&"Combinator"!==e.type&&t.push({type:"Combinator",loc:null,name:" "})},getNode:function(){switch(this.tokenType){case q:return this.AttributeSelector();case N:return this.IdSelector();case U:return this.lookupType(1)===U?this.PseudoElementSelector():this.PseudoClassSelector();case P:return this.TypeSelector();case M:case B:return this.Percentage();case W:46===this.charCodeAt(this.tokenStart)&&this.error("Identifier is expected",this.tokenStart+1);break;case D:switch(this.charCodeAt(this.tokenStart)){case 43:case 62:case 126:case 47:return this.Combinator();case 46:return this.ClassSelector();case 42:case 124:return this.TypeSelector();case 35:return this.IdSelector();case 38:return this.NestingSelector()}}}};function Fs(e){return null!==e&&"Operator"===e.type&&("-"===e.value[e.value.length-1]||"+"===e.value[e.value.length-1])}var Ys={getNode:Bs,onWhiteSpace(e,t){Fs(e)&&(e.value=" "+e.value),Fs(t.last)&&(t.last.value+=" ")},expression:function(){return this.createSingleNodeList(this.Raw(null,!1))},var:function(){const e=this.createList();if(this.skipSC(),e.push(this.Identifier()),this.skipSC(),this.tokenType===V){e.push(this.Operator());const t=this.tokenIndex,n=this.parseCustomProperty?this.Value(null):this.Raw(this.consumeUntilExclamationMarkOrSemicolon,!1);if("Value"===n.type&&n.children.isEmpty)for(let e=t-this.tokenIndex;e<=0;e++)if(this.lookupType(e)===J){n.children.appendData({type:"WhiteSpace",loc:null,value:" "});break}e.push(n)}return e}},Us=Object.freeze({__proto__:null,AtrulePrelude:Ws,Selector:Js,Value:Ys});const $s=new Set(["none","and","not","or"]);var Vs={parse:{prelude(){const e=this.createList();if(this.tokenType===P){const t=this.substring(this.tokenStart,this.tokenEnd);$s.has(t.toLowerCase())||e.push(this.Identifier())}return e.push(this.Condition("container")),e},block(e=!1){return this.Block(e)}}};function qs(e,t){return this.parseWithFallback((()=>{try{return e.call(this)}finally{this.skipSC(),this.lookupNonWSType(0)!==K&&this.error()}}),t||(()=>this.Raw(null,!0)))}const Hs={layer(){this.skipSC();const e=this.createList(),t=qs.call(this,this.Layer);return"Raw"===t.type&&""===t.value||e.push(t),e},supports(){this.skipSC();const e=this.createList(),t=qs.call(this,this.Declaration,(()=>qs.call(this,(()=>this.Condition("supports")))));return"Raw"===t.type&&""===t.value||e.push(t),e}},Zs={parse(){return this.createSingleNodeList(this.SelectorList())}},Ks={parse(){return this.createSingleNodeList(this.Selector())}},Gs={parse(){return this.createSingleNodeList(this.Nth())}};var Xs=function e(t){const n=function(e){let t="",n="<unknown>",r=!1,o=Ke,i=!1;const a=new je,s=Object.assign(new Be,function(e){const t={context:Object.create(null),features:Object.assign(Object.create(null),e.features),scope:Object.assign(Object.create(null),e.scope),atrule:rt(e.atrule),pseudo:rt(e.pseudo),node:rt(e.node)};for(const[n,r]of Object.entries(e.parseContext))switch(typeof r){case"function":t.context[n]=r;break;case"string":t.context[n]=nt(r)}return{config:t,...t,...t.node}}(e||{}),{parseAtrulePrelude:!0,parseRulePrelude:!0,parseValue:!0,parseCustomProperty:!1,readSequence:Ze,consumeUntilBalanceEnd:()=>0,consumeUntilLeftCurlyBracket:e=>e===et?1:0,consumeUntilLeftCurlyBracketOrSemicolon:e=>e===et||e===Qe?1:0,consumeUntilExclamationMarkOrSemicolon:e=>e===Ge||e===Qe?1:0,consumeUntilSemicolonIncluded:e=>e===Qe?2:0,createList:()=>new Fe,createSingleNodeList:e=>(new Fe).appendData(e),getFirstListNode:e=>e&&e.first,getLastListNode:e=>e&&e.last,parseWithFallback(e,t){const n=this.tokenIndex;try{return e.call(this)}catch(e){if(i)throw e;this.skip(n-this.tokenIndex);const r=t.call(this);return i=!0,o(e,r),i=!1,r}},lookupNonWSType(e){let t;do{if(t=this.lookupType(e++),t!==J&&t!==Q)return t}while(t!==tt);return tt},charCodeAt:e=>e>=0&&e<t.length?t.charCodeAt(e):0,substring:(e,n)=>t.substring(e,n),substrToCursor(e){return this.source.substring(e,this.tokenStart)},cmpChar:(e,n)=>we(t,e,n),cmpStr:(e,n,r)=>ke(t,e,n,r),consume(e){const t=this.tokenStart;return this.eat(e),this.substrToCursor(t)},consumeFunctionName(){const e=t.substring(this.tokenStart,this.tokenEnd-1);return this.eat(L),e},consumeNumber(e){const n=t.substring(this.tokenStart,Ee(t,this.tokenStart));return this.eat(e),n},eat(e){if(this.tokenType!==e){const t=Le[e].slice(0,-6).replace(/-/g," ").replace(/^./,(e=>e.toUpperCase()));let n=`${/[[\](){}]/.test(t)?`"${t}"`:t} is expected`,r=this.tokenStart;switch(e){case P:this.tokenType===L||this.tokenType===I?(r=this.tokenEnd-1,n="Identifier is expected but function found"):n="Identifier is expected";break;case N:this.isDelim(Xe)&&(this.next(),r++,n="Name is expected");break;case B:this.tokenType===M&&(r=this.tokenEnd,n="Percent sign is expected")}this.error(n,r)}this.next()},eatIdent(e){this.tokenType===P&&!1!==this.lookupValue(0,e)||this.error(`Identifier "${e}" is expected`),this.next()},eatDelim(e){this.isDelim(e)||this.error(`Delim "${String.fromCharCode(e)}" is expected`),this.next()},getLocation:(e,t)=>r?a.getLocationRange(e,t,n):null,getLocationFromList(e){if(r){const t=this.getFirstListNode(e),r=this.getLastListNode(e);return a.getLocationRange(null!==t?t.loc.start.offset-a.startOffset:this.tokenStart,null!==r?r.loc.end.offset-a.startOffset:this.tokenStart,n)}return null},error(e,n){const r=void 0!==n&&n<t.length?a.getLocation(n):this.eof?a.getLocation(function(e,t){for(;t>=0&&le(e.charCodeAt(t));t--);return t+1}(t,t.length-1)):a.getLocation(this.tokenStart);throw new He(e||"Unexpected input",t,r.offset,r.line,r.column,a.startLine,a.startColumn)}});return Object.assign((function(e,l){t=e,l=l||{},s.setSource(t,We),a.setSource(t,l.offset,l.line,l.column),n=l.filename||"<unknown>",r=Boolean(l.positions),o="function"==typeof l.onParseError?l.onParseError:Ke,i=!1,s.parseAtrulePrelude=!("parseAtrulePrelude"in l)||Boolean(l.parseAtrulePrelude),s.parseRulePrelude=!("parseRulePrelude"in l)||Boolean(l.parseRulePrelude),s.parseValue=!("parseValue"in l)||Boolean(l.parseValue),s.parseCustomProperty="parseCustomProperty"in l&&Boolean(l.parseCustomProperty);const{context:c="default",onComment:u}=l;if(c in s.context==0)throw new Error("Unknown context `"+c+"`");"function"==typeof u&&s.forEachToken(((e,n,r)=>{if(e===Q){const e=s.getLocation(n,r),o=ke(t,r-2,r,"*/")?t.slice(n+2,r-2):t.slice(n+2,r);u(o,e)}}));const d=s.context[c].call(s,l);return s.eof||s.error(),d}),{SyntaxError:He,config:s.config})}(t),r=function(e){const t=function(e){const t={};for(const n in e.node)if(jt.call(e.node,n)){const r=e.node[n];if(!r.structure)throw new Error("Missed `structure` field in `"+n+"` node type definition");t[n]=Mt(0,r)}return t}(e),n={},r={},o=Symbol("break-walk"),i=Symbol("skip-node");for(const e in t)jt.call(t,e)&&null!==t[e]&&(n[e]=Bt(t[e],!1),r[e]=Bt(t[e],!0));const a=Wt(n),s=Wt(r),l=function(e,l){function c(e,t,n){const r=u.call(f,e,t,n);return r===o||r!==i&&(!(!h.hasOwnProperty(e.type)||!h[e.type](e,f,c,p))||d.call(f,e,t,n)===o)}let u=It,d=It,h=n,p=(e,t,n,r)=>e||c(t,n,r);const f={break:o,skip:i,root:e,stylesheet:null,atrule:null,atrulePrelude:null,rule:null,selector:null,block:null,declaration:null,function:null};if("function"==typeof l)u=l;else if(l&&(u=Rt(l.enter),d=Rt(l.leave),l.reverse&&(h=r),l.visit)){if(a.hasOwnProperty(l.visit))h=l.reverse?s[l.visit]:a[l.visit];else if(!t.hasOwnProperty(l.visit))throw new Error("Bad value `"+l.visit+"` for `visit` option (should be: "+Object.keys(t).sort().join(", ")+")");u=Dt(u,l.visit),d=Dt(d,l.visit)}if(u===It&&d===It)throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");c(e)};return l.break=o,l.skip=i,l.find=function(e,t){let n=null;return l(e,(function(e,r,i){if(t.call(this,e,r,i))return n=e,o})),n},l.findLast=function(e,t){let n=null;return l(e,{reverse:!0,enter(e,r,i){if(t.call(this,e,r,i))return n=e,o}}),n},l.findAll=function(e,t){const n=[];return l(e,(function(e,r,o){t.call(this,e,r,o)&&n.push(e)})),n},l}(t),o=function(e){const t=new Map;for(let[n,r]of Object.entries(e.node))"function"==typeof(r.generate||r)&&t.set(n,r.generate||r);return function(e,n){let r="",o=0,i={node(e){if(!t.has(e.type))throw new Error("Unknown node type: "+e.type);t.get(e.type).call(a,e)},tokenBefore:Pt,token(e,t){o=this.tokenBefore(o,e,t),this.emit(t,e,!1),e===D&&t.charCodeAt(0)===zt&&this.emit("\n",J,!0)},emit(e){r+=e},result:()=>r};n&&("function"==typeof n.decorator&&(i=n.decorator(i)),n.sourceMap&&(i=function(e){const t=new kt,n={line:1,column:0},r={line:0,column:0},o={line:1,column:0},i={generated:o};let a=1,s=0,l=!1;const c=e.node;e.node=function(e){if(e.loc&&e.loc.start&&xt.has(e.type)){const c=e.loc.start.line,u=e.loc.start.column-1;r.line===c&&r.column===u||(r.line=c,r.column=u,n.line=a,n.column=s,l&&(l=!1,n.line===o.line&&n.column===o.column||t.addMapping(i)),l=!0,t.addMapping({source:e.loc.source,original:r,generated:n}))}c.call(this,e),l&&xt.has(e.type)&&(o.line=a,o.column=s)};const u=e.emit;e.emit=function(e,t,n){for(let t=0;t<e.length;t++)10===e.charCodeAt(t)?(a++,s=0):s++;u(e,t,n)};const d=e.result;return e.result=function(){return l&&t.addMapping(i),{css:d(),map:t}},e}(i)),n.mode in Lt&&(i.tokenBefore=Lt[n.mode]));const a={node:e=>i.node(e),children:Nt,token:(e,t)=>i.token(e,t),tokenize:Tt};return i.node(e),i.result()}}(t),{fromPlainObject:i,toPlainObject:a}=function(e){return{fromPlainObject:t=>(e(t,{enter(e){e.children&&e.children instanceof Fe==0&&(e.children=(new Fe).fromArray(e.children))}}),t),toPlainObject:t=>(e(t,{leave(e){e.children&&e.children instanceof Fe&&(e.children=e.children.toArray())}}),t)}}(r),s={lexer:null,createLexer:e=>new no(e,s,s.lexer.structure),tokenize:We,parse:n,generate:o,walk:r,find:r.find,findLast:r.findLast,findAll:r.findAll,fromPlainObject:i,toPlainObject:a,fork(n){const r=io({},t);return e("function"==typeof n?n(r):io(r,n))}};return s.lexer=new no({generic:t.generic,cssWideKeywords:t.cssWideKeywords,units:t.units,types:t.types,atrules:t.atrules,properties:t.properties,node:t.node},s),s}(io({},{...Ms,parseContext:{default:"StyleSheet",stylesheet:"StyleSheet",atrule:"Atrule",atrulePrelude(e){return this.AtrulePrelude(e.atrule?String(e.atrule):null)},mediaQueryList:"MediaQueryList",mediaQuery:"MediaQuery",condition(e){return this.Condition(e.kind)},rule:"Rule",selectorList:"SelectorList",selector:"Selector",block(){return this.Block(!0)},declarationList:"DeclarationList",declaration:"Declaration",value:"Value"},features:{supports:{selector(){return this.Selector()}},container:{style(){return this.Declaration()}}},scope:Us,atrule:{container:Vs,"font-face":{parse:{prelude:null,block(){return this.Block(!0)}}},import:{parse:{prelude(){const e=this.createList();switch(this.tokenType){case T:e.push(this.String());break;case I:case L:e.push(this.Url());break;default:this.error("String or url() is expected")}return this.skipSC(),this.tokenType===P&&this.cmpStr(this.tokenStart,this.tokenEnd,"layer")?e.push(this.Identifier()):this.tokenType===L&&this.cmpStr(this.tokenStart,this.tokenEnd,"layer(")&&e.push(this.Function(null,Hs)),this.skipSC(),this.tokenType===L&&this.cmpStr(this.tokenStart,this.tokenEnd,"supports(")&&e.push(this.Function(null,Hs)),this.lookupNonWSType(0)!==P&&this.lookupNonWSType(0)!==Z||e.push(this.MediaQueryList()),e},block:null}},layer:{parse:{prelude(){return this.createSingleNodeList(this.LayerList())},block(){return this.Block(!1)}}},media:{parse:{prelude(){return this.createSingleNodeList(this.MediaQueryList())},block(e=!1){return this.Block(e)}}},nest:{parse:{prelude(){return this.createSingleNodeList(this.SelectorList())},block(){return this.Block(!0)}}},page:{parse:{prelude(){return this.createSingleNodeList(this.SelectorList())},block(){return this.Block(!0)}}},scope:{parse:{prelude(){return this.createSingleNodeList(this.Scope())},block(e=!1){return this.Block(e)}}},"starting-style":{parse:{prelude:null,block(e=!1){return this.Block(e)}}},supports:{parse:{prelude(){return this.createSingleNodeList(this.Condition("supports"))},block(e=!1){return this.Block(e)}}}},pseudo:{dir:{parse(){return this.createSingleNodeList(this.Identifier())}},has:Zs,lang:{parse:function(){const e=this.createList();this.skipSC();e:for(;!this.eof;){switch(this.tokenType){case P:e.push(this.Identifier());break;case T:e.push(this.String());break;case V:e.push(this.Operator());break;case K:break e;default:this.error("Identifier, string or comma is expected")}this.skipSC()}return e}},matches:Zs,is:Zs,"-moz-any":Zs,"-webkit-any":Zs,where:Zs,not:Zs,"nth-child":Gs,"nth-last-child":Gs,"nth-last-of-type":Gs,"nth-of-type":Gs,slotted:Ks,host:Ks,"host-context":Ks},node:Object.freeze({__proto__:null,AnPlusB:go,Atrule:wo,AtrulePrelude:xo,AttributeSelector:jo,Block:Wo,Brackets:Fo,CDC:Uo,CDO:Vo,ClassSelector:Zo,Combinator:Xo,Comment:ti,Condition:si,Declaration:vi,DeclarationList:Oi,Dimension:Ci,Feature:zi,FeatureFunction:Ii,FeatureRange:Ui,Function:qi,GeneralEnclosed:Ki,Hash:Qi,IdSelector:ia,Identifier:na,Layer:la,LayerList:ua,MediaQuery:pa,MediaQueryList:ma,NestingSelector:ya,Nth:_a,Number:ka,Operator:Oa,Parentheses:Ea,Percentage:La,PseudoClassSelector:Ta,PseudoElementSelector:Ra,Ratio:Ba,Raw:Ya,Rule:qa,Scope:Za,Selector:Ga,SelectorList:Qa,String:as,StyleSheet:cs,SupportsDeclaration:ds,TypeSelector:gs,UnicodeRange:As,Url:Ps,Value:zs,WhiteSpace:Is}),node:Ds}));const{tokenize:Qs,parse:el,generate:tl,lexer:nl,createLexer:rl,walk:ol,find:il,findLast:al,findAll:sl,toPlainObject:ll,fromPlainObject:cl,fork:ul}=Xs,dl=new Map([["background",new Set(["background-color","background-position","background-position-x","background-position-y","background-size","background-repeat","background-repeat-x","background-repeat-y","background-clip","background-origin","background-attachment","background-image"])],["background-position",new Set(["background-position-x","background-position-y"])],["background-repeat",new Set(["background-repeat-x","background-repeat-y"])],["font",new Set(["font-style","font-variant-caps","font-weight","font-stretch","font-size","line-height","font-family","font-size-adjust","font-kerning","font-optical-sizing","font-palette","font-synthesis-style","font-synthesis-weight","font-synthesis-small-caps","font-variant-alternates","font-variant-east-asian","font-variant-emoji","font-variant-ligatures","font-variant-numeric","font-variant-position","font-language-override","font-feature-settings","font-variation-settings"])],["font-synthesis",new Set(["font-synthesis-style","font-synthesis-weight","font-synthesis-small-caps"])],["font-variant",new Set(["font-variant-caps","font-variant-numeric","font-variant-alternates","font-variant-ligatures","font-variant-east-asian","font-variant-emoji","font-variant-position"])],["outline",new Set(["outline-width","outline-style","outline-color"])],["border",new Set(["border-top-width","border-right-width","border-bottom-width","border-left-width","border-top-style","border-right-style","border-bottom-style","border-left-style","border-top-color","border-right-color","border-bottom-color","border-left-color","border-image-source","border-image-slice","border-image-width","border-image-outset","border-image-repeat"])],["border-width",new Set(["border-top-width","border-right-width","border-bottom-width","border-left-width"])],["border-style",new Set(["border-top-style","border-right-style","border-bottom-style","border-left-style"])],["border-color",new Set(["border-top-color","border-right-color","border-bottom-color","border-left-color"])],["border-top",new Set(["border-top-width","border-top-style","border-top-color"])],["border-right",new Set(["border-right-width","border-right-style","border-right-color"])],["border-bottom",new Set(["border-bottom-width","border-bottom-style","border-bottom-color"])],["border-left",new Set(["border-left-width","border-left-style","border-left-color"])],["border-block",new Set(["border-block-start-width","border-block-end-width","border-block-start-style","border-block-end-style","border-block-start-color","border-block-end-color"])],["border-block-start",new Set(["border-block-start-width","border-block-start-style","border-block-start-color"])],["border-block-end",new Set(["border-block-end-width","border-block-end-style","border-block-end-color"])],["border-inline",new Set(["border-inline-start-width","border-inline-end-width","border-inline-start-style","border-inline-end-style","border-inline-start-color","border-inline-end-color"])],["border-inline-start",new Set(["border-inline-start-width","border-inline-start-style","border-inline-start-color"])],["border-inline-end",new Set(["border-inline-end-width","border-inline-end-style","border-inline-end-color"])],["border-image",new Set(["border-image-source","border-image-slice","border-image-width","border-image-outset","border-image-repeat"])],["border-radius",new Set(["border-top-left-radius","border-top-right-radius","border-bottom-right-radius","border-bottom-left-radius"])],["padding",new Set(["padding-top","padding-right","padding-bottom","padding-left"])],["padding-block",new Set(["padding-block-start","padding-block-end"])],["padding-inline",new Set(["padding-inline-start","padding-inline-end"])],["margin",new Set(["margin-top","margin-right","margin-bottom","margin-left"])],["margin-block",new Set(["margin-block-start","margin-block-end"])],["margin-inline",new Set(["margin-inline-start","margin-inline-end"])],["inset",new Set(["top","right","bottom","left"])],["inset-block",new Set(["inset-block-start","inset-block-end"])],["inset-inline",new Set(["inset-inline-start","inset-inline-end"])],["flex",new Set(["flex-grow","flex-shrink","flex-basis"])],["flex-flow",new Set(["flex-direction","flex-wrap"])],["gap",new Set(["row-gap","column-gap"])],["transition",new Set(["transition-duration","transition-timing-function","transition-delay","transition-property"])],["grid",new Set(["grid-template-rows","grid-template-columns","grid-template-areas","grid-auto-flow","grid-auto-columns","grid-auto-rows"])],["grid-template",new Set(["grid-template-rows","grid-template-columns","grid-template-areas"])],["grid-row",new Set(["grid-row-start","grid-row-end"])],["grid-column",new Set(["grid-column-start","grid-column-end"])],["grid-gap",new Set(["grid-row-gap","grid-column-gap","row-gap","column-gap"])],["place-content",new Set(["align-content","justify-content"])],["place-items",new Set(["align-items","justify-items"])],["place-self",new Set(["align-self","justify-self"])],["columns",new Set(["column-width","column-count"])],["column-rule",new Set(["column-rule-width","column-rule-style","column-rule-color"])],["list-style",new Set(["list-style-type","list-style-position","list-style-image"])],["offset",new Set(["offset-position","offset-path","offset-distance","offset-rotate","offset-anchor"])],["overflow",new Set(["overflow-x","overflow-y"])],["overscroll-behavior",new Set(["overscroll-behavior-x","overscroll-behavior-y"])],["scroll-margin",new Set(["scroll-margin-top","scroll-margin-right","scroll-margin-bottom","scroll-margin-left"])],["scroll-padding",new Set(["scroll-padding-top","scroll-padding-right","scroll-padding-bottom","scroll-padding-left"])],["text-decoration",new Set(["text-decoration-line","text-decoration-style","text-decoration-color","text-decoration-thickness"])],["text-stroke",new Set(["text-stroke-color","text-stroke-width"])],["animation",new Set(["animation-duration","animation-timing-function","animation-delay","animation-iteration-count","animation-direction","animation-fill-mode","animation-play-state","animation-name","animation-timeline","animation-range-start","animation-range-end"])],["mask",new Set(["mask-image","mask-mode","mask-repeat-x","mask-repeat-y","mask-position-x","mask-position-y","mask-clip","mask-origin","mask-size","mask-composite"])],["mask-repeat",new Set(["mask-repeat-x","mask-repeat-y"])],["mask-position",new Set(["mask-position-x","mask-position-y"])],["perspective-origin",new Set(["perspective-origin-x","perspective-origin-y"])],["transform-origin",new Set(["transform-origin-x","transform-origin-y","transform-origin-z"])],["white-space",new Set(["white-space-collapse","text-wrap"])]]),hl=new Map([gl("animation","moz"),gl("border-image","moz"),gl("mask","moz"),gl("transition","moz"),gl("columns","moz"),gl("text-stroke","moz"),gl("column-rule","moz"),["-moz-border-end",new Set(["-moz-border-end-color","-moz-border-end-style","-moz-border-end-width"])],["-moz-border-start",new Set(["-moz-border-start-color","-moz-border-start-style","-moz-border-start-width"])],["-moz-outline-radius",new Set(["-moz-outline-radius-topleft","-moz-outline-radius-topright","-moz-outline-radius-bottomright","-moz-outline-radius-bottomleft"])]]),pl=new Map([gl("animation","webkit"),gl("border-radius","webkit"),gl("column-rule","webkit"),gl("columns","webkit"),gl("flex","webkit"),gl("flex-flow","webkit"),gl("mask","webkit"),gl("text-stroke","webkit"),gl("perspective-origin","webkit"),gl("transform-origin","webkit"),gl("transition","webkit"),["-webkit-border-start",new Set(["-webkit-border-start-color","-webkit-border-start-style","-webkit-border-start-width"])],["-webkit-border-before",new Set(["-webkit-border-before-color","-webkit-border-before-style","-webkit-border-before-width"])],["-webkit-border-end",new Set(["-webkit-border-end-color","-webkit-border-end-style","-webkit-border-end-width"])],["-webkit-border-after",new Set(["-webkit-border-after-color","-webkit-border-after-style","-webkit-border-after-width"])]]),fl=["background-position","background-repeat","text-decoration"];hl.forEach(((e,t)=>dl.set(t,e))),pl.forEach(((e,t)=>dl.set(t,e)));const ml=new Map;function gl(e,t){const n=dl.get(e);if(n)return[`-${t}-${e}`,new Set(Array.from(n,(e=>`-${t}-${e}`)))]}function yl(e,t){const n=dl.get(e);return!!n&&n.has(t)}dl.forEach(((e,t)=>{e.forEach((e=>{ml.get(e)||ml.set(e,new Set),ml.get(e).add(t)}))}));const bl=new Set(["border-top","border-right","border-bottom","border-left"]);function _l(e,t){const n=Array.from(e).reduce(((t,n)=>{const r=vl(e,n);t.set(r,wl(e,r));const o=function(e){return ml.get(e)}(n);return o&&o.forEach((n=>{const r=e.getPropertyValue(n);r&&(bl.has(n)&&e.getPropertyValue("border")===r||(t.delete(n),t.set(n,wl(e,n))))})),t}),new Map);return null==t||t.forEach(((t,r)=>{const o=vl(e,r);n.set(o,{type:"Declaration",important:"important"===e.getPropertyPriority(o),property:o,value:{type:"Raw",value:t}})})),Array.from(n.values())}function vl(e,t){const n=function(e){return fl.find((t=>dl.get(t).has(e)))}(t);return n&&e.getPropertyValue(n)?n:t}function wl(e,t){return{type:"Declaration",important:Boolean(e.getPropertyPriority(t)),property:t,value:{type:"Raw",value:e.getPropertyValue(t)}}}const kl={CSSPropertyRule:{atrule:"property",prelude:"name"},2:{atrule:"charset",prelude:"charset"},CSSImportRule:{atrule:"import",prelude:"import"},CSSNamespaceRule:{atrule:"namespace",prelude:"namespace"},CSSStyleRule:{prelude:"selector",block:"style-and-nested"},CSSKeyframeRule:{prelude:"key",block:"style"},CSSPageRule:{atrule:"page",prelude:"selector",block:"style"},CSSFontFaceRule:{atrule:"font-face",block:"style"},CSSMediaRule:{atrule:"media",prelude:"condition",block:"nested"},CSSSupportsRule:{atrule:"supports",prelude:"condition",block:"nested"},13:{atrule:"document",prelude:"condition",block:"nested"},CSSKeyframesRule:{atrule:"keyframes",prelude:"name",block:"nested"},CSSContainerRule:{atrule:"container",prelude:"condition",block:"nested"},CSSLayerStatementRule:{atrule:"layer",prelude:"nameList"},CSSLayerBlockRule:{atrule:"layer",prelude:"name",block:"nested"}};function xl(e,t,n){return Array.from(e,(e=>{var r,o,i;const a=null!==(r=kl[e.type])&&void 0!==r?r:kl[e.constructor.name];if(!a)return t.error(`createAstFromCssom | Unknown CSS object model rule ${e.constructor.name} ${null===(o=e.cssText)||void 0===o?void 0:o.substring(0,150)}`),{type:"Raw",value:e.cssText||""};const s={};if(a.atrule){s.type="Atrule";const[t,n]=e.cssText.match(new RegExp(`^@(-\\w+-)?${a.atrule}`))||[];s.name=n?n+a.atrule:a.atrule}else s.type="Rule";let l;if("property"===a.atrule?(l=e.name,s.syntax=e.syntax,s.inherits=e.inherits,s.initialValue=e.initialValue):"selector"===a.prelude?l=e.selectorText:"key"===a.prelude?l=e.keyText:"condition"===a.prelude?l=e.conditionText:"name"===a.prelude?l=e.name:"import"===a.prelude?l=`url("${e.href}") ${e.media.mediaText}`:"namespace"===a.prelude?l=`${e.prefix} url("${e.namespaceURI}")`:"charset"===a.prelude?l=`"${e.encoding}"`:"nameList"===a.prelude&&(l=e.nameList),l){const e=a.atrule?{context:"atrulePrelude",atrule:a.atrule}:{context:"selectorList"};s.prelude=ll(el(l,e))}else s.prelude=null;if("style-and-nested"===a.block){const r=_l(e.style,null==n?void 0:n.get(e)),o=e.cssRules,i=(null==o?void 0:o.length)?xl(o,t,n):[];s.block={type:"Block",children:r.concat(i)}}else"nested"===a.block||(null===(i=e.cssRules)||void 0===i?void 0:i.length)>0?s.block={type:"Block",children:xl(e.cssRules,t,n)}:"style"===a.block?s.block={type:"Block",children:_l(e.style,null==n?void 0:n.get(e))}:s.block=null;return s}))}const Sl=new Set(["before","after","first-line","first-letter"]),Ol={"word-wrap":"overflow-wrap",clip:"clip-path"};function Al(e,t){let n=0;const r=[];return e.forEach((e=>{const o={};o.type=e.type,o.name=e.name,o.prelude=e.prelude,o.block=e.block;const i=function(e,t,n){return function(e,t,n){for(let r=t;r<e.length;++r)if(n(e[r]))return r;return-1}(e,t,(e=>{return e.type===n.type&&e.name===n.name&&(t=e.prelude,r=n.prelude,!t&&!r||t.type===r.type&&Cl(t.children,r.children))&&(!Pl(n)||function(e,t){const n=t.reduce(((t,n)=>{const r="Declaration"===n.type&&(function(e){return/^(-\w+-)/.test(e)}(n.property)||e.some((e=>function(e,t){const n=Ol[e]||e,r=Ol[t]||t;return n===r||yl(r,n)||yl(n,r)}(e.property,n.property))));return t+(r?1:0)}),0),r=t.filter((e=>"Rule"!==e.type&&"Atrule"!==e.type)).length;return n>=r}(e.block.children,n.block.children));var t,r}))}(t,n,e);if(i>n&&Ll(t,n,i,(e=>r.push(e))),i>=0)if(n=i+1,function(e){return"Atrule"===e.type&&/^(-\w+-)?(media|supports|document|keyframes|layer)$/.test(e.name)}(e))o.block={type:"Block",children:Al(e.block.children,t[i].block.children)};else if(Pl(e)){const n=e.block.children,r=t[i].block.children,a=n.some((e=>"Rule"===e.type||"Atrule"===e.type)),s=r.some((e=>"Rule"===e.type||"Atrule"===e.type));o.block=a||s?{type:"Block",children:Al(n,r)}:{type:"Block",children:El(n,r)}}r.push(o)}),[]),n<t.length&&Ll(t,n,t.length,(e=>r.push(e))),r}function El(e,t){let n=[];return e.forEach((e=>{"Declaration"===e.type&&n.push(e)})),t.forEach((e=>{if("Declaration"!==e.type)return;if(t=e.property,n.map((e=>e.property)).some((e=>yl(e,t))))return;var t;const r=n.filter((t=>t.property===e.property));if(0===r.length)n.push(e);else{const t=r.slice().reverse().find((t=>t.value.value===e.value.value));if(t)t.important!==e.important&&r.forEach((t=>t.important=e.important));else{if(o=e.property,dl.has(o))return;n=n.filter((t=>t.property!==e.property)),n.push(e)}}var o})),n}function Cl(e,t){return!Array.isArray(e)&&!Array.isArray(t)||Array.isArray(e)&&Array.isArray(t)&&e.length===t.length&&e.every(((e,n)=>{const r=t[n];return e.type===r.type&&((a=e.name)===(s=r.name)||a&&s&&a.name&&a.name===s.name)&&((o=e.value)===(i=r.value)||o.type===i.type&&o.value===i.value)&&Cl(e.children,r.children);var o,i,a,s}))}function Pl(e){return"Rule"===e.type||/^(-\w+-)?(page|font-face)$/.test(e.name)}function Ll(e,t,n,r){for(let o=t;o<n;++o)r(e[o],o,e)}function zl(e){const t=Array.from(e.attributes).map((t=>"id"===t.name?`#${t.value}`:"class"===t.name?Array.from(e.classList).map((e=>`.${e}`)).join(""):`[${t.name}="${t.value}"]`)).join("");return`${e.nodeName}${t}`}function Nl(e,n){const r=new Map,o=[];let i=0,a=!1;return function e(s){for(const l of Array.from(s)){const s=i++,c=l.style,u=l.selectorText;if(c&&"string"==typeof u){const i=Array.from(c).filter((e=>!c.getPropertyValue(e)));if(i.length>0){"CSSStyleRule"===l.constructor.name&&(a=!0);try{const e=n.querySelector(u);if(e){const n=t.getComputedStyle(e),a=new Map;for(const e of i){const t=n.getPropertyValue(e);t&&a.set(e,t)}a.size>0&&(r.set(l,a),o.push([s,Array.from(a)]))}}catch(e){}}}l.cssRules&&e(l.cssRules)}}(e),{resolved:r,signature:JSON.stringify(o),hasEmptyLonghands:a}}function Tl(e,t,n){t.log("[processInlineCss] processing inline css for",zl(e));try{const r=e.getRootNode(),o=e.ownerDocument,i=r!==o&&11===r.nodeType,a=i?r:o,{resolved:s,signature:l,hasEmptyLonghands:c}=Nl(e.sheet.cssRules,a),u=e.textContent;let d;if(n){const e=JSON.stringify([i,n.cssomKey,l]);d=n.results.get(e),d||n.results.set(e,d=[]);const r=d.find((e=>e.textContent===u));if(r)return t.log("[processInlineCss] reusing css of an identical style element"),r.cssText}const h=function(e){const t=el(e,{context:"stylesheet",parseAtrulePrelude:!0,parseRulePrelude:!0,parseValue:!1,parseCustomProperty:!1});return ol(t,{visit:"TypeSelector",enter(e,t){"from"===e.name?t.data={type:"Percentage",value:"0"}:"to"===e.name&&(t.data={type:"Percentage",value:"100"})}}),ol(t,{visit:"AtrulePrelude",enter(e){if(["import","namespace"].includes(this.atrule.name)){const t=e.children.toArray(),n="import"===e.name?0:t.length-1,r=t[n];"String"===r.type&&(t[n]={type:"Url",value:r.value},e.children.fromArray(t))}}}),ol(t,{visit:"PseudoClassSelector",enter(e){Sl.has(e.name)&&(e.type="PseudoElementSelector")}}),ol(t,{visit:"Selector",enter(e){const t=e.children.toArray();if(t.length>1){const n=t.filter(((e,n)=>{const r=t[n+1],o=r?"PseudoClassSelector"===r.type||"PseudoElementSelector"===r.type:void 0;return!("*"===e.name&&"TypeSelector"===e.type&&o)}));e.children.fromArray(n.length?n:null)}}}),ol(t,{visit:"AttributeSelector",enter(e){e.value&&"Identifier"===e.value.type&&(e.value={type:"String",value:e.value.name})}}),ll(t)}(u);t.log("[processInlineCss] created AST for textContent");const p=!u||""===u.trim(),f=(i||p)&&c,m=xl(e.sheet.cssRules,t,s);t.log("[processInlineCss] created AST for CSSOM");const g=f?m:Al(h.children,m);t.log("[processInlineCss] merged AST");const y=tl(cl({type:"StyleSheet",children:g}));return t.log("[processInlineCss] generated cssText of length",y.length),null==d||d.push({textContent:u,cssText:y}),y}catch(n){return t.log("[processInlineCss] error while processing inline css:",n.message,n),t.log("[processInlineCss] try to set fallback"),"string"==typeof e.textContent&&e.textContent.length>0?(t.log("[processInlineCss] set style from `styleNode.textContent`"),e.textContent):e.sheet&&e.sheet.cssRules?(t.log("[processInlineCss] set style from reduce `sheet.cssRules`"),Array.from(e.sheet.cssRules).reduce(((e,{cssText:t})=>e+t),"")):(t.log("[processInlineCss] could not set fallback to inline css"),"")}}function jl(e,t){let n=e[0],r=e[1],o=e[2],i=e[3];n=Rl(n,r,o,i,t[0],7,-680876936),i=Rl(i,n,r,o,t[1],12,-389564586),o=Rl(o,i,n,r,t[2],17,606105819),r=Rl(r,o,i,n,t[3],22,-1044525330),n=Rl(n,r,o,i,t[4],7,-176418897),i=Rl(i,n,r,o,t[5],12,1200080426),o=Rl(o,i,n,r,t[6],17,-1473231341),r=Rl(r,o,i,n,t[7],22,-45705983),n=Rl(n,r,o,i,t[8],7,1770035416),i=Rl(i,n,r,o,t[9],12,-1958414417),o=Rl(o,i,n,r,t[10],17,-42063),r=Rl(r,o,i,n,t[11],22,-1990404162),n=Rl(n,r,o,i,t[12],7,1804603682),i=Rl(i,n,r,o,t[13],12,-40341101),o=Rl(o,i,n,r,t[14],17,-1502002290),r=Rl(r,o,i,n,t[15],22,1236535329),n=Dl(n,r,o,i,t[1],5,-165796510),i=Dl(i,n,r,o,t[6],9,-1069501632),o=Dl(o,i,n,r,t[11],14,643717713),r=Dl(r,o,i,n,t[0],20,-373897302),n=Dl(n,r,o,i,t[5],5,-701558691),i=Dl(i,n,r,o,t[10],9,38016083),o=Dl(o,i,n,r,t[15],14,-660478335),r=Dl(r,o,i,n,t[4],20,-405537848),n=Dl(n,r,o,i,t[9],5,568446438),i=Dl(i,n,r,o,t[14],9,-1019803690),o=Dl(o,i,n,r,t[3],14,-187363961),r=Dl(r,o,i,n,t[8],20,1163531501),n=Dl(n,r,o,i,t[13],5,-1444681467),i=Dl(i,n,r,o,t[2],9,-51403784),o=Dl(o,i,n,r,t[7],14,1735328473),r=Dl(r,o,i,n,t[12],20,-1926607734),n=Ml(n,r,o,i,t[5],4,-378558),i=Ml(i,n,r,o,t[8],11,-2022574463),o=Ml(o,i,n,r,t[11],16,1839030562),r=Ml(r,o,i,n,t[14],23,-35309556),n=Ml(n,r,o,i,t[1],4,-1530992060),i=Ml(i,n,r,o,t[4],11,1272893353),o=Ml(o,i,n,r,t[7],16,-155497632),r=Ml(r,o,i,n,t[10],23,-1094730640),n=Ml(n,r,o,i,t[13],4,681279174),i=Ml(i,n,r,o,t[0],11,-358537222),o=Ml(o,i,n,r,t[3],16,-722521979),r=Ml(r,o,i,n,t[6],23,76029189),n=Ml(n,r,o,i,t[9],4,-640364487),i=Ml(i,n,r,o,t[12],11,-421815835),o=Ml(o,i,n,r,t[15],16,530742520),r=Ml(r,o,i,n,t[2],23,-995338651),n=Bl(n,r,o,i,t[0],6,-198630844),i=Bl(i,n,r,o,t[7],10,1126891415),o=Bl(o,i,n,r,t[14],15,-1416354905),r=Bl(r,o,i,n,t[5],21,-57434055),n=Bl(n,r,o,i,t[12],6,1700485571),i=Bl(i,n,r,o,t[3],10,-1894986606),o=Bl(o,i,n,r,t[10],15,-1051523),r=Bl(r,o,i,n,t[1],21,-2054922799),n=Bl(n,r,o,i,t[8],6,1873313359),i=Bl(i,n,r,o,t[15],10,-30611744),o=Bl(o,i,n,r,t[6],15,-1560198380),r=Bl(r,o,i,n,t[13],21,1309151649),n=Bl(n,r,o,i,t[4],6,-145523070),i=Bl(i,n,r,o,t[11],10,-1120210379),o=Bl(o,i,n,r,t[2],15,718787259),r=Bl(r,o,i,n,t[9],21,-343485551),e[0]=Ul(n,e[0]),e[1]=Ul(r,e[1]),e[2]=Ul(o,e[2]),e[3]=Ul(i,e[3])}function Il(e,t,n,r,o,i){return t=Ul(Ul(t,e),Ul(r,i)),Ul(t<<o|t>>>32-o,n)}function Rl(e,t,n,r,o,i,a){return Il(t&n|~t&r,e,t,o,i,a)}function Dl(e,t,n,r,o,i,a){return Il(t&r|n&~r,e,t,o,i,a)}function Ml(e,t,n,r,o,i,a){return Il(t^n^r,e,t,o,i,a)}function Bl(e,t,n,r,o,i,a){return Il(n^(t|~r),e,t,o,i,a)}function Wl(e){const t=[];let n;for(n=0;n<64;n+=4)t[n>>2]=e.charCodeAt(n)+(e.charCodeAt(n+1)<<8)+(e.charCodeAt(n+2)<<16)+(e.charCodeAt(n+3)<<24);return t}const Jl="0123456789abcdef".split("");function Fl(e){let t="",n=0;for(;n<4;n++)t+=Jl[e>>8*n+4&15]+Jl[e>>8*n&15];return t}function Yl(e){return t=function(e){const t=e.length,n=[1732584193,-271733879,-1732584194,271733878];let r;for(r=64;r<=e.length;r+=64)jl(n,Wl(e.substring(r-64,r)));e=e.substring(r-64);const o=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(r=0;r<e.length;r++)o[r>>2]|=e.charCodeAt(r)<<(r%4<<3);if(o[r>>2]|=128<<(r%4<<3),r>55)for(jl(n,o),r=0;r<16;r++)o[r]=0;return o[14]=8*t,jl(n,o),n}(e),t.map(Fl).join("");var t}function Ul(e,t){return e+t&4294967295}function $l(e,{removeReverseProxyURLPrefixes:t}={}){const n=[];return[/url\((?!['"]?:)'([^']*)'\)/g,/url\((?!['"]?:)"([^"]*)"\)/g,/url\((?!['"]?:)([^()'"]*)\)/g].forEach((t=>{let r;for(;null!==(r=t.exec(e));)n.push(r[1])})),t?n.map((e=>{const t=e.match(/\/http(.*)$/);return t&&t.length?t[0].substring(1):e})):n}function Vl(e){let t=[];if(!e||"function"!=typeof e.getPropertyValue)return t;for(let n=0,r=e.length;n<r;n++){const r=e[n];let o=e.getPropertyValue(r);(/^\s*var\s*\(/.test(o)||/^--/.test(r))&&(o=o.replace(/(\\[0-9a-fA-F]{1,6}\s?)/g,(e=>String.fromCodePoint(parseInt(e.substr(1).trim(),16)))).replace(/\\([^0-9a-fA-F])/g,"$1"));const i=$l(o);t=t.concat(i)}return t}const ql=/(\S+)(?:\s+[\d.]+[wx])?(?:,|$)/g;function Hl(e,t,n,r){const{resolved:o,signature:i}=Nl(e.cssRules,n);let a=r.get(e);a||r.set(e,a=new Map);const s=a.get(i);if(void 0!==s)return t.log("[styleSheetToCssText] reusing css of an identical adopted stylesheet"),s;const l=xl(e.cssRules,t,o),c=tl(cl({type:"StyleSheet",children:l}));return a.set(i,c),c}function Zl(e){const{ownerDocument:t}=e;if(!t)return!0;const n=t.defaultView.getComputedStyle(e);if(!n||"string"!=typeof n.display)return!1;const{display:r}=n,{width:o,height:i}=e.getBoundingClientRect();return"none"===r||0===o||0===i}function Kl(e){try{return ll(el(e.toLowerCase(),{context:"mediaQueryList"})).children.some((e=>{const t=Gl(e);return e.mediaType&&t.unshift(e),t.every((e=>{var t,n;return!(e.modifier&&!["not","only"].includes(e.modifier))&&("Feature"===e.type||("Identifier"!==e.type&&"MediaQuery"!==e.type||!["all","screen"].includes(null!==(n=null!==(t=e.name)&&void 0!==t?t:e.mediaType)&&void 0!==n?n:"")?e.modifier&&"not"===e.modifier:!e.modifier||"not"!==e.modifier))}))}))}catch(e){return!1}}function Gl(e){var t,n;const r=[];if(e.condition)r.push(...Gl(e.condition));else{const o=null!==(n=null===(t=e.children)||void 0===t?void 0:t.reduce(((e,t)=>("Condition"===t.type?e.push(...Gl(t)):"Identifier"===t.type&&"and"===t.name||e.push(t),e)),[]))&&void 0!==n?n:[];r.push(...o)}return r}const Xl=Symbol("raw");function Ql(e){const t=function(e){const t=n;if(!t)return null;const r=t.Node.prototype.toString.apply(e).replace(/\[object (.*)]/,"$1");return t[r]}(e);return t?(r=e,o=t.prototype,new Proxy(Object.create(r),{get(e,t,n){if(t===Xl)return r;const i=Reflect.get(o,t,r);return"function"==typeof i?function(){return i.apply(this===n?r:this,arguments)}:i}})):e;var r,o}Ql.unwrap=function(e){return e[Xl]||e};const ec=new Set(["date","datetime-local","email","month","number","password","search","tel","text","time","url","week","range"]),tc=/^on[a-z]+$/;function nc(e,t,n,r){const o=[{nodeType:Node.DOCUMENT_NODE}],i=[e],a=[],s=[],l=[],c=[];let u=[];const d=[],h=[],p={inline:new Map,sheets:new Map};return o[0].childNodeIndexes=m(o,e.childNodes),e.adoptedStyleSheets&&e.adoptedStyleSheets.length>0&&ic(o,o[0],e,n,p,r),{cdt:o,docRoots:i,canvasElements:a,frames:l,inlineFrames:s,crossFrames:c,linkUrls:u,imageBlobs:d,videoBlobs:h};function m(e,t,n){if(!t||0===t.length)return null;const r=[];return Array.prototype.forEach.call(t,(t=>{const o=g(e,t,n);null!==o&&r.push(o)})),r}function g(e,o,y){try{return function(e,o,y){var b;const _=Ql(o);let w;if([Node.ELEMENT_NODE,Node.DOCUMENT_FRAGMENT_NODE].includes(_.nodeType)){if(_.hasAttribute&&_.hasAttribute("data-applitools-skip"))return null;if(["LINK","STYLE","SOURCE"].includes(_.nodeName)&&(null===(b=_.media)||void 0===b?void 0:b.trim())&&!Kl(_.media))return null;if("SCRIPT"===_.nodeName)w=function(e){return{nodeType:Node.ELEMENT_NODE,nodeName:"SCRIPT",attributes:rc(e).map((t=>{const n=e.attributes[t].name;return{name:n,value:tc.test(n)?"":e.attributes[t].value}})).filter((e=>"src"!==e.name)),childNodeIndexes:[]}}(_);else{const u=_.shadowRoot&&_.shadowRoot.childNodes.length&&"ShadowRoot"!==_.shadowRoot.constructor.name;if(w=function(e){var t,n,r;const o={nodeType:e.nodeType,nodeName:e.nodeName,attributes:rc(e).map((t=>{let n=e.attributes[t].value;const r=e.attributes[t].name;return!n.includes("blob:")||"IFRAME"===e.nodeName&&"src"===r&&f(e)?tc.test(r)?n="":"IFRAME"===e.nodeName&&f(e)&&"src"===r&&"about:blank"!==e.contentDocument.location.href&&e.contentDocument.location.href!==v(n,e.ownerDocument.location.href)?n=e.contentDocument.location.href:"LINK"===e.nodeName&&"href"===r?n=function(e,t){var n;const r=null===(n=e.sheet)||void 0===n?void 0:n.href;if(!r)return t;const o=E(r);return o===v(t,e.ownerDocument.location.href)?t:o}(e,n):"style"===r&&(n=function(e){const t={type:"DeclarationList",children:_l(e)};return tl(t)}(e.style)):n=n.replace(/blob:/g,""),{name:r,value:n}}))};if("INPUT"===e.tagName&&["checkbox","radio"].includes(e.type)){if(e.attributes.getNamedItem("checked")&&!e.checked){const e=o.attributes.findIndex((e=>"checked"===e.name));o.attributes.splice(e,1)}!e.attributes.getNamedItem("checked")&&e.checked&&o.attributes.push({name:"checked"}),e.indeterminate&&o.attributes.push({name:"data-applitools-js-properties",value:JSON.stringify({indeterminate:!0})})}if("INPUT"===e.tagName&&ec.has(e.type)){const i=null!==e.attributes.getNamedItem("value"),a=null!==(n=null===(t=e.attributes.getNamedItem("value"))||void 0===t?void 0:t.value)&&void 0!==n?n:"",s=null!==(r=e.value)&&void 0!==r?r:"";i&&a===s||oc(o.attributes,"value",s)}return"OPTION"===e.tagName&&e.parentElement&&e.parentElement.selectedOptions&&Array.from(e.parentElement.selectedOptions).indexOf(Ql.unwrap(e))>-1&&oc(o.attributes,"selected",""),"STYLE"===e.tagName&&e.sheet&&e.sheet.disabled&&o.attributes.push({name:"data-applitools-disabled",value:""}),"LINK"===e.tagName&&"text/css"===e.type&&e.sheet&&e.sheet.disabled&&oc(o.attributes,"disabled",""),o}(_),"STYLE"===_.nodeName&&_.sheet&&_.sheet.cssRules.length?(e.push(function(e,t,n,r){const o=(i=e,Yl(Array.prototype.map.call(i.sheet.cssRules,(e=>e.cssText)).join("")));var i;if(n.__dsNodeCache&&n.__dsNodeCache.key===o)t.log("[domNodesToCdt] using cache for inline css of",zl(e));else{const i={cssomKey:o,results:r.inline};n.__dsNodeCache={key:o,value:Tl(e,t,i)}}return{nodeType:Node.TEXT_NODE,nodeValue:n.__dsNodeCache.value}}(_,n,o,p)),w.childNodeIndexes=[e.length-1]):"TEXTAREA"===_.tagName&&_.value!==_.textContent?(e.push(function(e){return{nodeType:Node.TEXT_NODE,nodeValue:e.value}}(_)),w.childNodeIndexes=[e.length-1]):w.childNodeIndexes=!u&&_.childNodes.length?m(e,_.childNodes,y):[],y&&"SLOT"===_.tagName&&"function"==typeof _.assignedNodes){const t=_.assignedNodes();t.length&&(w.childNodeIndexes=m(e,t,y)||[])}if(_.shadowRoot&&(u?w.childNodeIndexes=w.childNodeIndexes.concat(m(e,_.shadowRoot.childNodes,!0)):(w.shadowRootIndex=g(e,_.shadowRoot),i.push(_.shadowRoot))),"CANVAS"===_.nodeName&&!Zl(o)){const e=v(`applitools-canvas-${C()}.png`,t);w.attributes.push({name:"data-applitools-src",value:e}),a.push({element:_,cdtNode:w,url:e})}if("IFRAME"===_.nodeName){const n=C();if(_.setAttribute("data-applitools-selector",n.toString()),Zl(o))w.attributes.forEach((e=>{"src"!==e.name&&"srcdoc"!==e.name||(w.attributes.push({name:`data-applitools-original-${e.name}`,value:e.value}),e.value="")}));else if(f(o))if(k(_)){const e=v(`?applitools-iframe=${C()}`,t);w.attributes.push({name:"data-applitools-src",value:e}),s.push({element:_,url:e})}else{const e=_.contentDocument.location.href,t=v(`?applitools-iframe=${C()}`,e);w.attributes.push({name:"data-applitools-src",value:t}),l.push({element:_,url:t})}else{const t=`[data-applitools-selector="${n}"]`;c.push({selector:t,index:e.length})}}_.adoptedStyleSheets&&_.adoptedStyleSheets.length>0&&ic(e,w,_,n,p,r)}if(_.nodeType===Node.ELEMENT_NODE){const n=function(e){const t=(e.matches||e.msMatchesSelector).bind(e);let n=[];if(t("img[srcset],source[srcset]")){const t=e.getAttribute("srcset");n=n.concat(function(e,t,n){const r=[],o=new RegExp(e.source,e.flags),i=o.global;let a;for(;(a=o.exec(t))&&(r.push(n(a)),i););return r}(ql,t,(e=>e[1])))}if(t('img[src],source[src],input[type="image"][src],audio[src],video[src]')){const t=e.getAttribute("src");n.push(t)}if(t("image,use")){const t=e.getAttribute("href")||e.getAttribute("xlink:href");t&&!function(e,t){try{const n=new URL(t),r=new URL(e,t);return r.origin===n.origin&&r.pathname===n.pathname&&Boolean(r.hash)}catch(e){return!1}}(t,e.ownerDocument.location.href)&&n.push(t)}if(t("object")&&e.getAttribute("data")&&n.push(e.getAttribute("data")),t('link[rel~="stylesheet"], link[as="stylesheet"]')){const t=e.sheet;n.push(t&&t.href||e.getAttribute("href"))}if(t("video[poster]")){const t=e.getAttribute("poster");n.push(t)}if(t("embed[src]")){const t=e.getAttribute("src");n.push(t)}const r=function(e){if(e.hasAttribute("style"))return Vl(e.style)}(e);return r&&(n=n.concat(r)),n}(_);if(n.length>0&&(u=u.concat(n)),"IMG"===_.tagName&&/^blob:/.test(_.src)){const e=_.src.replace(/^blob:/,"");d.push({element:_,cdtNode:w,url:e})}if("VIDEO"===_.tagName&&(/^blob:/.test(_.src)||_.srcObject)){let n;_.src?n=_.src.replace(/^blob:/,""):(n=v(`applitools-video-${C()}.webm`,t),w.attributes.push({name:"data-applitools-src",value:n})),h.push({element:_,url:n,cdtNode:w,dropSrcIfUnrecorded:/^blob:/.test(_.src)&&w.childNodeIndexes.some((t=>"SOURCE"===e[t].nodeName))})}}}else _.nodeType===Node.TEXT_NODE?w=function(e){return{nodeType:Node.TEXT_NODE,nodeValue:e.nodeValue}}(_):_.nodeType===Node.DOCUMENT_TYPE_NODE&&(w=function(e){return{nodeType:Node.DOCUMENT_TYPE_NODE,nodeName:e.nodeName}}(_));return w?(e.push(w),e.length-1):null}(e,o,y)}catch(e){try{n.warn("[domNodesToCdt] skipped a node that failed to serialize",function(e){try{const t=e;if(t.nodeType!==Node.ELEMENT_NODE)return`nodeType=${e.nodeType}`;const n="string"==typeof t.tagName?t.tagName.toLowerCase():`nodeType=${t.nodeType}`;return`${n}${t.id?`#${t.id}`:""}${"string"==typeof t.className&&t.className?`.${t.className.trim().split(/\s+/).join(".")}`:""}`}catch(e){return"unknown-node"}}(o),String(e))}catch(e){}return null}}}function rc(e){return Object.keys(e.attributes||{}).filter((t=>e.attributes[t]&&e.attributes[t].name))}function oc(e,t,n){const r=e.find((e=>e.name===t));r?r.value=n:e.push({name:t,value:n})}function ic(e,t,n,r,o,i){const a=Array.from(n.adoptedStyleSheets);if(i)t.exp_adoptedStyleSheets=a.map((e=>Hl(e,r,n,o.sheets)));else for(const i of a)e.push({nodeType:Node.TEXT_NODE,nodeValue:Hl(i,r,n,o.sheets)}),e.push({nodeType:Node.ELEMENT_NODE,nodeName:"STYLE",attributes:[{name:"x-rg-adopted-style",value:""}],childNodeIndexes:[e.length-1]}),t.childNodeIndexes||(t.childNodeIndexes=[]),t.childNodeIndexes.push(e.length-1)}function ac(e,t){if(e===t)return!0;if(Array.isArray(e)&&Array.isArray(t))return e.length===t.length&&e.every(((e,n)=>ac(e,t[n])));if(e&&t&&"object"==typeof e&&"object"==typeof t){const n=Object.keys(e);return n.length===Object.keys(t).length&&n.every((n=>ac(e[n],t[n])))}return!1}class sc{constructor(){this.buckets=new Map}get(e){var t;return null===(t=this.bucketOf(e).find((t=>ac(t.node,e))))||void 0===t?void 0:t.index}add(e,t){const n=this.bucketOf(e);n.some((t=>ac(t.node,e)))||n.push({node:e,index:t})}keyOf(e){var t,n,r;return"string"==typeof e.nodeValue?e.nodeValue:[e.nodeType,e.nodeName,null===(t=e.attributes)||void 0===t?void 0:t.map((e=>{var t;return`${e.name}=${null===(t=e.value)||void 0===t?void 0:t.substring(0,20)}`})).join(";"),null===(n=e.exp_adoptedStyleSheets)||void 0===n?void 0:n.map((e=>null==e?void 0:e.substring(0,20))).join(";"),e.shadowRootIndex,null===(r=e.childNodeIndexes)||void 0===r?void 0:r.join(",")].join(":")}bucketOf(e){const t=this.keyOf(e);let n=this.buckets.get(t);return n||this.buckets.set(t,n=[]),n}}function lc(e){var t;return null!==(t=e.nodeName)&&void 0!==t?t:String(e.nodeType)}function cc(e){const t=[];return new Set(e).forEach((e=>e&&t.push(e))),t}function uc(e){return e.reduce((({resourceUrls:e,blobsObj:t},{resourceUrls:n,blobsObj:r})=>({resourceUrls:cc(e.concat(n)),blobsObj:Object.assign(t,r)})),{resourceUrls:[],blobsObj:{}})}var dc={exports:{}};!function(e){function t(e){var t=new o,r=0|e;function i(e){try{return Promise.resolve(e.fn.apply(e.self,e.args)).then(a,s)}catch(e){s(e)}}function a(e){return l(),e}function s(e){throw l(),e}function l(){var e=t.shift();e?e.resolve(e):r=1+(0|r)}return function(e,o,l){return 0!=(0|r)?(r=(0|r)-1,new Promise((function(t){t(e.apply(o,l))})).then(a,s)):new Promise((function(r){t.push(new n(r,e,o,l))})).then(i)}}function n(e,t,n,r){this.resolve=e,this.fn=t,this.self=n||null,this.args=r}e.exports=function(e,n){if("function"==typeof e){var r=n;n=e,e=r}if("number"!=typeof e)throw new TypeError("Expected throat size to be a number but got "+typeof e);if(void 0!==n&&"function"!=typeof n)throw new TypeError("Expected throat fn to be a function but got "+typeof n);return"function"==typeof n?function(e,n){const r=t(0|e);return function(){for(var e=new Array(arguments.length),t=0;t<arguments.length;t++)e[t]=arguments[t];return r(n,this,e)}}(0|e,n):function(e){const n=t(0|e);return function(e){if("function"!=typeof e)throw new TypeError("Expected throat fn to be a function but got "+typeof e);for(var t=new Array(arguments.length-1),r=1;r<arguments.length;r++)t[r-1]=arguments[r];return n(e,this,t)}}(0|e)},e.exports.default=e.exports;var r=64;function o(){this._s1=[],this._s2=[],this._shiftBlock=this._pushBlock=new Array(r),this._pushIndex=0,this._shiftIndex=0}o.prototype.push=function(e){this._pushIndex===r&&(this._pushIndex=0,this._s1[this._s1.length]=this._pushBlock=new Array(r)),this._pushBlock[this._pushIndex++]=e},o.prototype.shift=function(){if(this._shiftIndex===r){var e=this._s2;if(0===e.length){var t=this._s1;if(0===t.length)return;this._s1=e,e=this._s2=t.reverse()}this._shiftIndex=0,this._shiftBlock=e.pop()}if(this._pushBlock!==this._shiftBlock||this._pushIndex!==this._shiftIndex){var n=this._shiftBlock[this._shiftIndex];return this._shiftBlock[this._shiftIndex++]=null,n}}}(dc);var hc=function(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}(dc.exports),pc={};!function(e){var t="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Int32Array;function n(e,t){return Object.prototype.hasOwnProperty.call(e,t)}e.assign=function(e){for(var t=Array.prototype.slice.call(arguments,1);t.length;){var r=t.shift();if(r){if("object"!=typeof r)throw new TypeError(r+"must be non-object");for(var o in r)n(r,o)&&(e[o]=r[o])}}return e},e.shrinkBuf=function(e,t){return e.length===t?e:e.subarray?e.subarray(0,t):(e.length=t,e)};var r={arraySet:function(e,t,n,r,o){if(t.subarray&&e.subarray)e.set(t.subarray(n,n+r),o);else for(var i=0;i<r;i++)e[o+i]=t[n+i]},flattenChunks:function(e){var t,n,r,o,i,a;for(r=0,t=0,n=e.length;t<n;t++)r+=e[t].length;for(a=new Uint8Array(r),o=0,t=0,n=e.length;t<n;t++)i=e[t],a.set(i,o),o+=i.length;return a}},o={arraySet:function(e,t,n,r,o){for(var i=0;i<r;i++)e[o+i]=t[n+i]},flattenChunks:function(e){return[].concat.apply([],e)}};e.setTyped=function(t){t?(e.Buf8=Uint8Array,e.Buf16=Uint16Array,e.Buf32=Int32Array,e.assign(e,r)):(e.Buf8=Array,e.Buf16=Array,e.Buf32=Array,e.assign(e,o))},e.setTyped(t)}(pc);var fc={},mc={},gc={},yc=pc;function bc(e){for(var t=e.length;--t>=0;)e[t]=0}var _c=256,vc=286,wc=30,kc=15,xc=16,Sc=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],Oc=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],Ac=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],Ec=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Cc=new Array(576);bc(Cc);var Pc=new Array(60);bc(Pc);var Lc=new Array(512);bc(Lc);var zc=new Array(256);bc(zc);var Nc=new Array(29);bc(Nc);var Tc,jc,Ic,Rc=new Array(wc);function Dc(e,t,n,r,o){this.static_tree=e,this.extra_bits=t,this.extra_base=n,this.elems=r,this.max_length=o,this.has_stree=e&&e.length}function Mc(e,t){this.dyn_tree=e,this.max_code=0,this.stat_desc=t}function Bc(e){return e<256?Lc[e]:Lc[256+(e>>>7)]}function Wc(e,t){e.pending_buf[e.pending++]=255&t,e.pending_buf[e.pending++]=t>>>8&255}function Jc(e,t,n){e.bi_valid>xc-n?(e.bi_buf|=t<<e.bi_valid&65535,Wc(e,e.bi_buf),e.bi_buf=t>>xc-e.bi_valid,e.bi_valid+=n-xc):(e.bi_buf|=t<<e.bi_valid&65535,e.bi_valid+=n)}function Fc(e,t,n){Jc(e,n[2*t],n[2*t+1])}function Yc(e,t){var n=0;do{n|=1&e,e>>>=1,n<<=1}while(--t>0);return n>>>1}function Uc(e,t,n){var r,o,i=new Array(kc+1),a=0;for(r=1;r<=kc;r++)i[r]=a=a+n[r-1]<<1;for(o=0;o<=t;o++){var s=e[2*o+1];0!==s&&(e[2*o]=Yc(i[s]++,s))}}function $c(e){var t;for(t=0;t<vc;t++)e.dyn_ltree[2*t]=0;for(t=0;t<wc;t++)e.dyn_dtree[2*t]=0;for(t=0;t<19;t++)e.bl_tree[2*t]=0;e.dyn_ltree[512]=1,e.opt_len=e.static_len=0,e.last_lit=e.matches=0}function Vc(e){e.bi_valid>8?Wc(e,e.bi_buf):e.bi_valid>0&&(e.pending_buf[e.pending++]=e.bi_buf),e.bi_buf=0,e.bi_valid=0}function qc(e,t,n,r){var o=2*t,i=2*n;return e[o]<e[i]||e[o]===e[i]&&r[t]<=r[n]}function Hc(e,t,n){for(var r=e.heap[n],o=n<<1;o<=e.heap_len&&(o<e.heap_len&&qc(t,e.heap[o+1],e.heap[o],e.depth)&&o++,!qc(t,r,e.heap[o],e.depth));)e.heap[n]=e.heap[o],n=o,o<<=1;e.heap[n]=r}function Zc(e,t,n){var r,o,i,a,s=0;if(0!==e.last_lit)do{r=e.pending_buf[e.d_buf+2*s]<<8|e.pending_buf[e.d_buf+2*s+1],o=e.pending_buf[e.l_buf+s],s++,0===r?Fc(e,o,t):(Fc(e,(i=zc[o])+_c+1,t),0!==(a=Sc[i])&&Jc(e,o-=Nc[i],a),Fc(e,i=Bc(--r),n),0!==(a=Oc[i])&&Jc(e,r-=Rc[i],a))}while(s<e.last_lit);Fc(e,256,t)}function Kc(e,t){var n,r,o,i=t.dyn_tree,a=t.stat_desc.static_tree,s=t.stat_desc.has_stree,l=t.stat_desc.elems,c=-1;for(e.heap_len=0,e.heap_max=573,n=0;n<l;n++)0!==i[2*n]?(e.heap[++e.heap_len]=c=n,e.depth[n]=0):i[2*n+1]=0;for(;e.heap_len<2;)i[2*(o=e.heap[++e.heap_len]=c<2?++c:0)]=1,e.depth[o]=0,e.opt_len--,s&&(e.static_len-=a[2*o+1]);for(t.max_code=c,n=e.heap_len>>1;n>=1;n--)Hc(e,i,n);o=l;do{n=e.heap[1],e.heap[1]=e.heap[e.heap_len--],Hc(e,i,1),r=e.heap[1],e.heap[--e.heap_max]=n,e.heap[--e.heap_max]=r,i[2*o]=i[2*n]+i[2*r],e.depth[o]=(e.depth[n]>=e.depth[r]?e.depth[n]:e.depth[r])+1,i[2*n+1]=i[2*r+1]=o,e.heap[1]=o++,Hc(e,i,1)}while(e.heap_len>=2);e.heap[--e.heap_max]=e.heap[1],function(e,t){var n,r,o,i,a,s,l=t.dyn_tree,c=t.max_code,u=t.stat_desc.static_tree,d=t.stat_desc.has_stree,h=t.stat_desc.extra_bits,p=t.stat_desc.extra_base,f=t.stat_desc.max_length,m=0;for(i=0;i<=kc;i++)e.bl_count[i]=0;for(l[2*e.heap[e.heap_max]+1]=0,n=e.heap_max+1;n<573;n++)(i=l[2*l[2*(r=e.heap[n])+1]+1]+1)>f&&(i=f,m++),l[2*r+1]=i,r>c||(e.bl_count[i]++,a=0,r>=p&&(a=h[r-p]),s=l[2*r],e.opt_len+=s*(i+a),d&&(e.static_len+=s*(u[2*r+1]+a)));if(0!==m){do{for(i=f-1;0===e.bl_count[i];)i--;e.bl_count[i]--,e.bl_count[i+1]+=2,e.bl_count[f]--,m-=2}while(m>0);for(i=f;0!==i;i--)for(r=e.bl_count[i];0!==r;)(o=e.heap[--n])>c||(l[2*o+1]!==i&&(e.opt_len+=(i-l[2*o+1])*l[2*o],l[2*o+1]=i),r--)}}(e,t),Uc(i,c,e.bl_count)}function Gc(e,t,n){var r,o,i=-1,a=t[1],s=0,l=7,c=4;for(0===a&&(l=138,c=3),t[2*(n+1)+1]=65535,r=0;r<=n;r++)o=a,a=t[2*(r+1)+1],++s<l&&o===a||(s<c?e.bl_tree[2*o]+=s:0!==o?(o!==i&&e.bl_tree[2*o]++,e.bl_tree[32]++):s<=10?e.bl_tree[34]++:e.bl_tree[36]++,s=0,i=o,0===a?(l=138,c=3):o===a?(l=6,c=3):(l=7,c=4))}function Xc(e,t,n){var r,o,i=-1,a=t[1],s=0,l=7,c=4;for(0===a&&(l=138,c=3),r=0;r<=n;r++)if(o=a,a=t[2*(r+1)+1],!(++s<l&&o===a)){if(s<c)do{Fc(e,o,e.bl_tree)}while(0!=--s);else 0!==o?(o!==i&&(Fc(e,o,e.bl_tree),s--),Fc(e,16,e.bl_tree),Jc(e,s-3,2)):s<=10?(Fc(e,17,e.bl_tree),Jc(e,s-3,3)):(Fc(e,18,e.bl_tree),Jc(e,s-11,7));s=0,i=o,0===a?(l=138,c=3):o===a?(l=6,c=3):(l=7,c=4)}}bc(Rc);var Qc=!1;function eu(e,t,n,r){Jc(e,0+(r?1:0),3),function(e,t,n,r){Vc(e),Wc(e,n),Wc(e,~n),yc.arraySet(e.pending_buf,e.window,t,n,e.pending),e.pending+=n}(e,t,n)}gc._tr_init=function(e){Qc||(function(){var e,t,n,r,o,i=new Array(kc+1);for(n=0,r=0;r<28;r++)for(Nc[r]=n,e=0;e<1<<Sc[r];e++)zc[n++]=r;for(zc[n-1]=r,o=0,r=0;r<16;r++)for(Rc[r]=o,e=0;e<1<<Oc[r];e++)Lc[o++]=r;for(o>>=7;r<wc;r++)for(Rc[r]=o<<7,e=0;e<1<<Oc[r]-7;e++)Lc[256+o++]=r;for(t=0;t<=kc;t++)i[t]=0;for(e=0;e<=143;)Cc[2*e+1]=8,e++,i[8]++;for(;e<=255;)Cc[2*e+1]=9,e++,i[9]++;for(;e<=279;)Cc[2*e+1]=7,e++,i[7]++;for(;e<=287;)Cc[2*e+1]=8,e++,i[8]++;for(Uc(Cc,287,i),e=0;e<wc;e++)Pc[2*e+1]=5,Pc[2*e]=Yc(e,5);Tc=new Dc(Cc,Sc,257,vc,kc),jc=new Dc(Pc,Oc,0,wc,kc),Ic=new Dc(new Array(0),Ac,0,19,7)}(),Qc=!0),e.l_desc=new Mc(e.dyn_ltree,Tc),e.d_desc=new Mc(e.dyn_dtree,jc),e.bl_desc=new Mc(e.bl_tree,Ic),e.bi_buf=0,e.bi_valid=0,$c(e)},gc._tr_stored_block=eu,gc._tr_flush_block=function(e,t,n,r){var o,i,a=0;e.level>0?(2===e.strm.data_type&&(e.strm.data_type=function(e){var t,n=4093624447;for(t=0;t<=31;t++,n>>>=1)if(1&n&&0!==e.dyn_ltree[2*t])return 0;if(0!==e.dyn_ltree[18]||0!==e.dyn_ltree[20]||0!==e.dyn_ltree[26])return 1;for(t=32;t<_c;t++)if(0!==e.dyn_ltree[2*t])return 1;return 0}(e)),Kc(e,e.l_desc),Kc(e,e.d_desc),a=function(e){var t;for(Gc(e,e.dyn_ltree,e.l_desc.max_code),Gc(e,e.dyn_dtree,e.d_desc.max_code),Kc(e,e.bl_desc),t=18;t>=3&&0===e.bl_tree[2*Ec[t]+1];t--);return e.opt_len+=3*(t+1)+5+5+4,t}(e),o=e.opt_len+3+7>>>3,(i=e.static_len+3+7>>>3)<=o&&(o=i)):o=i=n+5,n+4<=o&&-1!==t?eu(e,t,n,r):4===e.strategy||i===o?(Jc(e,2+(r?1:0),3),Zc(e,Cc,Pc)):(Jc(e,4+(r?1:0),3),function(e,t,n,r){var o;for(Jc(e,t-257,5),Jc(e,n-1,5),Jc(e,r-4,4),o=0;o<r;o++)Jc(e,e.bl_tree[2*Ec[o]+1],3);Xc(e,e.dyn_ltree,t-1),Xc(e,e.dyn_dtree,n-1)}(e,e.l_desc.max_code+1,e.d_desc.max_code+1,a+1),Zc(e,e.dyn_ltree,e.dyn_dtree)),$c(e),r&&Vc(e)},gc._tr_tally=function(e,t,n){return e.pending_buf[e.d_buf+2*e.last_lit]=t>>>8&255,e.pending_buf[e.d_buf+2*e.last_lit+1]=255&t,e.pending_buf[e.l_buf+e.last_lit]=255&n,e.last_lit++,0===t?e.dyn_ltree[2*n]++:(e.matches++,t--,e.dyn_ltree[2*(zc[n]+_c+1)]++,e.dyn_dtree[2*Bc(t)]++),e.last_lit===e.lit_bufsize-1},gc._tr_align=function(e){Jc(e,2,3),Fc(e,256,Cc),function(e){16===e.bi_valid?(Wc(e,e.bi_buf),e.bi_buf=0,e.bi_valid=0):e.bi_valid>=8&&(e.pending_buf[e.pending++]=255&e.bi_buf,e.bi_buf>>=8,e.bi_valid-=8)}(e)};var tu,nu=function(e,t,n,r){for(var o=65535&e|0,i=e>>>16&65535|0,a=0;0!==n;){n-=a=n>2e3?2e3:n;do{i=i+(o=o+t[r++]|0)|0}while(--a);o%=65521,i%=65521}return o|i<<16|0},ru=function(){for(var e,t=[],n=0;n<256;n++){e=n;for(var r=0;r<8;r++)e=1&e?3988292384^e>>>1:e>>>1;t[n]=e}return t}(),ou=function(e,t,n,r){var o=ru,i=r+n;e^=-1;for(var a=r;a<i;a++)e=e>>>8^o[255&(e^t[a])];return-1^e},iu={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"},au=pc,su=gc,lu=nu,cu=ou,uu=iu,du=0,hu=0,pu=-2,fu=2,mu=8,gu=286,yu=30,bu=19,_u=2*gu+1,vu=15,wu=3,ku=258,xu=ku+wu+1,Su=42,Ou=103,Au=113,Eu=666;function Cu(e,t){return e.msg=uu[t],t}function Pu(e){return(e<<1)-(e>4?9:0)}function Lu(e){for(var t=e.length;--t>=0;)e[t]=0}function zu(e){var t=e.state,n=t.pending;n>e.avail_out&&(n=e.avail_out),0!==n&&(au.arraySet(e.output,t.pending_buf,t.pending_out,n,e.next_out),e.next_out+=n,t.pending_out+=n,e.total_out+=n,e.avail_out-=n,t.pending-=n,0===t.pending&&(t.pending_out=0))}function Nu(e,t){su._tr_flush_block(e,e.block_start>=0?e.block_start:-1,e.strstart-e.block_start,t),e.block_start=e.strstart,zu(e.strm)}function Tu(e,t){e.pending_buf[e.pending++]=t}function ju(e,t){e.pending_buf[e.pending++]=t>>>8&255,e.pending_buf[e.pending++]=255&t}function Iu(e,t){var n,r,o=e.max_chain_length,i=e.strstart,a=e.prev_length,s=e.nice_match,l=e.strstart>e.w_size-xu?e.strstart-(e.w_size-xu):0,c=e.window,u=e.w_mask,d=e.prev,h=e.strstart+ku,p=c[i+a-1],f=c[i+a];e.prev_length>=e.good_match&&(o>>=2),s>e.lookahead&&(s=e.lookahead);do{if(c[(n=t)+a]===f&&c[n+a-1]===p&&c[n]===c[i]&&c[++n]===c[i+1]){i+=2,n++;do{}while(c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&c[++i]===c[++n]&&i<h);if(r=ku-(h-i),i=h-ku,r>a){if(e.match_start=t,a=r,r>=s)break;p=c[i+a-1],f=c[i+a]}}}while((t=d[t&u])>l&&0!=--o);return a<=e.lookahead?a:e.lookahead}function Ru(e){var t,n,r,o,i,a,s,l,c,u,d=e.w_size;do{if(o=e.window_size-e.lookahead-e.strstart,e.strstart>=d+(d-xu)){au.arraySet(e.window,e.window,d,d,0),e.match_start-=d,e.strstart-=d,e.block_start-=d,t=n=e.hash_size;do{r=e.head[--t],e.head[t]=r>=d?r-d:0}while(--n);t=n=d;do{r=e.prev[--t],e.prev[t]=r>=d?r-d:0}while(--n);o+=d}if(0===e.strm.avail_in)break;if(a=e.strm,s=e.window,l=e.strstart+e.lookahead,c=o,u=void 0,(u=a.avail_in)>c&&(u=c),n=0===u?0:(a.avail_in-=u,au.arraySet(s,a.input,a.next_in,u,l),1===a.state.wrap?a.adler=lu(a.adler,s,u,l):2===a.state.wrap&&(a.adler=cu(a.adler,s,u,l)),a.next_in+=u,a.total_in+=u,u),e.lookahead+=n,e.lookahead+e.insert>=wu)for(i=e.strstart-e.insert,e.ins_h=e.window[i],e.ins_h=(e.ins_h<<e.hash_shift^e.window[i+1])&e.hash_mask;e.insert&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[i+wu-1])&e.hash_mask,e.prev[i&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=i,i++,e.insert--,!(e.lookahead+e.insert<wu)););}while(e.lookahead<xu&&0!==e.strm.avail_in)}function Du(e,t){for(var n,r;;){if(e.lookahead<xu){if(Ru(e),e.lookahead<xu&&t===du)return 1;if(0===e.lookahead)break}if(n=0,e.lookahead>=wu&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+wu-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),0!==n&&e.strstart-n<=e.w_size-xu&&(e.match_length=Iu(e,n)),e.match_length>=wu)if(r=su._tr_tally(e,e.strstart-e.match_start,e.match_length-wu),e.lookahead-=e.match_length,e.match_length<=e.max_lazy_match&&e.lookahead>=wu){e.match_length--;do{e.strstart++,e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+wu-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart}while(0!=--e.match_length);e.strstart++}else e.strstart+=e.match_length,e.match_length=0,e.ins_h=e.window[e.strstart],e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+1])&e.hash_mask;else r=su._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++;if(r&&(Nu(e,!1),0===e.strm.avail_out))return 1}return e.insert=e.strstart<wu-1?e.strstart:wu-1,4===t?(Nu(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(Nu(e,!1),0===e.strm.avail_out)?1:2}function Mu(e,t){for(var n,r,o;;){if(e.lookahead<xu){if(Ru(e),e.lookahead<xu&&t===du)return 1;if(0===e.lookahead)break}if(n=0,e.lookahead>=wu&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+wu-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),e.prev_length=e.match_length,e.prev_match=e.match_start,e.match_length=wu-1,0!==n&&e.prev_length<e.max_lazy_match&&e.strstart-n<=e.w_size-xu&&(e.match_length=Iu(e,n),e.match_length<=5&&(1===e.strategy||e.match_length===wu&&e.strstart-e.match_start>4096)&&(e.match_length=wu-1)),e.prev_length>=wu&&e.match_length<=e.prev_length){o=e.strstart+e.lookahead-wu,r=su._tr_tally(e,e.strstart-1-e.prev_match,e.prev_length-wu),e.lookahead-=e.prev_length-1,e.prev_length-=2;do{++e.strstart<=o&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+wu-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart)}while(0!=--e.prev_length);if(e.match_available=0,e.match_length=wu-1,e.strstart++,r&&(Nu(e,!1),0===e.strm.avail_out))return 1}else if(e.match_available){if((r=su._tr_tally(e,0,e.window[e.strstart-1]))&&Nu(e,!1),e.strstart++,e.lookahead--,0===e.strm.avail_out)return 1}else e.match_available=1,e.strstart++,e.lookahead--}return e.match_available&&(r=su._tr_tally(e,0,e.window[e.strstart-1]),e.match_available=0),e.insert=e.strstart<wu-1?e.strstart:wu-1,4===t?(Nu(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(Nu(e,!1),0===e.strm.avail_out)?1:2}function Bu(e,t,n,r,o){this.good_length=e,this.max_lazy=t,this.nice_length=n,this.max_chain=r,this.func=o}function Wu(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=mu,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new au.Buf16(2*_u),this.dyn_dtree=new au.Buf16(2*(2*yu+1)),this.bl_tree=new au.Buf16(2*(2*bu+1)),Lu(this.dyn_ltree),Lu(this.dyn_dtree),Lu(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new au.Buf16(vu+1),this.heap=new au.Buf16(2*gu+1),Lu(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new au.Buf16(2*gu+1),Lu(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function Ju(e){var t;return e&&e.state?(e.total_in=e.total_out=0,e.data_type=fu,(t=e.state).pending=0,t.pending_out=0,t.wrap<0&&(t.wrap=-t.wrap),t.status=t.wrap?Su:Au,e.adler=2===t.wrap?0:1,t.last_flush=du,su._tr_init(t),hu):Cu(e,pu)}function Fu(e){var t,n=Ju(e);return n===hu&&((t=e.state).window_size=2*t.w_size,Lu(t.head),t.max_lazy_match=tu[t.level].max_lazy,t.good_match=tu[t.level].good_length,t.nice_match=tu[t.level].nice_length,t.max_chain_length=tu[t.level].max_chain,t.strstart=0,t.block_start=0,t.lookahead=0,t.insert=0,t.match_length=t.prev_length=wu-1,t.match_available=0,t.ins_h=0),n}function Yu(e,t,n,r,o,i){if(!e)return pu;var a=1;if(-1===t&&(t=6),r<0?(a=0,r=-r):r>15&&(a=2,r-=16),o<1||o>9||n!==mu||r<8||r>15||t<0||t>9||i<0||i>4)return Cu(e,pu);8===r&&(r=9);var s=new Wu;return e.state=s,s.strm=e,s.wrap=a,s.gzhead=null,s.w_bits=r,s.w_size=1<<s.w_bits,s.w_mask=s.w_size-1,s.hash_bits=o+7,s.hash_size=1<<s.hash_bits,s.hash_mask=s.hash_size-1,s.hash_shift=~~((s.hash_bits+wu-1)/wu),s.window=new au.Buf8(2*s.w_size),s.head=new au.Buf16(s.hash_size),s.prev=new au.Buf16(s.w_size),s.lit_bufsize=1<<o+6,s.pending_buf_size=4*s.lit_bufsize,s.pending_buf=new au.Buf8(s.pending_buf_size),s.d_buf=1*s.lit_bufsize,s.l_buf=3*s.lit_bufsize,s.level=t,s.strategy=i,s.method=n,Fu(e)}tu=[new Bu(0,0,0,0,(function(e,t){var n=65535;for(n>e.pending_buf_size-5&&(n=e.pending_buf_size-5);;){if(e.lookahead<=1){if(Ru(e),0===e.lookahead&&t===du)return 1;if(0===e.lookahead)break}e.strstart+=e.lookahead,e.lookahead=0;var r=e.block_start+n;if((0===e.strstart||e.strstart>=r)&&(e.lookahead=e.strstart-r,e.strstart=r,Nu(e,!1),0===e.strm.avail_out))return 1;if(e.strstart-e.block_start>=e.w_size-xu&&(Nu(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(Nu(e,!0),0===e.strm.avail_out?3:4):(e.strstart>e.block_start&&(Nu(e,!1),e.strm.avail_out),1)})),new Bu(4,4,8,4,Du),new Bu(4,5,16,8,Du),new Bu(4,6,32,32,Du),new Bu(4,4,16,16,Mu),new Bu(8,16,32,32,Mu),new Bu(8,16,128,128,Mu),new Bu(8,32,128,256,Mu),new Bu(32,128,258,1024,Mu),new Bu(32,258,258,4096,Mu)],mc.deflateInit=function(e,t){return Yu(e,t,mu,15,8,0)},mc.deflateInit2=Yu,mc.deflateReset=Fu,mc.deflateResetKeep=Ju,mc.deflateSetHeader=function(e,t){return e&&e.state?2!==e.state.wrap?pu:(e.state.gzhead=t,hu):pu},mc.deflate=function(e,t){var n,r,o,i;if(!e||!e.state||t>5||t<0)return e?Cu(e,pu):pu;if(r=e.state,!e.output||!e.input&&0!==e.avail_in||r.status===Eu&&4!==t)return Cu(e,0===e.avail_out?-5:pu);if(r.strm=e,n=r.last_flush,r.last_flush=t,r.status===Su)if(2===r.wrap)e.adler=0,Tu(r,31),Tu(r,139),Tu(r,8),r.gzhead?(Tu(r,(r.gzhead.text?1:0)+(r.gzhead.hcrc?2:0)+(r.gzhead.extra?4:0)+(r.gzhead.name?8:0)+(r.gzhead.comment?16:0)),Tu(r,255&r.gzhead.time),Tu(r,r.gzhead.time>>8&255),Tu(r,r.gzhead.time>>16&255),Tu(r,r.gzhead.time>>24&255),Tu(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Tu(r,255&r.gzhead.os),r.gzhead.extra&&r.gzhead.extra.length&&(Tu(r,255&r.gzhead.extra.length),Tu(r,r.gzhead.extra.length>>8&255)),r.gzhead.hcrc&&(e.adler=cu(e.adler,r.pending_buf,r.pending,0)),r.gzindex=0,r.status=69):(Tu(r,0),Tu(r,0),Tu(r,0),Tu(r,0),Tu(r,0),Tu(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Tu(r,3),r.status=Au);else{var a=mu+(r.w_bits-8<<4)<<8;a|=(r.strategy>=2||r.level<2?0:r.level<6?1:6===r.level?2:3)<<6,0!==r.strstart&&(a|=32),a+=31-a%31,r.status=Au,ju(r,a),0!==r.strstart&&(ju(r,e.adler>>>16),ju(r,65535&e.adler)),e.adler=1}if(69===r.status)if(r.gzhead.extra){for(o=r.pending;r.gzindex<(65535&r.gzhead.extra.length)&&(r.pending!==r.pending_buf_size||(r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),zu(e),o=r.pending,r.pending!==r.pending_buf_size));)Tu(r,255&r.gzhead.extra[r.gzindex]),r.gzindex++;r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),r.gzindex===r.gzhead.extra.length&&(r.gzindex=0,r.status=73)}else r.status=73;if(73===r.status)if(r.gzhead.name){o=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),zu(e),o=r.pending,r.pending===r.pending_buf_size)){i=1;break}i=r.gzindex<r.gzhead.name.length?255&r.gzhead.name.charCodeAt(r.gzindex++):0,Tu(r,i)}while(0!==i);r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),0===i&&(r.gzindex=0,r.status=91)}else r.status=91;if(91===r.status)if(r.gzhead.comment){o=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),zu(e),o=r.pending,r.pending===r.pending_buf_size)){i=1;break}i=r.gzindex<r.gzhead.comment.length?255&r.gzhead.comment.charCodeAt(r.gzindex++):0,Tu(r,i)}while(0!==i);r.gzhead.hcrc&&r.pending>o&&(e.adler=cu(e.adler,r.pending_buf,r.pending-o,o)),0===i&&(r.status=Ou)}else r.status=Ou;if(r.status===Ou&&(r.gzhead.hcrc?(r.pending+2>r.pending_buf_size&&zu(e),r.pending+2<=r.pending_buf_size&&(Tu(r,255&e.adler),Tu(r,e.adler>>8&255),e.adler=0,r.status=Au)):r.status=Au),0!==r.pending){if(zu(e),0===e.avail_out)return r.last_flush=-1,hu}else if(0===e.avail_in&&Pu(t)<=Pu(n)&&4!==t)return Cu(e,-5);if(r.status===Eu&&0!==e.avail_in)return Cu(e,-5);if(0!==e.avail_in||0!==r.lookahead||t!==du&&r.status!==Eu){var s=2===r.strategy?function(e,t){for(var n;;){if(0===e.lookahead&&(Ru(e),0===e.lookahead)){if(t===du)return 1;break}if(e.match_length=0,n=su._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++,n&&(Nu(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(Nu(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(Nu(e,!1),0===e.strm.avail_out)?1:2}(r,t):3===r.strategy?function(e,t){for(var n,r,o,i,a=e.window;;){if(e.lookahead<=ku){if(Ru(e),e.lookahead<=ku&&t===du)return 1;if(0===e.lookahead)break}if(e.match_length=0,e.lookahead>=wu&&e.strstart>0&&(r=a[o=e.strstart-1])===a[++o]&&r===a[++o]&&r===a[++o]){i=e.strstart+ku;do{}while(r===a[++o]&&r===a[++o]&&r===a[++o]&&r===a[++o]&&r===a[++o]&&r===a[++o]&&r===a[++o]&&r===a[++o]&&o<i);e.match_length=ku-(i-o),e.match_length>e.lookahead&&(e.match_length=e.lookahead)}if(e.match_length>=wu?(n=su._tr_tally(e,1,e.match_length-wu),e.lookahead-=e.match_length,e.strstart+=e.match_length,e.match_length=0):(n=su._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++),n&&(Nu(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(Nu(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(Nu(e,!1),0===e.strm.avail_out)?1:2}(r,t):tu[r.level].func(r,t);if(3!==s&&4!==s||(r.status=Eu),1===s||3===s)return 0===e.avail_out&&(r.last_flush=-1),hu;if(2===s&&(1===t?su._tr_align(r):5!==t&&(su._tr_stored_block(r,0,0,!1),3===t&&(Lu(r.head),0===r.lookahead&&(r.strstart=0,r.block_start=0,r.insert=0))),zu(e),0===e.avail_out))return r.last_flush=-1,hu}return 4!==t?hu:r.wrap<=0?1:(2===r.wrap?(Tu(r,255&e.adler),Tu(r,e.adler>>8&255),Tu(r,e.adler>>16&255),Tu(r,e.adler>>24&255),Tu(r,255&e.total_in),Tu(r,e.total_in>>8&255),Tu(r,e.total_in>>16&255),Tu(r,e.total_in>>24&255)):(ju(r,e.adler>>>16),ju(r,65535&e.adler)),zu(e),r.wrap>0&&(r.wrap=-r.wrap),0!==r.pending?hu:1)},mc.deflateEnd=function(e){var t;return e&&e.state?(t=e.state.status)!==Su&&69!==t&&73!==t&&91!==t&&t!==Ou&&t!==Au&&t!==Eu?Cu(e,pu):(e.state=null,t===Au?Cu(e,-3):hu):pu},mc.deflateSetDictionary=function(e,t){var n,r,o,i,a,s,l,c,u=t.length;if(!e||!e.state)return pu;if(2===(i=(n=e.state).wrap)||1===i&&n.status!==Su||n.lookahead)return pu;for(1===i&&(e.adler=lu(e.adler,t,u,0)),n.wrap=0,u>=n.w_size&&(0===i&&(Lu(n.head),n.strstart=0,n.block_start=0,n.insert=0),c=new au.Buf8(n.w_size),au.arraySet(c,t,u-n.w_size,n.w_size,0),t=c,u=n.w_size),a=e.avail_in,s=e.next_in,l=e.input,e.avail_in=u,e.next_in=0,e.input=t,Ru(n);n.lookahead>=wu;){r=n.strstart,o=n.lookahead-(wu-1);do{n.ins_h=(n.ins_h<<n.hash_shift^n.window[r+wu-1])&n.hash_mask,n.prev[r&n.w_mask]=n.head[n.ins_h],n.head[n.ins_h]=r,r++}while(--o);n.strstart=r,n.lookahead=wu-1,Ru(n)}return n.strstart+=n.lookahead,n.block_start=n.strstart,n.insert=n.lookahead,n.lookahead=0,n.match_length=n.prev_length=wu-1,n.match_available=0,e.next_in=s,e.input=l,e.avail_in=a,n.wrap=i,hu},mc.deflateInfo="pako deflate (from Nodeca project)";var Uu={},$u=pc,Vu=!0,qu=!0;try{String.fromCharCode.apply(null,[0])}catch(e){Vu=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch(e){qu=!1}for(var Hu=new $u.Buf8(256),Zu=0;Zu<256;Zu++)Hu[Zu]=Zu>=252?6:Zu>=248?5:Zu>=240?4:Zu>=224?3:Zu>=192?2:1;function Ku(e,t){if(t<65534&&(e.subarray&&qu||!e.subarray&&Vu))return String.fromCharCode.apply(null,$u.shrinkBuf(e,t));for(var n="",r=0;r<t;r++)n+=String.fromCharCode(e[r]);return n}Hu[254]=Hu[254]=1,Uu.string2buf=function(e){var t,n,r,o,i,a=e.length,s=0;for(o=0;o<a;o++)55296==(64512&(n=e.charCodeAt(o)))&&o+1<a&&56320==(64512&(r=e.charCodeAt(o+1)))&&(n=65536+(n-55296<<10)+(r-56320),o++),s+=n<128?1:n<2048?2:n<65536?3:4;for(t=new $u.Buf8(s),i=0,o=0;i<s;o++)55296==(64512&(n=e.charCodeAt(o)))&&o+1<a&&56320==(64512&(r=e.charCodeAt(o+1)))&&(n=65536+(n-55296<<10)+(r-56320),o++),n<128?t[i++]=n:n<2048?(t[i++]=192|n>>>6,t[i++]=128|63&n):n<65536?(t[i++]=224|n>>>12,t[i++]=128|n>>>6&63,t[i++]=128|63&n):(t[i++]=240|n>>>18,t[i++]=128|n>>>12&63,t[i++]=128|n>>>6&63,t[i++]=128|63&n);return t},Uu.buf2binstring=function(e){return Ku(e,e.length)},Uu.binstring2buf=function(e){for(var t=new $u.Buf8(e.length),n=0,r=t.length;n<r;n++)t[n]=e.charCodeAt(n);return t},Uu.buf2string=function(e,t){var n,r,o,i,a=t||e.length,s=new Array(2*a);for(r=0,n=0;n<a;)if((o=e[n++])<128)s[r++]=o;else if((i=Hu[o])>4)s[r++]=65533,n+=i-1;else{for(o&=2===i?31:3===i?15:7;i>1&&n<a;)o=o<<6|63&e[n++],i--;i>1?s[r++]=65533:o<65536?s[r++]=o:(o-=65536,s[r++]=55296|o>>10&1023,s[r++]=56320|1023&o)}return Ku(s,r)},Uu.utf8border=function(e,t){var n;for((t=t||e.length)>e.length&&(t=e.length),n=t-1;n>=0&&128==(192&e[n]);)n--;return n<0||0===n?t:n+Hu[e[n]]>t?n:t};var Gu=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0},Xu=mc,Qu=pc,ed=Uu,td=iu,nd=Gu,rd=Object.prototype.toString,od=0,id=-1,ad=0,sd=8;function ld(e){if(!(this instanceof ld))return new ld(e);this.options=Qu.assign({level:id,method:sd,chunkSize:16384,windowBits:15,memLevel:8,strategy:ad,to:""},e||{});var t=this.options;t.raw&&t.windowBits>0?t.windowBits=-t.windowBits:t.gzip&&t.windowBits>0&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new nd,this.strm.avail_out=0;var n=Xu.deflateInit2(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy);if(n!==od)throw new Error(td[n]);if(t.header&&Xu.deflateSetHeader(this.strm,t.header),t.dictionary){var r;if(r="string"==typeof t.dictionary?ed.string2buf(t.dictionary):"[object ArrayBuffer]"===rd.call(t.dictionary)?new Uint8Array(t.dictionary):t.dictionary,(n=Xu.deflateSetDictionary(this.strm,r))!==od)throw new Error(td[n]);this._dict_set=!0}}function cd(e,t){var n=new ld(t);if(n.push(e,!0),n.err)throw n.msg||td[n.err];return n.result}ld.prototype.push=function(e,t){var n,r,o=this.strm,i=this.options.chunkSize;if(this.ended)return!1;r=t===~~t?t:!0===t?4:0,"string"==typeof e?o.input=ed.string2buf(e):"[object ArrayBuffer]"===rd.call(e)?o.input=new Uint8Array(e):o.input=e,o.next_in=0,o.avail_in=o.input.length;do{if(0===o.avail_out&&(o.output=new Qu.Buf8(i),o.next_out=0,o.avail_out=i),1!==(n=Xu.deflate(o,r))&&n!==od)return this.onEnd(n),this.ended=!0,!1;0!==o.avail_out&&(0!==o.avail_in||4!==r&&2!==r)||("string"===this.options.to?this.onData(ed.buf2binstring(Qu.shrinkBuf(o.output,o.next_out))):this.onData(Qu.shrinkBuf(o.output,o.next_out)))}while((o.avail_in>0||0===o.avail_out)&&1!==n);return 4===r?(n=Xu.deflateEnd(this.strm),this.onEnd(n),this.ended=!0,n===od):2!==r||(this.onEnd(od),o.avail_out=0,!0)},ld.prototype.onData=function(e){this.chunks.push(e)},ld.prototype.onEnd=function(e){e===od&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=Qu.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},fc.Deflate=ld,fc.deflate=cd,fc.deflateRaw=function(e,t){return(t=t||{}).raw=!0,cd(e,t)},fc.gzip=function(e,t){return(t=t||{}).gzip=!0,cd(e,t)};var ud={},dd={},hd=pc,pd=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],fd=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],md=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],gd=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64],yd=pc,bd=nu,_d=ou,vd=function(e,t){var n,r,o,i,a,s,l,c,u,d,h,p,f,m,g,y,b,_,v,w,k,x,S,O,A;n=e.state,r=e.next_in,O=e.input,o=r+(e.avail_in-5),i=e.next_out,A=e.output,a=i-(t-e.avail_out),s=i+(e.avail_out-257),l=n.dmax,c=n.wsize,u=n.whave,d=n.wnext,h=n.window,p=n.hold,f=n.bits,m=n.lencode,g=n.distcode,y=(1<<n.lenbits)-1,b=(1<<n.distbits)-1;e:do{f<15&&(p+=O[r++]<<f,f+=8,p+=O[r++]<<f,f+=8),_=m[p&y];t:for(;;){if(p>>>=v=_>>>24,f-=v,0==(v=_>>>16&255))A[i++]=65535&_;else{if(!(16&v)){if(0==(64&v)){_=m[(65535&_)+(p&(1<<v)-1)];continue t}if(32&v){n.mode=12;break e}e.msg="invalid literal/length code",n.mode=30;break e}w=65535&_,(v&=15)&&(f<v&&(p+=O[r++]<<f,f+=8),w+=p&(1<<v)-1,p>>>=v,f-=v),f<15&&(p+=O[r++]<<f,f+=8,p+=O[r++]<<f,f+=8),_=g[p&b];n:for(;;){if(p>>>=v=_>>>24,f-=v,!(16&(v=_>>>16&255))){if(0==(64&v)){_=g[(65535&_)+(p&(1<<v)-1)];continue n}e.msg="invalid distance code",n.mode=30;break e}if(k=65535&_,f<(v&=15)&&(p+=O[r++]<<f,(f+=8)<v&&(p+=O[r++]<<f,f+=8)),(k+=p&(1<<v)-1)>l){e.msg="invalid distance too far back",n.mode=30;break e}if(p>>>=v,f-=v,k>(v=i-a)){if((v=k-v)>u&&n.sane){e.msg="invalid distance too far back",n.mode=30;break e}if(x=0,S=h,0===d){if(x+=c-v,v<w){w-=v;do{A[i++]=h[x++]}while(--v);x=i-k,S=A}}else if(d<v){if(x+=c+d-v,(v-=d)<w){w-=v;do{A[i++]=h[x++]}while(--v);if(x=0,d<w){w-=v=d;do{A[i++]=h[x++]}while(--v);x=i-k,S=A}}}else if(x+=d-v,v<w){w-=v;do{A[i++]=h[x++]}while(--v);x=i-k,S=A}for(;w>2;)A[i++]=S[x++],A[i++]=S[x++],A[i++]=S[x++],w-=3;w&&(A[i++]=S[x++],w>1&&(A[i++]=S[x++]))}else{x=i-k;do{A[i++]=A[x++],A[i++]=A[x++],A[i++]=A[x++],w-=3}while(w>2);w&&(A[i++]=A[x++],w>1&&(A[i++]=A[x++]))}break}}break}}while(r<o&&i<s);r-=w=f>>3,p&=(1<<(f-=w<<3))-1,e.next_in=r,e.next_out=i,e.avail_in=r<o?o-r+5:5-(r-o),e.avail_out=i<s?s-i+257:257-(i-s),n.hold=p,n.bits=f},wd=function(e,t,n,r,o,i,a,s){var l,c,u,d,h,p,f,m,g,y=s.bits,b=0,_=0,v=0,w=0,k=0,x=0,S=0,O=0,A=0,E=0,C=null,P=0,L=new hd.Buf16(16),z=new hd.Buf16(16),N=null,T=0;for(b=0;b<=15;b++)L[b]=0;for(_=0;_<r;_++)L[t[n+_]]++;for(k=y,w=15;w>=1&&0===L[w];w--);if(k>w&&(k=w),0===w)return o[i++]=20971520,o[i++]=20971520,s.bits=1,0;for(v=1;v<w&&0===L[v];v++);for(k<v&&(k=v),O=1,b=1;b<=15;b++)if(O<<=1,(O-=L[b])<0)return-1;if(O>0&&(0===e||1!==w))return-1;for(z[1]=0,b=1;b<15;b++)z[b+1]=z[b]+L[b];for(_=0;_<r;_++)0!==t[n+_]&&(a[z[t[n+_]]++]=_);if(0===e?(C=N=a,p=19):1===e?(C=pd,P-=257,N=fd,T-=257,p=256):(C=md,N=gd,p=-1),E=0,_=0,b=v,h=i,x=k,S=0,u=-1,d=(A=1<<k)-1,1===e&&A>852||2===e&&A>592)return 1;for(;;){f=b-S,a[_]<p?(m=0,g=a[_]):a[_]>p?(m=N[T+a[_]],g=C[P+a[_]]):(m=96,g=0),l=1<<b-S,v=c=1<<x;do{o[h+(E>>S)+(c-=l)]=f<<24|m<<16|g|0}while(0!==c);for(l=1<<b-1;E&l;)l>>=1;if(0!==l?(E&=l-1,E+=l):E=0,_++,0==--L[b]){if(b===w)break;b=t[n+a[_]]}if(b>k&&(E&d)!==u){for(0===S&&(S=k),h+=v,O=1<<(x=b-S);x+S<w&&!((O-=L[x+S])<=0);)x++,O<<=1;if(A+=1<<x,1===e&&A>852||2===e&&A>592)return 1;o[u=E&d]=k<<24|x<<16|h-i|0}}return 0!==E&&(o[h+E]=b-S<<24|64<<16|0),s.bits=k,0},kd=0,xd=-2,Sd=1,Od=12,Ad=30,Ed=852,Cd=592;function Pd(e){return(e>>>24&255)+(e>>>8&65280)+((65280&e)<<8)+((255&e)<<24)}function Ld(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new yd.Buf16(320),this.work=new yd.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function zd(e){var t;return e&&e.state?(t=e.state,e.total_in=e.total_out=t.total=0,e.msg="",t.wrap&&(e.adler=1&t.wrap),t.mode=Sd,t.last=0,t.havedict=0,t.dmax=32768,t.head=null,t.hold=0,t.bits=0,t.lencode=t.lendyn=new yd.Buf32(Ed),t.distcode=t.distdyn=new yd.Buf32(Cd),t.sane=1,t.back=-1,kd):xd}function Nd(e){var t;return e&&e.state?((t=e.state).wsize=0,t.whave=0,t.wnext=0,zd(e)):xd}function Td(e,t){var n,r;return e&&e.state?(r=e.state,t<0?(n=0,t=-t):(n=1+(t>>4),t<48&&(t&=15)),t&&(t<8||t>15)?xd:(null!==r.window&&r.wbits!==t&&(r.window=null),r.wrap=n,r.wbits=t,Nd(e))):xd}function jd(e,t){var n,r;return e?(r=new Ld,e.state=r,r.window=null,(n=Td(e,t))!==kd&&(e.state=null),n):xd}var Id,Rd,Dd=!0;function Md(e){if(Dd){var t;for(Id=new yd.Buf32(512),Rd=new yd.Buf32(32),t=0;t<144;)e.lens[t++]=8;for(;t<256;)e.lens[t++]=9;for(;t<280;)e.lens[t++]=7;for(;t<288;)e.lens[t++]=8;for(wd(1,e.lens,0,288,Id,0,e.work,{bits:9}),t=0;t<32;)e.lens[t++]=5;wd(2,e.lens,0,32,Rd,0,e.work,{bits:5}),Dd=!1}e.lencode=Id,e.lenbits=9,e.distcode=Rd,e.distbits=5}function Bd(e,t,n,r){var o,i=e.state;return null===i.window&&(i.wsize=1<<i.wbits,i.wnext=0,i.whave=0,i.window=new yd.Buf8(i.wsize)),r>=i.wsize?(yd.arraySet(i.window,t,n-i.wsize,i.wsize,0),i.wnext=0,i.whave=i.wsize):((o=i.wsize-i.wnext)>r&&(o=r),yd.arraySet(i.window,t,n-r,o,i.wnext),(r-=o)?(yd.arraySet(i.window,t,n-r,r,0),i.wnext=r,i.whave=i.wsize):(i.wnext+=o,i.wnext===i.wsize&&(i.wnext=0),i.whave<i.wsize&&(i.whave+=o))),0}dd.inflateReset=Nd,dd.inflateReset2=Td,dd.inflateResetKeep=zd,dd.inflateInit=function(e){return jd(e,15)},dd.inflateInit2=jd,dd.inflate=function(e,t){var n,r,o,i,a,s,l,c,u,d,h,p,f,m,g,y,b,_,v,w,k,x,S,O,A=0,E=new yd.Buf8(4),C=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!e||!e.state||!e.output||!e.input&&0!==e.avail_in)return xd;(n=e.state).mode===Od&&(n.mode=13),a=e.next_out,o=e.output,l=e.avail_out,i=e.next_in,r=e.input,s=e.avail_in,c=n.hold,u=n.bits,d=s,h=l,x=kd;e:for(;;)switch(n.mode){case Sd:if(0===n.wrap){n.mode=13;break}for(;u<16;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(2&n.wrap&&35615===c){n.check=0,E[0]=255&c,E[1]=c>>>8&255,n.check=_d(n.check,E,2,0),c=0,u=0,n.mode=2;break}if(n.flags=0,n.head&&(n.head.done=!1),!(1&n.wrap)||(((255&c)<<8)+(c>>8))%31){e.msg="incorrect header check",n.mode=Ad;break}if(8!=(15&c)){e.msg="unknown compression method",n.mode=Ad;break}if(u-=4,k=8+(15&(c>>>=4)),0===n.wbits)n.wbits=k;else if(k>n.wbits){e.msg="invalid window size",n.mode=Ad;break}n.dmax=1<<k,e.adler=n.check=1,n.mode=512&c?10:Od,c=0,u=0;break;case 2:for(;u<16;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(n.flags=c,8!=(255&n.flags)){e.msg="unknown compression method",n.mode=Ad;break}if(57344&n.flags){e.msg="unknown header flags set",n.mode=Ad;break}n.head&&(n.head.text=c>>8&1),512&n.flags&&(E[0]=255&c,E[1]=c>>>8&255,n.check=_d(n.check,E,2,0)),c=0,u=0,n.mode=3;case 3:for(;u<32;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.head&&(n.head.time=c),512&n.flags&&(E[0]=255&c,E[1]=c>>>8&255,E[2]=c>>>16&255,E[3]=c>>>24&255,n.check=_d(n.check,E,4,0)),c=0,u=0,n.mode=4;case 4:for(;u<16;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.head&&(n.head.xflags=255&c,n.head.os=c>>8),512&n.flags&&(E[0]=255&c,E[1]=c>>>8&255,n.check=_d(n.check,E,2,0)),c=0,u=0,n.mode=5;case 5:if(1024&n.flags){for(;u<16;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.length=c,n.head&&(n.head.extra_len=c),512&n.flags&&(E[0]=255&c,E[1]=c>>>8&255,n.check=_d(n.check,E,2,0)),c=0,u=0}else n.head&&(n.head.extra=null);n.mode=6;case 6:if(1024&n.flags&&((p=n.length)>s&&(p=s),p&&(n.head&&(k=n.head.extra_len-n.length,n.head.extra||(n.head.extra=new Array(n.head.extra_len)),yd.arraySet(n.head.extra,r,i,p,k)),512&n.flags&&(n.check=_d(n.check,r,p,i)),s-=p,i+=p,n.length-=p),n.length))break e;n.length=0,n.mode=7;case 7:if(2048&n.flags){if(0===s)break e;p=0;do{k=r[i+p++],n.head&&k&&n.length<65536&&(n.head.name+=String.fromCharCode(k))}while(k&&p<s);if(512&n.flags&&(n.check=_d(n.check,r,p,i)),s-=p,i+=p,k)break e}else n.head&&(n.head.name=null);n.length=0,n.mode=8;case 8:if(4096&n.flags){if(0===s)break e;p=0;do{k=r[i+p++],n.head&&k&&n.length<65536&&(n.head.comment+=String.fromCharCode(k))}while(k&&p<s);if(512&n.flags&&(n.check=_d(n.check,r,p,i)),s-=p,i+=p,k)break e}else n.head&&(n.head.comment=null);n.mode=9;case 9:if(512&n.flags){for(;u<16;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(c!==(65535&n.check)){e.msg="header crc mismatch",n.mode=Ad;break}c=0,u=0}n.head&&(n.head.hcrc=n.flags>>9&1,n.head.done=!0),e.adler=n.check=0,n.mode=Od;break;case 10:for(;u<32;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}e.adler=n.check=Pd(c),c=0,u=0,n.mode=11;case 11:if(0===n.havedict)return e.next_out=a,e.avail_out=l,e.next_in=i,e.avail_in=s,n.hold=c,n.bits=u,2;e.adler=n.check=1,n.mode=Od;case Od:if(5===t||6===t)break e;case 13:if(n.last){c>>>=7&u,u-=7&u,n.mode=27;break}for(;u<3;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}switch(n.last=1&c,u-=1,3&(c>>>=1)){case 0:n.mode=14;break;case 1:if(Md(n),n.mode=20,6===t){c>>>=2,u-=2;break e}break;case 2:n.mode=17;break;case 3:e.msg="invalid block type",n.mode=Ad}c>>>=2,u-=2;break;case 14:for(c>>>=7&u,u-=7&u;u<32;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if((65535&c)!=(c>>>16^65535)){e.msg="invalid stored block lengths",n.mode=Ad;break}if(n.length=65535&c,c=0,u=0,n.mode=15,6===t)break e;case 15:n.mode=16;case 16:if(p=n.length){if(p>s&&(p=s),p>l&&(p=l),0===p)break e;yd.arraySet(o,r,i,p,a),s-=p,i+=p,l-=p,a+=p,n.length-=p;break}n.mode=Od;break;case 17:for(;u<14;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(n.nlen=257+(31&c),c>>>=5,u-=5,n.ndist=1+(31&c),c>>>=5,u-=5,n.ncode=4+(15&c),c>>>=4,u-=4,n.nlen>286||n.ndist>30){e.msg="too many length or distance symbols",n.mode=Ad;break}n.have=0,n.mode=18;case 18:for(;n.have<n.ncode;){for(;u<3;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.lens[C[n.have++]]=7&c,c>>>=3,u-=3}for(;n.have<19;)n.lens[C[n.have++]]=0;if(n.lencode=n.lendyn,n.lenbits=7,S={bits:n.lenbits},x=wd(0,n.lens,0,19,n.lencode,0,n.work,S),n.lenbits=S.bits,x){e.msg="invalid code lengths set",n.mode=Ad;break}n.have=0,n.mode=19;case 19:for(;n.have<n.nlen+n.ndist;){for(;y=(A=n.lencode[c&(1<<n.lenbits)-1])>>>16&255,b=65535&A,!((g=A>>>24)<=u);){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(b<16)c>>>=g,u-=g,n.lens[n.have++]=b;else{if(16===b){for(O=g+2;u<O;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(c>>>=g,u-=g,0===n.have){e.msg="invalid bit length repeat",n.mode=Ad;break}k=n.lens[n.have-1],p=3+(3&c),c>>>=2,u-=2}else if(17===b){for(O=g+3;u<O;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}u-=g,k=0,p=3+(7&(c>>>=g)),c>>>=3,u-=3}else{for(O=g+7;u<O;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}u-=g,k=0,p=11+(127&(c>>>=g)),c>>>=7,u-=7}if(n.have+p>n.nlen+n.ndist){e.msg="invalid bit length repeat",n.mode=Ad;break}for(;p--;)n.lens[n.have++]=k}}if(n.mode===Ad)break;if(0===n.lens[256]){e.msg="invalid code -- missing end-of-block",n.mode=Ad;break}if(n.lenbits=9,S={bits:n.lenbits},x=wd(1,n.lens,0,n.nlen,n.lencode,0,n.work,S),n.lenbits=S.bits,x){e.msg="invalid literal/lengths set",n.mode=Ad;break}if(n.distbits=6,n.distcode=n.distdyn,S={bits:n.distbits},x=wd(2,n.lens,n.nlen,n.ndist,n.distcode,0,n.work,S),n.distbits=S.bits,x){e.msg="invalid distances set",n.mode=Ad;break}if(n.mode=20,6===t)break e;case 20:n.mode=21;case 21:if(s>=6&&l>=258){e.next_out=a,e.avail_out=l,e.next_in=i,e.avail_in=s,n.hold=c,n.bits=u,vd(e,h),a=e.next_out,o=e.output,l=e.avail_out,i=e.next_in,r=e.input,s=e.avail_in,c=n.hold,u=n.bits,n.mode===Od&&(n.back=-1);break}for(n.back=0;y=(A=n.lencode[c&(1<<n.lenbits)-1])>>>16&255,b=65535&A,!((g=A>>>24)<=u);){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(y&&0==(240&y)){for(_=g,v=y,w=b;y=(A=n.lencode[w+((c&(1<<_+v)-1)>>_)])>>>16&255,b=65535&A,!(_+(g=A>>>24)<=u);){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}c>>>=_,u-=_,n.back+=_}if(c>>>=g,u-=g,n.back+=g,n.length=b,0===y){n.mode=26;break}if(32&y){n.back=-1,n.mode=Od;break}if(64&y){e.msg="invalid literal/length code",n.mode=Ad;break}n.extra=15&y,n.mode=22;case 22:if(n.extra){for(O=n.extra;u<O;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.length+=c&(1<<n.extra)-1,c>>>=n.extra,u-=n.extra,n.back+=n.extra}n.was=n.length,n.mode=23;case 23:for(;y=(A=n.distcode[c&(1<<n.distbits)-1])>>>16&255,b=65535&A,!((g=A>>>24)<=u);){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(0==(240&y)){for(_=g,v=y,w=b;y=(A=n.distcode[w+((c&(1<<_+v)-1)>>_)])>>>16&255,b=65535&A,!(_+(g=A>>>24)<=u);){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}c>>>=_,u-=_,n.back+=_}if(c>>>=g,u-=g,n.back+=g,64&y){e.msg="invalid distance code",n.mode=Ad;break}n.offset=b,n.extra=15&y,n.mode=24;case 24:if(n.extra){for(O=n.extra;u<O;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}n.offset+=c&(1<<n.extra)-1,c>>>=n.extra,u-=n.extra,n.back+=n.extra}if(n.offset>n.dmax){e.msg="invalid distance too far back",n.mode=Ad;break}n.mode=25;case 25:if(0===l)break e;if(p=h-l,n.offset>p){if((p=n.offset-p)>n.whave&&n.sane){e.msg="invalid distance too far back",n.mode=Ad;break}p>n.wnext?(p-=n.wnext,f=n.wsize-p):f=n.wnext-p,p>n.length&&(p=n.length),m=n.window}else m=o,f=a-n.offset,p=n.length;p>l&&(p=l),l-=p,n.length-=p;do{o[a++]=m[f++]}while(--p);0===n.length&&(n.mode=21);break;case 26:if(0===l)break e;o[a++]=n.length,l--,n.mode=21;break;case 27:if(n.wrap){for(;u<32;){if(0===s)break e;s--,c|=r[i++]<<u,u+=8}if(h-=l,e.total_out+=h,n.total+=h,h&&(e.adler=n.check=n.flags?_d(n.check,o,h,a-h):bd(n.check,o,h,a-h)),h=l,(n.flags?c:Pd(c))!==n.check){e.msg="incorrect data check",n.mode=Ad;break}c=0,u=0}n.mode=28;case 28:if(n.wrap&&n.flags){for(;u<32;){if(0===s)break e;s--,c+=r[i++]<<u,u+=8}if(c!==(4294967295&n.total)){e.msg="incorrect length check",n.mode=Ad;break}c=0,u=0}n.mode=29;case 29:x=1;break e;case Ad:x=-3;break e;case 31:return-4;default:return xd}return e.next_out=a,e.avail_out=l,e.next_in=i,e.avail_in=s,n.hold=c,n.bits=u,(n.wsize||h!==e.avail_out&&n.mode<Ad&&(n.mode<27||4!==t))&&Bd(e,e.output,e.next_out,h-e.avail_out),d-=e.avail_in,h-=e.avail_out,e.total_in+=d,e.total_out+=h,n.total+=h,n.wrap&&h&&(e.adler=n.check=n.flags?_d(n.check,o,h,e.next_out-h):bd(n.check,o,h,e.next_out-h)),e.data_type=n.bits+(n.last?64:0)+(n.mode===Od?128:0)+(20===n.mode||15===n.mode?256:0),(0===d&&0===h||4===t)&&x===kd&&(x=-5),x},dd.inflateEnd=function(e){if(!e||!e.state)return xd;var t=e.state;return t.window&&(t.window=null),e.state=null,kd},dd.inflateGetHeader=function(e,t){var n;return e&&e.state?0==(2&(n=e.state).wrap)?xd:(n.head=t,t.done=!1,kd):xd},dd.inflateSetDictionary=function(e,t){var n,r=t.length;return e&&e.state?0!==(n=e.state).wrap&&11!==n.mode?xd:11===n.mode&&bd(1,t,r,0)!==n.check?-3:Bd(e,t,r,r)?(n.mode=31,-4):(n.havedict=1,kd):xd},dd.inflateInfo="pako inflate (from Nodeca project)";var Wd={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8},Jd=dd,Fd=pc,Yd=Uu,Ud=Wd,$d=iu,Vd=Gu,qd=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1},Hd=Object.prototype.toString;function Zd(e){if(!(this instanceof Zd))return new Zd(e);this.options=Fd.assign({chunkSize:16384,windowBits:0,to:""},e||{});var t=this.options;t.raw&&t.windowBits>=0&&t.windowBits<16&&(t.windowBits=-t.windowBits,0===t.windowBits&&(t.windowBits=-15)),!(t.windowBits>=0&&t.windowBits<16)||e&&e.windowBits||(t.windowBits+=32),t.windowBits>15&&t.windowBits<48&&0==(15&t.windowBits)&&(t.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new Vd,this.strm.avail_out=0;var n=Jd.inflateInit2(this.strm,t.windowBits);if(n!==Ud.Z_OK)throw new Error($d[n]);if(this.header=new qd,Jd.inflateGetHeader(this.strm,this.header),t.dictionary&&("string"==typeof t.dictionary?t.dictionary=Yd.string2buf(t.dictionary):"[object ArrayBuffer]"===Hd.call(t.dictionary)&&(t.dictionary=new Uint8Array(t.dictionary)),t.raw&&(n=Jd.inflateSetDictionary(this.strm,t.dictionary))!==Ud.Z_OK))throw new Error($d[n])}function Kd(e,t){var n=new Zd(t);if(n.push(e,!0),n.err)throw n.msg||$d[n.err];return n.result}Zd.prototype.push=function(e,t){var n,r,o,i,a,s=this.strm,l=this.options.chunkSize,c=this.options.dictionary,u=!1;if(this.ended)return!1;r=t===~~t?t:!0===t?Ud.Z_FINISH:Ud.Z_NO_FLUSH,"string"==typeof e?s.input=Yd.binstring2buf(e):"[object ArrayBuffer]"===Hd.call(e)?s.input=new Uint8Array(e):s.input=e,s.next_in=0,s.avail_in=s.input.length;do{if(0===s.avail_out&&(s.output=new Fd.Buf8(l),s.next_out=0,s.avail_out=l),(n=Jd.inflate(s,Ud.Z_NO_FLUSH))===Ud.Z_NEED_DICT&&c&&(n=Jd.inflateSetDictionary(this.strm,c)),n===Ud.Z_BUF_ERROR&&!0===u&&(n=Ud.Z_OK,u=!1),n!==Ud.Z_STREAM_END&&n!==Ud.Z_OK)return this.onEnd(n),this.ended=!0,!1;s.next_out&&(0!==s.avail_out&&n!==Ud.Z_STREAM_END&&(0!==s.avail_in||r!==Ud.Z_FINISH&&r!==Ud.Z_SYNC_FLUSH)||("string"===this.options.to?(o=Yd.utf8border(s.output,s.next_out),i=s.next_out-o,a=Yd.buf2string(s.output,o),s.next_out=i,s.avail_out=l-i,i&&Fd.arraySet(s.output,s.output,o,i,0),this.onData(a)):this.onData(Fd.shrinkBuf(s.output,s.next_out)))),0===s.avail_in&&0===s.avail_out&&(u=!0)}while((s.avail_in>0||0===s.avail_out)&&n!==Ud.Z_STREAM_END);return n===Ud.Z_STREAM_END&&(r=Ud.Z_FINISH),r===Ud.Z_FINISH?(n=Jd.inflateEnd(this.strm),this.onEnd(n),this.ended=!0,n===Ud.Z_OK):r!==Ud.Z_SYNC_FLUSH||(this.onEnd(Ud.Z_OK),s.avail_out=0,!0)},Zd.prototype.onData=function(e){this.chunks.push(e)},Zd.prototype.onEnd=function(e){e===Ud.Z_OK&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=Fd.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},ud.Inflate=Zd,ud.inflate=Kd,ud.inflateRaw=function(e,t){return(t=t||{}).raw=!0,Kd(e,t)},ud.ungzip=Kd;var Gd={};(0,pc.assign)(Gd,fc,ud,Wd);var Xd=Gd;function Qd({type:e,value:t,compress:n,serialize:r}){const o={type:e,value:t};return n&&(o.value=Xd.deflate(new Uint8Array(o.value)),o.compressed=!0),r&&(o.value=function(e){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""),n=new Uint8Array(e),r=n.length,o=r%3,i=[],a=16383;let s;for(let e=0,t=r-o;e<t;e+=a)i.push(l(e,e+a>t?t:e+a));return 1===o?(s=n[r-1],i.push(t[s>>2]+t[s<<4&63]+"==")):2===o&&(s=(n[r-2]<<8)+n[r-1],i.push(t[s>>10]+t[s>>4&63]+t[s<<2&63]+"=")),i.join("");function l(e,r){let o;const i=[];for(let s=e;s<r;s+=3)o=(n[s]<<16&16711680)+(n[s+1]<<8&65280)+(255&n[s+2]),i.push(t[(a=o)>>18&63]+t[a>>12&63]+t[a>>6&63]+t[63&a]);var a;return i.join("")}}(o.value)),o}function eh(e){return/^(blob|https?):/.test(e)}function th(e){const t=e&&e.match(/(^[^#]*)/),n=t&&t[1]||e;return n&&n.replace(/\?\s*$/,"?")||e}const nh=(...e)=>{};function rh(e){return e.reduce(((e,t)=>e.concat(t)),[])}let oh;function ih(){if(oh)return oh;if(void 0===e||t.top===t)return t.fetch;try{const t=e.createElement("iframe");t.setAttribute("data-applitools-skip","true"),t.style.display="none",e.head.appendChild(t);const n=t.contentWindow,r=n.fetch;"function"==typeof r&&(oh=r.bind(n))}catch(e){}return oh||t.fetch}function ah(t){const n=new TextDecoder("utf-8").decode(t),r=e.head||e.querySelectorAll("head")[0],o=e.createElement("style");return o.type="text/css",o.setAttribute("data-desc","Applitools tmp variable created by DOM SNAPSHOT"),r.appendChild(o),o.styleSheet?o.styleSheet.cssText=n:o.appendChild(e.createTextNode(n)),o.sheet}function sh(e,t,n=nh){let r;if(t)try{t.cssRules,r=t}catch(o){n(`[dom-snapshot] could not access cssRules for ${t.href} ${o}\ncreating temp style for access.`),r=ah(e)}else r=ah(e);return{corsFreeStyleSheet:r,cleanStyleSheet:function(){r!==t&&r.ownerNode.parentNode.removeChild(r.ownerNode)}}}const lh=300,ch=150;function uh(e){if(e.id)return`canvas#${e.id}`;const t="string"==typeof e.className?e.className.trim():"";return t?`canvas.${t.split(/\s+/).slice(0,3).join(".")}`:"canvas"}function dh(e){return e.width===lh&&e.height===ch&&!e.attributes.width&&!e.attributes.height}function hh(e,{log:t,compress:n,serialize:r}){const o=[];let i=0;return e.reduce((async(e,{url:a,element:s,cdtNode:l})=>{let c;try{c={description:uh(s),width:s.width,height:s.height,sizeNeverSet:dh(s),source:s.attributes["data-data-url"]?"data-data-url":"toBlob"}}catch(e){}const u=new Promise((async e=>{try{const t=s.attributes["data-data-url"];t?e(await async function(e){const t=await fetch(e);return await t.arrayBuffer()}(t.value)):s.toBlob((t=>t?e(t.arrayBuffer()):n()),"image/png")}catch(e){n(e)}function n(n){var r;t("resetting canvas node",n?n.message:"",s&&s.attributes&&(r=s,JSON.stringify([r.attributes].reduce(((e,t)=>Object.assign({[t.name]:t.value},e)),{})))),l.attributes.splice(l.attributes.findIndex((e=>"data-applitools-src"===e.name)),1),l.attributes.push({name:"data-applitools-tainted-canvas",value:"true"}),e(void 0)}}));return e.then((e=>u.then((s=>{if(s){const l=Qd({type:"image/png",value:s,compress:n,serialize:r}),u={...l,value:l.value,url:a};e.push(u);try{if(i++,c){const e=s.byteLength;t("[buildCanvasBlobs] canvas captured",`${c.description} backing=${c.width}x${c.height} bytes=${e} source=${c.source}${c.sizeNeverSet?" sizeNeverSet=true":""} url=${a}`),c.sizeNeverSet&&e<=2048&&o.push(`${c.description} (${e}B, source=${c.source})`)}}catch(e){}}return e}))))}),Promise.resolve([])).then((e=>({blobs:e,warnings:o.length>0?[`[buildCanvasBlobs] ${o.length} of ${i} captured canvases appear undrawn — width/height never set (spec default ${lh}x${ch}) and serialized to at most 2048 bytes: ${o.join(", ")}. If a map/chart library owns them, the snapshot likely ran before it initialised.`]:[]})))}const ph=new Set(["img/src","image/href","image/xlink:href"]),fh=/^\s*data:([^;,]*)(?:;[^,]*)?;base64,/i;const mh={css:!0},gh=/\.(woff2|woff|ttf|otf|eot)(?:[?#]|$)/i,yh={100:["thin","100"],200:["extralight","ultralight","200"],300:["light","300"],400:["regular","normal","400"],500:["medium","500"],600:["semibold","demibold","600"],700:["bold","700"],800:["extrabold","ultrabold","800"],900:["black","heavy","900"]},bh={};Object.keys(yh).forEach((e=>yh[e].forEach((e=>bh[e]=!0))));const _h=["italic","oblique"],vh={serif:!0,"sans-serif":!0,monospace:!0,cursive:!0,fantasy:!0,"system-ui":!0,"ui-serif":!0,"ui-sans-serif":!0,"ui-monospace":!0,"ui-rounded":!0,emoji:!0,math:!0,fangsong:!0,inherit:!0,initial:!0,revert:!0,unset:!0};function wh(e,t){const n=e.styleSheets;if(!n)return;const r=new Set,o=e=>{try{return e.cssRules||e.rules}catch(e){return}},i=e=>{if(e)for(let n=0;n<e.length;n++){const a=e[n];if(a)if(a.style&&"function"==typeof a.style.getPropertyValue&&t(a),a.styleSheet){if(r.has(a.styleSheet))continue;r.add(a.styleSheet),i(o(a.styleSheet))}else a.cssRules&&i(a.cssRules)}};for(let e=0;e<n.length;e++)r.has(n[e])||(r.add(n[e]),i(o(n[e])))}function kh(e){return 5===e.type||!0===(e.constructor&&"CSSFontFaceRule"===e.constructor.name)}function xh(e,t){const n=Lh(e.family),r=jh(n);if(0===r.length)return;const o=n.filter((e=>bh[e])),i=(yh[function(e){const t=String(e||"normal").toLowerCase().trim();return"normal"===t?"400":"bold"===t?"700":t}(e.weight)]||[]).concat(o),a=_h.some((t=>Lh(e.style).indexOf(t)>=0))||n.some((e=>_h.indexOf(e)>=0));let s,l=!1;for(const e of t){const t=Th(e);if(!Nh(r,jh(t)))continue;let n=0;const u=t.filter((e=>bh[e]));u.length>0&&(n+=u.some((e=>i.indexOf(e)>=0))?1:-1),o.length>0&&u.length>0&&(n+=(c=u,o.slice().sort().join(",")===c.slice().sort().join(",")?2:-2));const d=t.some((e=>_h.indexOf(e)>=0));(d||a)&&(n+=d===a?1:-1),!s||n>s.score?(s={url:e,score:n},l=!1):n===s.score&&(l=!0)}var c;return!s||l||s.score<0?void 0:s.url}function Sh(e,t,n){if(t&&t.childNodeIndexes)for(const r of t.childNodeIndexes)if(e[r]&&e[r].nodeName===n)return e[r]}function Oh(e,t,n){const r=null==n?"":String(n).trim();r&&"normal"!==r&&"auto"!==r&&!Ah(r)&&e.push(`${t}: ${r}`)}function Ah(e){return/[<};\r\n]/.test(e)}function Eh(e){return`"${e.replace(/^['"]|['"]$/g,"").replace(/\\/g,"\\\\").replace(/"/g,'\\"')}"`}function Ch(e,t,n,r){return[Ph(e),t.toLowerCase(),n.toLowerCase(),r].join("|")}function Ph(e){return String(e||"").trim().replace(/^['"]|['"]$/g,"").toLowerCase()}function Lh(e){return String(e||"").replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/([A-Z]+)([A-Z][a-z])/g,"$1 $2").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean)}function zh(e,t){return e===t||e.length>=3&&0===t.indexOf(e)}function Nh(e,t){if(0===e.length||0===t.length)return!1;const n=e.every((e=>t.some((t=>zh(e,t))))),r=t.every((t=>e.some((e=>zh(e,t)))));return n||r}function Th(e){const t=e.split("?")[0].split("#")[0];return Lh(function(e){try{return decodeURIComponent(e)}catch(t){return e}}(t.substring(t.lastIndexOf("/")+1).replace(gh,"")))}function jh(e){return e.filter((e=>!bh[e]&&_h.indexOf(e)<0&&!function(e){return/^[0-9]{4,}$/.test(e)||/^[0-9a-f]{6,}$/.test(e)&&/[0-9]/.test(e)}(e)))}function Ih(e){return gh.test(e)}function Rh(e,t){try{return new URL(e,t).href}catch(t){return e}}const Dh="__process_resource";function Mh(e){return e&&eh(e)}var Bh;null!==(Bh=n[S])&&void 0!==Bh||(n[S]={});const Wh=y((function({doc:n=e,showLogs:r,useSessionCache:o,dontFetchResources:i,fetchTimeout:a,fetchConcurrency:s,skipResources:l,skipRootHtmlResource:c,compressResources:u,serializeResources:d,removeReverseProxyURLPrefixes:h,skipDataUriExtraction:p,elements:f,skipCDTDedup:m}={}){
/* MARKER FOR TEST - DO NOT DELETE */
if(arguments[0]instanceof Document){n=arguments[0];const e=arguments[1];r=e.showLogs,o=e.useSessionCache,i=e.dontFetchResources,a=e.fetchTimeout,s=e.fetchConcurrency,l=e.skipResources,u=e.compressResources,d=e.serializeResources,h=e.removeReverseProxyURLPrefixes,m=e.skipCDTDedup,p=e.skipDataUriExtraction}const g=function(e,t=Date.now()){const n=[],r=[],o=e?(...e)=>console.warn("[dom-snapshot]",`[+${Date.now()-t}ms]`,...e):()=>{},i=e?(...e)=>console.error("[dom-snapshot]",`[+${Date.now()-t}ms]`,...e):()=>{};return{log:e?(...e)=>console.log("[dom-snapshot]",`[+${Date.now()-t}ms]`,...e):()=>{},warn:(e,...t)=>{if(void 0!==e){const r=t.length>0?`${e} ${t.join(" ")}`:String(e);n.push(r)}o(e,...t)},error:(e,...t)=>{if(void 0!==e){const n=t.length>0?`${e} ${t.join(" ")}`:String(e);r.push(n)}i(e,...t)},getWarnings:()=>n,getErrors:()=>r}}(!!r,Date.now());g.log("processPage start"),g.log(`skipResources length: ${l&&l.length}`);const y=o&&function({log:e,sessionStorage:n}){let r;try{const e=n||(void 0!==t?t.sessionStorage:void 0);if(e){const t=e.getItem(Dh);r=t?JSON.parse(t):{}}}catch(n){e("error creating session cache",n)}return{getItem:function(e){if(r)return r[e]},setItem:function(t,n){r&&(e("saving to in-memory sessionStorage, key:",t,"value:",n),r[t]=n)},keys:function(){return r?Object.keys(r):[]},persist:function(){if(r){const e=n||(void 0!==t?t.sessionStorage:void 0);e&&e.setItem(Dh,JSON.stringify(r))}}}}({log:g.log}),b={},_=function({styleSheetCache:e,CSSRule:n=t.CSSRule,removeReverseProxyURLPrefixes:r}){return function t(o){return cc(Array.from(o.cssRules||[]).reduce(((o,i)=>{const a={[n.IMPORT_RULE]:()=>{const t=i;return t.styleSheet&&(e[t.styleSheet.href]=t.styleSheet,t.styleSheet.href)?t.styleSheet.href:t.href},[n.FONT_FACE_RULE]:()=>$l(i.cssText,{removeReverseProxyURLPrefixes:r}),[n.SUPPORTS_RULE]:()=>t(i),[n.MEDIA_RULE]:()=>t(i),[n.STYLE_RULE]:()=>Vl(i.style)}[i.type],s=a&&a()||[];return(null==i?void 0:i.cssRules)&&s.push(...t(i)),o.concat(s)}),[])).filter((e=>"#"!==e[0]))}}({styleSheetCache:b,removeReverseProxyURLPrefixes:Boolean(null==h?void 0:h.length)}),w=function({styleSheetCache:e}){return function(t,n){const r=rh(n.map((e=>{try{return Array.from(e.styleSheets)}catch(e){return[]}})));return e[t]||r.find((e=>{const n=e.href&&th(e.href);return n&&function(e){const t=new URL(e);return t.username&&(t.username=""),t.password&&(t.password=""),t.href}(n)===t}))}}({styleSheetCache:b}),k=function(e){return function(t,n=!0){return cc(Array.from(t.querySelectorAll("style")).reduce(((r,o)=>{const i=n?Array.from(t.styleSheets).find((e=>e.ownerNode===o)):o.sheet;return i?r.concat(e(i)):r}),[]))}}(_),x=function(e){return function(t){return t.adoptedStyleSheets?cc(Array.from(t.adoptedStyleSheets).reduce(((t,n)=>t.concat(e(n))),[])):[]}}(_),S=function({parser:e,decoder:t,extractResourceUrlsFromStyleTags:n}){return function(r){const o=(t||new TextDecoder("utf-8")).decode(r),i=(e||new DOMParser).parseFromString(o,"image/svg+xml"),a=Array.from(i.querySelectorAll("img[srcset]")).map((e=>{const t=e.getAttribute("srcset");return t?t.split(", ").map((e=>e.trim().split(/\s+/)[0])):[]})).reduce(((e,t)=>e.concat(t)),[]),s=Array.from(i.querySelectorAll("img[src]")).map((e=>e.getAttribute("src"))).filter(Boolean),l=Array.from(i.querySelectorAll('image,use,link[rel="stylesheet"]')).map((e=>e.getAttribute("href")||e.getAttribute("xlink:href"))).filter(Boolean),c=Array.from(i.getElementsByTagName("object")).map((e=>e.getAttribute("data"))).filter(Boolean),u=n(i,!1),d=function(e){return rh(Array.from(e.querySelectorAll("*[style]")).map((e=>e.style.cssText)).map((e=>$l(e))).filter(Boolean))}(i);return a.concat(s).concat(l).concat(c).concat(u).concat(d).filter((e=>"#"!==e[0]))}}({extractResourceUrlsFromStyleTags:k}),O=function({fetch:e=ih(),AbortController:n=t.AbortController,timeout:r=1e4,mediaDownloadTimeout:o=3e4}={}){return function(t){return new Promise(((i,a)=>{const s=new n,l=()=>{const e=new Error("fetchUrl timeout reached");e.isTimeout=!0,a(e),s.abort()},c=setTimeout(l,r);return e(t,{cache:"force-cache",credentials:"same-origin",signal:s.signal}).then((e=>{if(clearTimeout(c),200===e.status){const n=e.headers.get("Content-Type"),r=!e.headers.get("Content-Length")&&["audio/","video/"].some((e=>n&&n.startsWith(e)))&&setTimeout(l,o);return e.arrayBuffer().then((e=>(r&&clearTimeout(r),{url:t,value:e,type:n})))}return{url:t,errorStatusCode:e.status}})).then(i).catch((e=>a(e)))}))}}({timeout:a}),C=function({fetchUrl:e,findStyleSheetByUrl:t,getCorsFreeStyleSheet:n,extractResourcesFromStyleSheet:r,extractResourcesFromSvg:o,sessionCache:i,cache:a={},compress:s,serialize:l,log:c=nh}){return function({url:u,documents:d,getResourceUrlsAndBlobs:h,forceCreateStyle:p=!1,skipResources:f}){if(!a[u])if(i&&i.getItem(u)){const e=function e(t){const n=i.getItem(t);return[t].concat(n?cc(rh(n.map(e))):[])}(u);c("doProcessResource from sessionStorage",u,"deps:",e.slice(1)),a[u]=Promise.resolve({resourceUrls:e})}else if(f&&f.indexOf(u)>-1||/https:\/\/fonts\.googleapis\.com/.test(u))c("not processing resource from skip list (or google font):",u),a[u]=Promise.resolve({resourceUrls:[u]});else{const g=Date.now();a[u]=function(a){c("fetching",a);const u=Date.now();return e(a).catch((e=>function(e){const t=e.message&&(e.message.includes("Failed to fetch")||e.message.includes("Network request failed")),n=e.name&&e.name.includes("TypeError");return t&&n}(e)?{probablyCORS:!0,url:a}:e.isTimeout?{isTimeout:!0,url:a}:(c(`error while fetching resource ${a} ${e?`message=${e.message} | name=${e.name}`:""}`,e),{errorStatusCode:599,url:a}))).then((({url:e,type:a,value:m,probablyCORS:g,errorStatusCode:y,isTimeout:b})=>{if(g)return c("not fetched due to CORS",`[${Date.now()-u}ms]`,e),i&&i.setItem(e,[]),{resourceUrls:[e]};if(y){const t={[e]:{errorStatusCode:y}};return i&&i.setItem(e,[]),{blobsObj:t}}if(b)return c("not fetched due to timeout, returning error status code 504 (Gateway timeout)"),i&&i.setItem(e,[]),{blobsObj:{[e]:{errorStatusCode:504}}};let _;if(c(`fetched [${Date.now()-u}ms] ${e} bytes: ${m.byteLength}`),/text\/css/.test(a)){const o=t(e,d);if(o||p){const{corsFreeStyleSheet:e,cleanStyleSheet:t}=n(m,o);_=r(e),t()}}else if(/image\/svg/.test(a))try{_=o(m),p=!!_}catch(e){c("could not parse svg content",e)}const w={[e]:Qd({type:a,value:m,compress:s,serialize:l})};if(_){const t=_.map((t=>v(t,e.replace(/^blob:/,"")))).map(th).filter(eh);return t.length&&(w[e].dependencies=t),i&&i.setItem(e,t),h({documents:d,urls:t,forceCreateStyle:p,skipResources:f}).then((({resourceUrls:e,blobsObj:t})=>({resourceUrls:e,blobsObj:Object.assign(t,w)})))}return i&&i.setItem(e,[]),{blobsObj:w}})).catch((e=>(c("error while processing resource",a,e,e?`message=${e.message} | name=${e.name}`:""),i&&m(),{})))}(u).then((e=>(c("doProcessResource",`[${Date.now()-g}ms]`,u),e)))}return a[u];function m(){c("clearing from sessionStorage:",u),i.keys().forEach((e=>{const t=i.getItem(e);i.setItem(e,t.filter((e=>e!==u)))})),c("cleared from sessionStorage:",u)}}}({fetchUrl:O,findStyleSheetByUrl:w,getCorsFreeStyleSheet:sh,extractResourcesFromStyleSheet:_,extractResourcesFromSvg:S,log:g.log,sessionCache:y,compress:u,serialize:d}),P=function({processResource:e,aggregateResourceUrlsAndBlobs:t,concurrency:n=100}){if(!Number.isInteger(n)||n<1)throw new TypeError(`concurrency must be an integer >= 1, got ${n}`);const r=hc(n);return function n({documents:o,urls:i,forceCreateStyle:a=!1,skipResources:s}){return Promise.all(i.map((t=>r((()=>e({url:t,documents:o,getResourceUrlsAndBlobs:n,forceCreateStyle:a,skipResources:s})))))).then((e=>t(e)))}}({processResource:C,aggregateResourceUrlsAndBlobs:uc,concurrency:s});return function e(t,n=t.location.href){const r=function(e){const t=e.querySelectorAll("base")[0]&&e.querySelectorAll("base")[0].href;if(t&&(n=t)&&!/^(about:blank|javascript:void|blob:)/.test(n))return E(t);var n}(t)||n,o=function(e){if(!(null==e?void 0:e.length))return;const t=(e=[...e].map((e=>[...e]))).map((e=>[e,"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,(e=>{const t=16*Math.random()|0;return("x"===e?t:3&t|8).toString(16)}))])),n=A.addElementIds(t).flat();let r=0;return t.map((([e])=>{if(0===e.length)return null;const t=n[r].reduce(((e,{selector:t,kind:n})=>{if(!t)return{type:"css",selector:"",error:"Internal error: selector is undefined"};if(!e)return t.error?t:{type:"css",selector:t};const r={type:"css",selector:t};return"shadow"===n?r.shadow=e:"frame"===n?r.frame=e:r.shadow=e,r}),void 0);return r+=e.length,t}))}(f),{cdt:a,docRoots:s,canvasElements:h,frames:b,inlineFrames:_,crossFrames:w,linkUrls:S,imageBlobs:O,videoBlobs:C}=nc(t,r,g,m);let L=[];try{L=function(e,t,n,r){const o=[],i=e.fonts;if(!e.defaultView||!i||"function"!=typeof i.forEach)return o;const a=(...e)=>{r&&r.log&&r.log(...e)},s=[];if(i.forEach((e=>{e&&"loaded"===e.status&&s.push(e)})),0===s.length)return o;const l=function(e,t){const n={resolvedFamilies:{},claimedUrls:{},intendedFamilies:{}};return wh(e,(e=>{if(!kh(e))return;const r=Ph(e.style.getPropertyValue("font-family"));if(!r)return;const o=String(e.style.getPropertyValue("src")||""),i=function(e){const t=/url\(\s*(['"]?)([^'")]+)\1\s*\)/.exec(e);return t?t[2].trim():void 0}(o);i||o.indexOf("data:")>=0?(n.resolvedFamilies[r]=!0,i&&(n.claimedUrls[Rh(i,t)]=!0)):n.intendedFamilies[r]=!0})),n}(e,n),c=s.filter((e=>!l.resolvedFamilies[Ph(e.family)]));if(0===c.length)return o;const u=function(e,t){const n=e.defaultView,r=[],o={},i=e=>{if("string"!=typeof e)return;const n=e.trim();if(!n||0===n.indexOf("blob:"))return;const i=Rh(n,t);o[i]||(o[i]=!0,r.push(n))},a=n&&n.performance;if(a&&"function"==typeof a.getEntriesByType){let e=[];try{e=a.getEntriesByType("resource")||[]}catch(t){e=[]}for(const t of e)t&&"string"==typeof t.name&&(Ih(t.name)||mh[String(t.initiatorType)])&&i(t.name)}let s=[];try{s=e.querySelectorAll('link[rel~="preload"][as="font"]')||[]}catch(e){s=[]}for(let e=0;e<s.length;e++){const t=s[e];i(t.href||t.getAttribute&&t.getAttribute("href"))}return r}(e,n);!function(e,t){wh(e,(e=>{if(kh(e))return;const n=e.style.getPropertyValue("font-family");n&&String(n).split(",").forEach((e=>{const n=Ph(e);n&&!vh[n]&&(t[n]=!0)}))}))}(e,l.intendedFamilies);const d={},h={},p=[],f=(e,t)=>{const r=function(e,t,n){const r=String(e.family||"").trim();if(!r||Ah(r))return;const o=String(e.style||"normal").trim(),i=String(e.weight||"normal").trim();if(Ah(o)||Ah(i))return;if(!t||function(e){return/[<}\\()'"\s]/.test(e)}(t))return;const a=[`font-family: ${Eh(r)}`,`font-style: ${o}`,`font-weight: ${i}`];return Oh(a,"font-stretch",e.stretch),Oh(a,"unicode-range",e.unicodeRange),Oh(a,"font-display",e.display),Oh(a,"font-feature-settings",e.featureSettings),a.push(`src: ${function(e){const t=function(e){const t=gh.exec(e);if(t)switch(t[1].toLowerCase()){case"woff2":return"woff2";case"woff":return"woff";case"ttf":return"truetype";case"otf":return"opentype";case"eot":return"embedded-opentype";default:return}}(e);return`url(${e})${t?` format('${t}')`:""}`}(t)}`),{cssText:`@font-face { ${a.join("; ")}; }`,url:t,signature:Ch(r,o,i,Rh(t,n))}}(e,t,n);r?(h[Rh(t,n)]=!0,d[r.signature]||(d[r.signature]=!0,p.push(r.cssText),o.push(r.url))):a("[synthesizeProgrammaticFonts] skipping font family",e.family,"— unsafe descriptors")},m=()=>u.filter((e=>!h[Rh(e,n)])),g=[];for(const e of c){const t=xh(e,m());t?f(e,t):g.push(e)}const y=m().filter((e=>!l.claimedUrls[Rh(e,n)]));return 1===g.length&&1===y.length&&l.intendedFamilies[Ph(g[0].family)]?f(g[0],y[0]):g.forEach((e=>a("[synthesizeProgrammaticFonts] no confident URL for font family",e.family))),p.length>0&&function(e,t){e.push({nodeType:3,nodeValue:t});const n=e.length-1;e.push({nodeType:1,nodeName:"STYLE",attributes:[{name:"data-desc",value:"applitools-programmatic-fonts"}],childNodeIndexes:[n]});const r=e.length-1,o=function(e){const t=e[0],n=Sh(e,t,"HTML");return n?Sh(e,n,"HEAD")||n:t}(e);o.childNodeIndexes||(o.childNodeIndexes=[]),o.childNodeIndexes.push(r)}(t,p.join("\n")),o}(t,a,r,g)}catch(e){g.log("[processPage] synthesizeProgrammaticFonts failed",e)}const z=rh(s.map((e=>k(e)))),N=rh(s.map((e=>x(e)))),T=(F=r,function(e){try{return E(v(e,F))}catch(e){}}),j=cc(Array.from(S).concat(Array.from(z)).concat(Array.from(N)).concat(L)).map((e=>e.trim())).reduce(((e,t)=>{e.push(t);const n=function(e){return e&&e.replace(/(\\[0-9a-fA-F]{1,6}\s?)/g,(e=>{const t=parseInt(e.substr(1).trim(),16);return t>1114111?e:String.fromCodePoint(t)}))||e}(t);return n!==t&&e.push(n),e}),[]).map(T).map(th).filter(Mh).filter((e=>!c||e!==th(n))),I=i?Promise.resolve({resourceUrls:j,blobsObj:{}}):P({documents:s,urls:j,skipResources:l}).then((e=>(y&&y.persist(),e))),R=p?[]:function(e,t,{compress:n,serialize:r}){var o,i,a;const s=new Map;for(const l of e)for(const c of null!==(o=l.attributes)&&void 0!==o?o:[]){if(!ph.has(`${null===(i=l.nodeName)||void 0===i?void 0:i.toLowerCase()}/${c.name}`))continue;const o=fh.exec(null!==(a=c.value)&&void 0!==a?a:"");if(!o)continue;const u=c.value.slice(o[0].length),d=v(`applitools-data-${Yl(u)}`,t);try{if(!s.has(d)){const e=Uint8Array.from(atob(u),(e=>e.charCodeAt(0))).buffer,t=Qd({type:o[1]||"application/octet-stream",value:e,compress:n,serialize:r});s.set(d,{...t,value:t.value,url:d})}}catch(e){continue}c.value=d}return[...s.values()]}(a,r,{compress:u,serialize:d}),D=hh(h,{log:g.log,compress:u,serialize:d}),M=I.then((e=>function(e,{doc:t,fetchedBlobs:n,log:r,compress:o,serialize:i,sessionCache:a}){if(!t.body||0===e.length)return Promise.resolve([]);const s=new Set(Object.keys(n)),l=e.filter((({url:e})=>!(s.has("blob:"+e)||a&&a.getItem("blob:"+e)))),c=t.createElement("canvas");c.style.display="none";const u=Ql(t.body);return u.appendChild(c),Promise.all(l.map((({element:e,url:t,cdtNode:n})=>{try{return c.width=e.naturalWidth,c.height=e.naturalHeight,c.getContext("2d").drawImage(Ql.unwrap(e),0,0),hh([{url:t,element:c,cdtNode:n}],{log:r,compress:o,serialize:i}).then((e=>e.blobs))}catch(e){}}))).then((e=>rh(e))).catch().finally((()=>{u.removeChild(c)}))}(O,{fetchedBlobs:e.blobsObj,doc:t,log:g.log,compress:u,serialize:d,sessionCache:y}))),B=I.then((e=>function(e,{doc:t,fetchedBlobs:n,compress:r,serialize:o,log:i,sessionCache:a}){if(!t.body)return Promise.resolve([]);const s=new Set(Object.keys(n)),l=e.filter((({url:e})=>!(s.has("blob:"+e)||a&&a.getItem("blob:"+e))));return Promise.all(l.map((({element:e,url:t,cdtNode:n,dropSrcIfUnrecorded:a})=>Promise.resolve().then((()=>function(e){const t=e.captureStream();return 0===t.getVideoTracks().length?Promise.resolve(void 0):new Promise((n=>{const r=["video/mp4;codecs=avc1,mp4a.40.2","video/mp4","video/webm"].find((e=>MediaRecorder.isTypeSupported(e))),o=new MediaRecorder(t,{mimeType:r}),i=[];o.addEventListener("dataavailable",(e=>i.push(e.data))),o.addEventListener("stop",(()=>{var t;e.pause(),n(new Blob(i,{type:null===(t=i[0])||void 0===t?void 0:t.type}))}),{once:!0}),e.play(),o.start(),setTimeout((()=>o.stop()),1e3)}))}(e))).catch((e=>{null==i||i(`[buildBlobVideos] failed to record ${t}`,e)})).then((e=>(null==e?void 0:e.size)?e.arrayBuffer().then((n=>{const i=Qd({type:e.type,value:n,compress:r,serialize:o});return i.url=t,i})):(a&&(n.attributes=n.attributes.filter((e=>"src"!==e.name))),[])))))).then((e=>rh(e)))}(C,{fetchedBlobs:e.blobsObj,doc:t,log:g.log,compress:u,serialize:d,sessionCache:y}))),W=b.map((({element:t,url:n})=>e(t.contentDocument,n))),J=_.map((({element:t,url:n})=>e(t.contentDocument,n)));var F;return Promise.all([I,D,M,B,...W,...J]).then((function(e){const{resourceUrls:t,blobsObj:i}=e[0],{blobs:s,warnings:l}=e[1],c=e[2],u=e[3],d=e.slice(4),h=Y("src"),p=Y("data-applitools-selector"),y=p?`[data-applitools-selector="${p}"]`:void 0,b=function(e){return Object.keys(e).map((t=>Object.assign({url:t.replace(/^blob:/,"")},e[t])))}(i).concat(s).concat(c).concat(u).concat(R),_=[...g.getWarnings(),...l],v=[];for(const e of b)599===e.errorStatusCode||504===e.errorStatusCode?(t.push(e.url),_.push(`${e.errorStatusCode}:${e.url}`)):v.push(e);m||function(e,t){!function(e){const t=new Map;function n(e){let n=t.get(e);return n||t.set(e,n=new sc),n}function r(t,r){const o=e[t];if(!function(e){var t;return"IFRAME"!==(null===(t=e.nodeName)||void 0===t?void 0:t.toUpperCase())}(o))return t;const i=n(r),a=i.get(o);return void 0===a?(i.add(o,t),t):(e[t]=void 0,a)}for(let t=1;t<e.length;t++){const n=e[t];if(!n)continue;const o=n.childNodeIndexes;if(o){const e=lc(n);for(let t=0;t<o.length;t++)o[t]=r(o[t],e)}}}(e);const n=function(e){const t=new Map;let n=0;for(let r=0;r<e.length;r++)e[r]?(e[r-n]=e[r],t.set(r,r-n)):n++;return e.length-=n,t}(e);!function(e,t,n){const r=e=>n.get(e);for(const t of e)t.childNodeIndexes&&(t.childNodeIndexes=t.childNodeIndexes.map(r)),void 0!==t.shadowRootIndex&&(t.shadowRootIndex=r(t.shadowRootIndex));for(const e of t)e.index=r(e.index)}(e,t,n)}(a,w);const k={cdt:a,url:n,srcAttr:h,resourceUrls:t.map((e=>e.replace(/^blob:/,""))),blobs:v,frames:d,crossFrames:w};void 0!==o&&(k.safeSelectors=o),void 0!==y&&(k.selector=y),r!==n&&(k.baseUri=r);try{f&&A.cleanupElementIds(f)}catch(e){_.push(e.message)}_.length>0&&(k.warnings=_);const x=g.getErrors();return x.length>0&&(k.errors=x),k}));function Y(e){return t.defaultView&&t.defaultView.frameElement&&t.defaultView.frameElement.getAttribute(e)}}(n).then((e=>(g.log("processPage end"),e.scriptVersion="4.18.7",e)))}),n[S],"domSnapshotResult");return function(e){try{return JSON.stringify(Wh(e)(e))}catch(e){return JSON.stringify({status:"ERROR",error:e.message})}}}()};let n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window,window)(...e);try{let r=window.__applitools_sandbox;r||(r=document.createElement("iframe"),r.setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);const o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);const a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;const s=r.contentWindow,l=s.__EYES__APPLITOOLS__=s.__EYES__APPLITOOLS__||{};l._stringify||(l._stringify=s.JSON.stringify.bind(s.JSON));const c=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};function u(e){if(s.Array.isArray(e)){const t=new s.Array(e.length);for(let n=0;n<e.length;n++)t[n]=u(e[n]);return t}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){const t=new s.Object;for(const n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=u(e[n]));return t}return e}c._stringify&&c._stringify!==JSON.stringify||(c._stringify=s.JSON.stringify.bind(s.JSON));const d=new s.Array(e.length);for(let h=0;h<e.length;h++)d[h]=u(e[h]);return a(document,window,s)(...d)}catch(p){try{return t(document,window,window)(...e)}catch(f){throw n?f:p}}};
//# sourceMappingURL=processPagePollCjs.js.map


/***/ }),

/***/ "./src/marker.js":
/*!***********************!*\
  !*** ./src/marker.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   makeMark: () => (/* binding */ makeMark),
/* harmony export */   makeUnmark: () => (/* binding */ makeUnmark)
/* harmony export */ });
/* harmony import */ var _applitools_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @applitools/utils */ "../utils/dist/browser.js");
/* harmony import */ var _applitools_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_applitools_utils__WEBPACK_IMPORTED_MODULE_0__);


const MARKER = 'applitools-element-mark'

function makeMark() {
  return function mark(value) {
    if (value instanceof HTMLElement) {
      const elementId = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.general.guid()
      for (let element = value; element; element = element.getRootNode().host) {
        const oldElementId = element.getAttribute(MARKER)
        const newElementId = oldElementId ? `${oldElementId} ${elementId}` : elementId
        element.setAttribute(MARKER, newElementId)
      }
      return {[MARKER]: `[${MARKER}~="${elementId}"]`}
    } else if (_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isArray(value)) {
      return value.map(mark)
    } else if (_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isObject(value)) {
      return Object.entries(value).reduce((obj, [key, value]) => Object.assign(obj, {[key]: mark(value)}), {})
    } else {
      return value
    }
  }
}

function makeUnmark({refer}) {
  return function unmark(value) {
    if (_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.has(value, MARKER)) {
      const selector = value[MARKER]
      let root = document
      let element = root.querySelector(selector)
      while (element.shadowRoot) {
        element.removeAttribute(MARKER)
        const nextElement = element.shadowRoot.querySelector(selector)
        if (!nextElement) break
        element = nextElement
      }
      const ref = refer.ref(element)
      return ref
    } else if (_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isArray(value)) {
      return value.map(unmark)
    } else if (_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isObject(value)) {
      return Object.entries(value).reduce((obj, [key, value]) => Object.assign(obj, {[key]: unmark(value)}), {})
    } else {
      return value
    }
  }
}


/***/ }),

/***/ "./src/messenger.js":
/*!**************************!*\
  !*** ./src/messenger.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   makeMessenger: () => (/* binding */ makeMessenger)
/* harmony export */ });
/* harmony import */ var _applitools_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @applitools/utils */ "../utils/dist/browser.js");
/* harmony import */ var _applitools_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_applitools_utils__WEBPACK_IMPORTED_MODULE_0__);


function makeMessenger({sendMessage, onMessage}) {
  const messengerId = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.general.guid()
  const listeners = new Map()

  onMessage(({name, key, from, payload}, ...rest) => {
    if (from === messengerId) return
    const fns = []

    const unnamedFns = listeners.get('*')
    if (unnamedFns) fns.push(...unnamedFns)

    const namedFns = listeners.get(name)
    if (namedFns) fns.push(...namedFns)

    if (key) {
      const keyedFns = listeners.get(`${name}/${key}`)
      if (keyedFns) fns.push(...keyedFns)
    }

    fns.forEach(fn => fn(payload, key ? {name, key} : name, ...rest))
  })

  return {
    emit,
    on,
    once,
    off,
    request,
    command,
  }

  function emit(type, payload, ...rest) {
    const message = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isString(type)
      ? {name: type, from: messengerId, payload}
      : {name: type.name, key: type.key, from: messengerId, payload}
    sendMessage(message, ...rest)
  }

  function on(type, fn) {
    const name = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isString(type) ? type : `${type.name}/${type.key}`
    let fns = listeners.get(name)
    if (!fns) {
      fns = new Set()
      listeners.set(name, fns)
    }
    fns.add(fn)
    return () => off(name, fn)
  }

  function once(type, fn) {
    const off = on(type, (...args) => (fn(...args), off()))
    return off
  }

  function off(type, fn) {
    const name = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isString(type) ? type : `${type.name}/${type.key}`
    if (!fn) return listeners.delete(name)
    const fns = listeners.get(name)
    if (!fns) return false
    const existed = fns.delete(fn)
    if (!fns.size) listeners.delete(name)
    return existed
  }

  function request(name, payload, ...rest) {
    return new Promise((resolve, reject) => {
      const key = _applitools_utils__WEBPACK_IMPORTED_MODULE_0__.general.guid()
      emit({name, key}, payload, ...rest)
      once({name, key}, response => {
        if (response.error) {
          const error = new Error(response.error.message)
          error.stack = response.error.stack
          reject(error)
        } else {
          resolve(response.result)
        }
      })
    })
  }

  function command(name, fn) {
    if (!fn) {
      fn = name
      name = '*'
    }
    return on(name, async (payload, type, ...rest) => {
      try {
        const result =
          name === '*'
            ? await fn(_applitools_utils__WEBPACK_IMPORTED_MODULE_0__.types.isString(type) ? type : type.name, payload, ...rest)
            : await fn(payload, ...rest)
        emit(type, {result}, ...rest)
      } catch (error) {
        emit(type, {error: {message: error.message, stack: error.stack}}, ...rest)
      }
    })
  }
}


/***/ }),

/***/ "../snippets/dist/index.js":
/*!*********************************!*\
  !*** ../snippets/dist/index.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

exports.translateTo=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return(n=function(r){var e=void 0===r?[]:r,n=e[0],o=e[1];n=n||t.documentElement;var i={value:"translate("+-o.x+"px, "+-o.y+"px)",important:!0};return function(t){var r=void 0===t?[]:t,e=r[0],n=r[1],o=Object.keys(n).sort();o.reduce((function(t,r){return t[r]={value:e.style.getPropertyValue(r),important:Boolean(e.style.getPropertyPriority(r))},t}),{});o.forEach((function(t){e.style.setProperty(t,"string"!=typeof n[t]&&n[t]?n[t].value:n[t],n[t]&&n[t].important?"important":"")}))}([n,{transform:i,"-webkit-transform":i}]),o})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var e=function t(r){if(c.Array.isArray(r)){for(var e=new c.Array(r.length),n=0;n<r.length;n++)e[n]=t(r[n]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new c.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(o[i]=t(r[i]));return o}return r},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var c=n.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var p=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};p._stringify&&p._stringify!==JSON.stringify||(p._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),l=0;l<arguments.length;l++)u[l]=e(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,c).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.translateTo.snippetName="translateTo"
exports.setElementStyleProperties=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return(n=function(t){var r=void 0===t?[]:t,e=r[0],n=r[1],o=Object.keys(n).sort(),i=o.reduce((function(t,r){return t[r]={value:e.style.getPropertyValue(r),important:Boolean(e.style.getPropertyPriority(r))},t}),{});return o.forEach((function(t){e.style.setProperty(t,"string"!=typeof n[t]&&n[t]?n[t].value:n[t],n[t]&&n[t].important?"important":"")})),i})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var e=function t(r){if(c.Array.isArray(r)){for(var e=new c.Array(r.length),n=0;n<r.length;n++)e[n]=t(r[n]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new c.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(o[i]=t(r[i]));return o}return r},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var c=n.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var p=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};p._stringify&&p._stringify!==JSON.stringify||(p._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),l=0;l<arguments.length;l++)u[l]=e(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,c).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.setElementStyleProperties.snippetName="setElementStyleProperties"
exports.setElementAttributes=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(r=function(t){var n=void 0===t?[]:t,e=n[0],r=n[1];return Object.keys(r).reduce((function(t,n){return t[n]=e.getAttribute(n),e.setAttribute(n,r[n]),t}),{})})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var e=function t(n){if(c.Array.isArray(n)){for(var e=new c.Array(n.length),r=0;r<n.length;r++)e[r]=t(n[r]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=r.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=e(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,c).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.setElementAttributes.snippetName="setElementAttributes"
exports.scrollTo=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,o){return n=function(t){var r=void 0===t?[]:t,o=r[0],e=r[1],n=Object.keys(e).sort(),i=n.reduce((function(t,r){return t[r]={value:o.style.getPropertyValue(r),important:Boolean(o.style.getPropertyPriority(r))},t}),{});return n.forEach((function(t){o.style.setProperty(t,"string"!=typeof e[t]&&e[t]?e[t].value:e[t],e[t]&&e[t].important?"important":"")})),i},(e=function(r){var o=void 0===r?[]:r,e=o[0],i=o[1];e=e||t.documentElement;var a=n([e,{"scroll-behavior":{value:"auto",important:!0}}]);return e.scrollTo?e.scrollTo(i.x,i.y):(e.scrollLeft=i.x,e.scrollTop=i.y),n([e,a]),{x:e.scrollLeft,y:e.scrollTop}})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e,n},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var o=function t(r){if(c.Array.isArray(r)){for(var o=new c.Array(r.length),e=0;e<r.length;e++)o[e]=t(r[e]);return o}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var n=new c.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(n[i]=t(r[i]));return n}return r},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var n=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+n+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+n];if(delete e.contentWindow["ctor-"+n],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var c=e.contentWindow,l=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};l._stringify||(l._stringify=c.JSON.stringify.bind(c.JSON));var d=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};d._stringify&&d._stringify!==JSON.stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),p=0;p<arguments.length;p++)u[p]=o(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,c).apply(void 0,u)}catch(o){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:o}}}}();
return s(arg)
}
exports.scrollTo.snippetName="scrollTo"
exports.reloadPage=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,o){return(e=function(){n.location.reload()})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var o=function t(n){if(d.Array.isArray(n)){for(var o=new d.Array(n.length),e=0;e<n.length;e++)o[e]=t(n[e]);return o}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var r=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(r[i]=t(n[i]));return r}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var r=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+r+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+r];if(delete e.contentWindow["ctor-"+r],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),l=0;l<arguments.length;l++)f[l]=o(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,d).apply(void 0,f)}catch(o){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:o}}}}();
return s(arg)
}
exports.reloadPage.snippetName="reloadPage"
exports.lazyLoad=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return function(){var e=function(t){var r=void 0===t?[]:t,e=r[0],o=r[1],n=Object.keys(o).sort(),i=n.reduce((function(t,r){return t[r]={value:e.style.getPropertyValue(r),important:Boolean(e.style.getPropertyPriority(r))},t}),{});return n.forEach((function(t){e.style.setProperty(t,"string"!=typeof o[t]&&o[t]?o[t].value:o[t],o[t]&&o[t].important?"important":"")})),i},o="__EYES__APPLITOOLS__",n="lazyLoadResult";r[o]=r[o]||{};var i=function(t){var e=(void 0===t?[]:t)[0];return e?{x:e.scrollLeft,y:e.scrollTop}:{x:r.scrollX||r.pageXOffset,y:r.scrollY||r.pageYOffset}},a=function(r){var o=void 0===r?[]:r,n=o[0],i=o[1];n=n||t.documentElement;var a=e([n,{"scroll-behavior":{value:"auto",important:!0}}]);return n.scrollTo?n.scrollTo(i.x,i.y):(n.scrollLeft=i.x,n.scrollTop=i.y),e([n,a]),{x:n.scrollLeft,y:n.scrollTop}};return function(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}((function(e){var l=void 0===e?[]:e,c=l[0],s=l[1],u=void 0===s?{}:s,d=u.scrollLength,f=u.waitingTime,p=u.maxAmountToScroll;try{if(r[o][n]){var y=r[o][n];return"WIP"!==y.status&&delete r[o][n],JSON.stringify(y)}var h=function(){try{var e=c&&"number"==typeof c.scrollHeight?c:t&&(t.scrollingElement||t.documentElement)||{};return{height:Number(e.scrollHeight)||0,client:Number(e.clientHeight)||void 0!==r&&Number(r.innerHeight)||0}}catch(e){return{height:0,client:0}}},v=function(){var t=h();t.height>S&&(S=t.height)};r[o][n]={status:"WIP"};var m=i(),g=[];g.push({maxAmountToScroll:p,scrollLength:d,waitingTime:f,startingScrollPositionX:m.x,startingScrollPositionY:m.y});var _=Date.now(),S=0,w=0,O="number"==typeof d&&d>0&&"number"==typeof p&&p>0?Math.ceil(p/d*1.5)+10:100;return function t(e){var i=void 0===e?{}:e,l=i.doneScrolling,s=i.previousScrollResult,u=void 0===s?{}:s,y=i.resumeY,x=i.attempts,b=i.stalls;x=x||0,b=b||0,setTimeout((function(){try{var e=x>=O;if(l||e){var i=a([c,m]),s=i.x,f=i.y;return g.push({x:s,y:f,msSinceStart:Date.now()-_,reason:e&&!l?"cappedAt":"stalled"===l?"stalled":"done",attempts:x,stalls:b,maxScrollTop:w,maxScrollHeight:S}),void(r[o][n]={status:"SUCCESS",value:g})}var P=a([c,{x:m.x,y:(void 0!==y?y:u.y)+d}]),E=P.x,L=P.y;g.push({x:E,y:L,msSinceStart:Date.now()-_}),L>w&&(w=L),v();var T,A=L===u.y,N=!1,Y=0;L>=p?N=!0:A&&(function(t){v();var r=h();return!r.height||!r.client||!(w>r.height)&&t+r.client>=r.height-2}(L)?N=!0:b>=3?(N="stalled",Y=b):(Y=b+1,T=Math.max(L,w))),t({doneScrolling:N,previousScrollResult:{x:E,y:L},resumeY:T,attempts:x+1,stalls:Y})}catch(t){r[o][n]={status:"ERROR",error:t}}}),f)}(),JSON.stringify(r[o][n])}catch(e){return r[o][n]={status:"ERROR",error:e},JSON.stringify(r[o][n])}}))}()},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(r){if(l.Array.isArray(r)){for(var e=new l.Array(r.length),o=0;o<r.length;o++)e[o]=t(r[o]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var n=new l.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(n[i]=t(r[i]));return n}return r},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var n=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+n+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+n];if(delete o.contentWindow["ctor-"+n],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var l=o.contentWindow,c=l.__EYES__APPLITOOLS__=l.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=l.JSON.stringify.bind(l.JSON));var s=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};s._stringify&&s._stringify!==JSON.stringify||(s._stringify=l.JSON.stringify.bind(l.JSON));for(var u=new l.Array(arguments.length),d=0;d<arguments.length;d++)u[d]=e(d<0||arguments.length<=d?void 0:arguments[d]);return a(document,window,l).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.lazyLoad.snippetName="lazyLoad"
exports.isStaleElement=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(o=function(e){var o=e&&e[0]||null;return!(o&&("isConnected"in n.Node.prototype?o.isConnected:t.documentElement.contains?t.documentElement.contains(o):o.ownerDocument.documentElement.contains(o)))})&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(n){if(c.Array.isArray(n)){for(var e=new c.Array(n.length),o=0;o<n.length;o++)e[o]=t(n[o]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var r=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(r[i]=t(n[i]));return r}return n},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var r=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+r+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+r];if(delete o.contentWindow["ctor-"+r],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=o.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));for(var _=new c.Array(arguments.length),l=0;l<arguments.length;l++)_[l]=e(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,c).apply(void 0,_)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.isStaleElement.snippetName="isStaleElement"
exports.isEqualElements=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(t){var n=void 0===t?[]:t;return n[0]===n[1]})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(n){if(d.Array.isArray(n)){for(var r=new d.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),p=0;p<arguments.length;p++)f[p]=r(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,d).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.isEqualElements.snippetName="isEqualElements"
exports.isElementScrollable=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,n){return(r=function(t){var n=(void 0===t?[]:t)[0],r=function(t){var n,r=void 0===t?[]:t,o=r[0],i=r[1],a=void 0===i?[]:i;try{n=e.getComputedStyle(o)}catch(t){return[]}return n&&"function"==typeof n.getPropertyValue?a.map((function(t){return n.getPropertyValue(t)})):[]}([n,["overflow-x","overflow-y","overflow"]]);return("scroll"===r[0]||"auto"===r[0]||"hidden"===r[2])&&n.scrollWidth>n.clientWidth||("scroll"===r[1]||"auto"===r[1]||"hidden"===r[2])&&n.scrollHeight>n.clientHeight})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var n=function t(e){if(d.Array.isArray(e)){for(var n=new d.Array(e.length),r=0;r<e.length;r++)n[r]=t(e[r]);return n}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new d.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=r.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=d.JSON.stringify.bind(d.JSON));for(var u=new d.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=n(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,d).apply(void 0,u)}catch(n){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:n}}}}();
return s(arg)
}
exports.isElementScrollable.snippetName="isElementScrollable"
exports.getViewport=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,n){return(i=function(){var n,i=0,o=0;return e.innerHeight?o=e.innerHeight:t.documentElement&&t.documentElement.clientHeight?o=t.documentElement.clientHeight:t.body&&t.body.clientHeight&&(o=t.body.clientHeight),e.innerWidth?i=e.innerWidth:t.documentElement&&t.documentElement.clientWidth?i=t.documentElement.clientWidth:t.body&&t.body.clientWidth&&(i=t.body.clientWidth),e.screen&&e.screen.orientation?n=e.screen.orientation.type.replace(/-primary$/,""):null!=e.orientation&&(0===e.orientation?n="portrait":180===e.orientation?n="portrait-secondary":90===e.orientation?n="landscape":-90===e.orientation&&(n="landscape-secondary")),{viewportSize:{width:i,height:o},pixelRatio:e.devicePixelRatio,viewportScale:e.visualViewport&&e.visualViewport.scale,orientation:n}})&&i.__esModule&&Object.prototype.hasOwnProperty.call(i,"default")?i.default:i;var i},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var n=function t(e){if(d.Array.isArray(e)){for(var n=new d.Array(e.length),i=0;i<e.length;i++)n[i]=t(e[i]);return n}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new d.Object;for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(o[r]=t(e[r]));return o}return e},i=window.__applitools_sandbox;i||((i=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),i.setAttribute("data-applitools-skip",""),document.head.appendChild(i),window.__applitools_sandbox=i);var o=Math.floor(4294967296*Math.random()),r=i.contentDocument.createElement("script");r.textContent="window['ctor-"+o+"'] = "+t.toString()+";",i.contentDocument.head.appendChild(r);var a=i.contentWindow["ctor-"+o];if(delete i.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=i.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=d.JSON.stringify.bind(d.JSON));for(var p=new d.Array(arguments.length),u=0;u<arguments.length;u++)p[u]=n(u<0||arguments.length<=u?void 0:arguments[u]);return a(document,window,d).apply(void 0,p)}catch(n){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:n}}}}();
return s(arg)
}
exports.getViewport.snippetName="getViewport"
exports.getUserAgent=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return a="userAgent",r[o="__EYES__APPLITOOLS__"]=r[o]||{},(n=function(){try{if(r[o][a]){var t=r[o][a];return"WIP"!==t.status&&delete r[o][a],JSON.stringify(t)}return r.navigator.userAgentData?(r[o][a]={status:"WIP"},r.navigator.userAgentData.getHighEntropyValues(["brands","platform","platformVersion","model"]).then((function(t){r[o][a]={status:"SUCCESS",value:{legacy:r.navigator.userAgent,brands:t.brands,mobile:t.mobile,platform:t.platform,platformVersion:t.platformVersion,model:t.model}}})).catch((function(t){r[o][a]={status:"ERROR",error:t.message}}))):r[o][a]={status:"SUCCESS",value:r.navigator.userAgent},JSON.stringify(r[o][a])}catch(t){return r[o][a]={status:"ERROR",error:t.message},JSON.stringify(r[o][a])}})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n,o,a},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(r){if(s.Array.isArray(r)){for(var e=new s.Array(r.length),n=0;n<r.length;n++)e[n]=t(r[n]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new s.Object;for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(o[a]=t(r[a]));return o}return r},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),a=n.contentDocument.createElement("script");a.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(a);var i=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof i)throw new Error("Sandbox failed to extract function");r=!1;var s=n.contentWindow,d=s.__EYES__APPLITOOLS__=s.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=s.JSON.stringify.bind(s.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=s.JSON.stringify.bind(s.JSON));for(var c=new s.Array(arguments.length),l=0;l<arguments.length;l++)c[l]=e(l<0||arguments.length<=l?void 0:arguments[l]);return i(document,window,s).apply(void 0,c)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.getUserAgent.snippetName="getUserAgent"
exports.getText=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(t){return t[0].innerText})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(n){if(d.Array.isArray(n)){for(var r=new d.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),p=0;p<arguments.length;p++)f[p]=r(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,d).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.getText.snippetName="getText"
exports.getShadowRoot=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(o=function(t){return(void 0===t?[]:t)[0].shadowRoot})&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(n){if(d.Array.isArray(n)){for(var r=new d.Array(n.length),o=0;o<n.length;o++)r[o]=t(n[o]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var e=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(e[i]=t(n[i]));return e}return n},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var e=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+e+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+e];if(delete o.contentWindow["ctor-"+e],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=o.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),p=0;p<arguments.length;p++)f[p]=r(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,d).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.getShadowRoot.snippetName="getShadowRoot"
exports.getElementXpath=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,n){return(e=function(t){var r=(void 0===t?[]:t)[0],n="",e=r.ownerDocument;if(!e)return n;for(var o=r;o!==e;){var i=Array.prototype.filter.call(o.parentNode.childNodes,(function(t){return t.tagName===o.tagName})).indexOf(o);n="/"+o.tagName+"["+(i+1)+"]"+n,o=o.parentNode}return n})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var n=function t(r){if(d.Array.isArray(r)){for(var n=new d.Array(r.length),e=0;e<r.length;e++)n[e]=t(r[e]);return n}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new d.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(o[i]=t(r[i]));return o}return r},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var f=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};f._stringify&&f._stringify!==JSON.stringify||(f._stringify=d.JSON.stringify.bind(d.JSON));for(var _=new d.Array(arguments.length),p=0;p<arguments.length;p++)_[p]=n(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,d).apply(void 0,_)}catch(n){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:n}}}}();
return s(arg)
}
exports.getElementXpath.snippetName="getElementXpath"
exports.getElementTranslateOffset=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return(n=function(r){var e=(void 0===r?[]:r)[0],n=function(t){var r=void 0===t?[]:t,e=r[0],n=r[1],o=void 0===n?[]:n,i=e.style;return i&&"function"==typeof i.getPropertyValue?o.reduce((function(t,r){return t[r]={value:i.getPropertyValue(r),important:Boolean(i.getPropertyPriority(r))},t}),{}):{}}([void 0===e?t.documentElement:e,["transform","-webkit-transform"]]),o=Object.keys(n).reduce((function(t,r){var e=n[r].value;if(e){var o=e.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(o){var i=o[1],a=void 0!==o[3]?o[3]:0;t.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else t.push({x:0,y:0})}return t}),[]);if(!o.every((function(t){return o[0].x===t.x||o[0].y===t.y})))throw new Error("Got different css positions!");return o[0]||{x:0,y:0}})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var e=function t(r){if(d.Array.isArray(r)){for(var e=new d.Array(r.length),n=0;n<r.length;n++)e[n]=t(r[n]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new d.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(o[i]=t(r[i]));return o}return r},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var d=n.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),s=0;s<arguments.length;s++)f[s]=e(s<0||arguments.length<=s?void 0:arguments[s]);return a(document,window,d).apply(void 0,f)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.getElementTranslateOffset.snippetName="getElementTranslateOffset"
exports.getElementStyleProperties=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return(n=function(t){var e=void 0===t?[]:t,r=e[0],n=e[1],o=void 0===n?[]:n,i=r.style;return i&&"function"==typeof i.getPropertyValue?o.reduce((function(t,e){return t[e]={value:i.getPropertyValue(e),important:Boolean(i.getPropertyPriority(e))},t}),{}):{}})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(e){if(d.Array.isArray(e)){for(var r=new d.Array(e.length),n=0;n<e.length;n++)r[n]=t(e[n]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new d.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=n.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=d.JSON.stringify.bind(d.JSON));for(var p=new d.Array(arguments.length),_=0;_<arguments.length;_++)p[_]=r(_<0||arguments.length<=_?void 0:arguments[_]);return a(document,window,d).apply(void 0,p)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.getElementStyleProperties.snippetName="getElementStyleProperties"
exports.getElementScrollOffset=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(t){var r=(void 0===t?[]:t)[0];return r?{x:r.scrollLeft,y:r.scrollTop}:{x:n.scrollX||n.pageXOffset,y:n.scrollY||n.pageYOffset}})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var r=function t(n){if(c.Array.isArray(n)){for(var r=new c.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=e.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=c.JSON.stringify.bind(c.JSON));for(var f=new c.Array(arguments.length),_=0;_<arguments.length;_++)f[_]=r(_<0||arguments.length<=_?void 0:arguments[_]);return a(document,window,c).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.getElementScrollOffset.snippetName="getElementScrollOffset"
exports.getElementRect=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return function(){var r=function(e){var r=(void 0===e?[]:e)[0],n=void 0===r?t.documentElement:r,o=function(t){var e=void 0===t?[]:t,r=e[0],n=e[1],o=void 0===n?[]:n,i=r.style;return i&&"function"==typeof i.getPropertyValue?o.reduce((function(t,e){return t[e]={value:i.getPropertyValue(e),important:Boolean(i.getPropertyPriority(e))},t}),{}):{}}([n,["transform","-webkit-transform"]]),i=Object.keys(o).reduce((function(t,e){var r=o[e].value;if(r){var n=r.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(n){var i=n[1],a=void 0!==n[3]?n[3]:0;t.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else t.push({x:0,y:0})}return t}),[]);if(!i.every((function(t){return i[0].x===t.x||i[0].y===t.y})))throw new Error("Got different css positions!");return i[0]||{x:0,y:0}},n=function(t){var n=(void 0===t?[]:t)[0],o=function(t){var r=(void 0===t?[]:t)[0];return r?{x:r.scrollLeft,y:r.scrollTop}:{x:e.scrollX||e.pageXOffset,y:e.scrollY||e.pageYOffset}}([n]),i=r([n]);return{x:o.x+i.x,y:o.y+i.y}};return function(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}((function(r){var o=void 0===r?[]:r,i=o[0],a=o[1],u=void 0!==a&&a,d="string"==typeof i.tagName?i.tagName.toLowerCase():"";if(i===t.documentElement||d===function(){var e="HTML",r=t.scrollingElement;return r&&(e=r.tagName),e.toLowerCase()}())return{x:0,y:0,width:i.clientWidth,height:i.clientHeight};var f="function"==typeof i.getBoundingClientRect?i.getBoundingClientRect():{left:0,top:0,width:0,height:0},c={x:f.left,y:f.top,width:f.width,height:f.height};if(u){var l;try{l=e.getComputedStyle(i)}catch(r){l=null}l&&"function"==typeof l.getPropertyValue&&(c.x+=parseInt(l.getPropertyValue("border-left-width")),c.y+=parseInt(l.getPropertyValue("border-top-width"))),c.width=i.clientWidth,c.height=i.clientHeight}var y=function(r){for(var n,o=(void 0===r?[]:r)[0];o.offsetParent&&o.offsetParent!==t.body&&o.offsetParent!==t.documentElement;)o=o.offsetParent;try{n=e.getComputedStyle(o)}catch(r){return null}return n&&"function"==typeof n.getPropertyValue&&"fixed"===n.getPropertyValue("position")?o:null}([i]);if(y){if(y!==i){var p=n([y]);c.x+=p.x,c.y+=p.y}}else{var s=n();c.x+=s.x,c.y+=s.y}return c}))}()},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var r=function t(e){if(u.Array.isArray(e)){for(var r=new u.Array(e.length),n=0;n<e.length;n++)r[n]=t(e[n]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new u.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var u=n.contentWindow,d=u.__EYES__APPLITOOLS__=u.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=u.JSON.stringify.bind(u.JSON));var f=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};f._stringify&&f._stringify!==JSON.stringify||(f._stringify=u.JSON.stringify.bind(u.JSON));for(var c=new u.Array(arguments.length),l=0;l<arguments.length;l++)c[l]=r(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,u).apply(void 0,c)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.getElementRect.snippetName="getElementRect"
exports.getElementProperties=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(t){var n=void 0===t?[]:t,r=n[0],e=n[1];return(void 0===e?[]:e).reduce((function(t,n){return t[n]=r[n],t}),{})})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(n){if(d.Array.isArray(n)){for(var r=new d.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var u=new d.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=r(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,d).apply(void 0,u)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.getElementProperties.snippetName="getElementProperties"
exports.getElementInnerOffset=function(arg){
var s=function(){"use strict";return function(){var t=function(t,r,e){return o=function(r){var e=(void 0===r?[]:r)[0],n=void 0===e?t.documentElement:e,o=function(t){var r=void 0===t?[]:t,e=r[0],n=r[1],o=void 0===n?[]:n,i=e.style;return i&&"function"==typeof i.getPropertyValue?o.reduce((function(t,r){return t[r]={value:i.getPropertyValue(r),important:Boolean(i.getPropertyPriority(r))},t}),{}):{}}([n,["transform","-webkit-transform"]]),i=Object.keys(o).reduce((function(t,r){var e=o[r].value;if(e){var n=e.match(/^translate\s*\(\s*(\-?[\d, \.]+)px\s*(,\s*(-?[\d, \.]+)px)?\s*\)/);if(n){var i=n[1],a=void 0!==n[3]?n[3]:0;t.push({x:Math.round(-parseFloat(i)),y:Math.round(-parseFloat(a))})}else t.push({x:0,y:0})}return t}),[]);if(!i.every((function(t){return i[0].x===t.x||i[0].y===t.y})))throw new Error("Got different css positions!");return i[0]||{x:0,y:0}},(n=function(t){var e=(void 0===t?[]:t)[0],n=function(t){var e=(void 0===t?[]:t)[0];return e?{x:e.scrollLeft,y:e.scrollTop}:{x:r.scrollX||r.pageXOffset,y:r.scrollY||r.pageYOffset}}([e]),i=o([e]);return{x:n.x+i.x,y:n.y+i.y}})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n,o},r=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(r){if(c.Array.isArray(r)){for(var e=new c.Array(r.length),n=0;n<r.length;n++)e[n]=t(r[n]);return e}if(r&&"object"==typeof r&&Object.getPrototypeOf(r)===Object.prototype){var o=new c.Object;for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(o[i]=t(r[i]));return o}return r},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");r=!1;var c=n.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));for(var f=new c.Array(arguments.length),s=0;s<arguments.length;s++)f[s]=e(s<0||arguments.length<=s?void 0:arguments[s]);return a(document,window,c).apply(void 0,f)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw r?t:e}}}}();
return s(arg)
}
exports.getElementInnerOffset.snippetName="getElementInnerOffset"
exports.getElementFixedAncestor=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,n){return(r=function(n){for(var r,o=(void 0===n?[]:n)[0];o.offsetParent&&o.offsetParent!==t.body&&o.offsetParent!==t.documentElement;)o=o.offsetParent;try{r=e.getComputedStyle(o)}catch(n){return null}return r&&"function"==typeof r.getPropertyValue&&"fixed"===r.getPropertyValue("position")?o:null})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var n=function t(e){if(d.Array.isArray(e)){for(var n=new d.Array(e.length),r=0;r<e.length;r++)n[r]=t(e[r]);return n}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new d.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=r.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var f=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};f._stringify&&f._stringify!==JSON.stringify||(f._stringify=d.JSON.stringify.bind(d.JSON));for(var u=new d.Array(arguments.length),l=0;l<arguments.length;l++)u[l]=n(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,d).apply(void 0,u)}catch(n){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:n}}}}();
return s(arg)
}
exports.getElementFixedAncestor.snippetName="getElementFixedAncestor"
exports.getElementContentSize=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return o=function(t){var e=void 0===t?[]:t,r=e[0],n=e[1],o=Object.keys(n).sort(),i=o.reduce((function(t,e){return t[e]={value:r.style.getPropertyValue(e),important:Boolean(r.style.getPropertyPriority(e))},t}),{});return o.forEach((function(t){r.style.setProperty(t,"string"!=typeof n[t]&&n[t]?n[t].value:n[t],n[t]&&n[t].important?"important":"")})),i},(n=function(e){var r,n=(void 0===e?[]:e)[0],i="string"==typeof n.tagName?n.tagName.toLowerCase():"";n!==t.documentElement&&i!==function(){var e="HTML",r=t.scrollingElement;return r&&(e=r.tagName),e.toLowerCase()}()||(r=o([n,{transform:"none"}]));var a={width:n.scrollWidth,height:n.scrollHeight};return r&&o([n,r]),a})&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n;var n,o},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var r=function t(e){if(c.Array.isArray(e)){for(var r=new c.Array(e.length),n=0;n<e.length;n++)r[n]=t(e[n]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new c.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var c=n.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=r(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,c).apply(void 0,u)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.getElementContentSize.snippetName="getElementContentSize"
exports.getElementComputedStyleProperties=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(r=function(t){var e,r=void 0===t?[]:t,o=r[0],i=r[1],a=void 0===i?[]:i;try{e=n.getComputedStyle(o)}catch(t){return[]}return e&&"function"==typeof e.getPropertyValue?a.map((function(t){return e.getPropertyValue(t)})):[]})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(n){if(d.Array.isArray(n)){for(var e=new d.Array(n.length),r=0;r<n.length;r++)e[r]=t(n[r]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=r.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=d.JSON.stringify.bind(d.JSON));for(var p=new d.Array(arguments.length),_=0;_<arguments.length;_++)p[_]=e(_<0||arguments.length<=_?void 0:arguments[_]);return a(document,window,d).apply(void 0,p)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.getElementComputedStyleProperties.snippetName="getElementComputedStyleProperties"
exports.getDocumentSize=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,n){return(o=function(){var e=t.documentElement.scrollWidth,n=t.documentElement.scrollHeight,o=t.documentElement.clientHeight,r=t.body.scrollWidth,i=t.body.scrollHeight,a=t.body.clientHeight;return{width:Math.max(e,r),height:Math.max(o,n,a,i)}})&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var n=function t(e){if(d.Array.isArray(e)){for(var n=new d.Array(e.length),o=0;o<e.length;o++)n[o]=t(e[o]);return n}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var r=new d.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(r[i]=t(e[i]));return r}return e},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var r=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+r+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+r];if(delete o.contentWindow["ctor-"+r],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=o.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=d.JSON.stringify.bind(d.JSON));for(var _=new d.Array(arguments.length),u=0;u<arguments.length;u++)_[u]=n(u<0||arguments.length<=u?void 0:arguments[u]);return a(document,window,d).apply(void 0,_)}catch(n){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:n}}}}();
return s(arg)
}
exports.getDocumentSize.snippetName="getDocumentSize"
exports.getDocumentScrollingElement=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(r=function(){var n="HTML",e=t.scrollingElement;return e&&(n=e.tagName),n.toLowerCase()})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var e=function t(n){if(c.Array.isArray(n)){for(var e=new c.Array(n.length),r=0;r<n.length;r++)e[r]=t(n[r]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=r.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=c.JSON.stringify.bind(c.JSON));for(var l=new c.Array(arguments.length),f=0;f<arguments.length;f++)l[f]=e(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,c).apply(void 0,l)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.getDocumentScrollingElement.snippetName="getDocumentScrollingElement"
exports.getContextInfo=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(r=function(){var e,r,o;try{e=n.top.document===n.document||"root-context"===n.parent.document["applitools-marker"]}catch(t){e=!1}try{r=!n.parent.document===n.document}catch(e){r=!0}if(!r)try{o=function(t){var n=(void 0===t?[]:t)[0],e="",r=n.ownerDocument;if(!r)return e;for(var o=n;o!==r;){var i=Array.prototype.filter.call(o.parentNode.childNodes,(function(t){return t.tagName===o.tagName})).indexOf(o);e="/"+o.tagName+"["+(i+1)+"]"+e,o=o.parentNode}return e}([n.frameElement])}catch(e){o=null}return[t.documentElement,o,e,r]})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(n){if(c.Array.isArray(n)){for(var e=new c.Array(n.length),r=0;r<n.length;r++)e[r]=t(n[r]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=r.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));for(var p=new c.Array(arguments.length),f=0;f<arguments.length;f++)p[f]=e(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,c).apply(void 0,p)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.getContextInfo.snippetName="getContextInfo"
exports.getChildFramesInfo=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(){return function n(r){var e=[];(r=r||t).querySelectorAll("frame, iframe").forEach((function(t){return e.push([t,!t.contentDocument,t.src])}));var o=Array.prototype.filter.call(r.querySelectorAll("*"),(function(t){return t.shadowRoot})).map((function(t){return n(t.shadowRoot)}));return e.concat.apply(e,o)}()})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var r=function t(n){if(c.Array.isArray(n)){for(var r=new c.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=e.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=c.JSON.stringify.bind(c.JSON));for(var f=new c.Array(arguments.length),l=0;l<arguments.length;l++)f[l]=r(l<0||arguments.length<=l?void 0:arguments[l]);return a(document,window,c).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.getChildFramesInfo.snippetName="getChildFramesInfo"
exports.focusElement=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,r){return(e=function(t){var n=(void 0===t?[]:t)[0];n&&n.focus()})&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e;var e},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t().apply(void 0,arguments);try{var r=function t(n){if(d.Array.isArray(n)){for(var r=new d.Array(n.length),e=0;e<n.length;e++)r[e]=t(n[e]);return r}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},e=window.__applitools_sandbox;e||((e=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),e.setAttribute("data-applitools-skip",""),document.head.appendChild(e),window.__applitools_sandbox=e);var o=Math.floor(4294967296*Math.random()),i=e.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",e.contentDocument.head.appendChild(i);var a=e.contentWindow["ctor-"+o];if(delete e.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=e.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var f=new d.Array(arguments.length),p=0;p<arguments.length;p++)f[p]=r(p<0||arguments.length<=p?void 0:arguments[p]);return a(document,window,d).apply(void 0,f)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:r}}}}();
return s(arg)
}
exports.focusElement.snippetName="focusElement"
exports.cleanupPageMarker=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return n=function(t){var e=void 0===t?[]:t,r=e[0],o=e[1],n=Object.keys(o).sort(),i=n.reduce((function(t,e){return t[e]={value:r.style.getPropertyValue(e),important:Boolean(r.style.getPropertyPriority(e))},t}),{});return n.forEach((function(t){r.style.setProperty(t,"string"!=typeof o[t]&&o[t]?o[t].value:o[t],o[t]&&o[t].important?"important":"")})),i},(o=function(){var e=t.querySelector("[data-applitools-marker]");e&&t.body.removeChild(e);var r=t.documentElement.getAttribute("data-applitools-original-transforms"),o=t.body.getAttribute("data-applitools-original-transforms");r&&n([t.documentElement,JSON.parse(r)]),o&&n([t.body,JSON.parse(o)])})&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o,n},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var r=function t(e){if(d.Array.isArray(e)){for(var r=new d.Array(e.length),o=0;o<e.length;o++)r[o]=t(e[o]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var n=new d.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(n[i]=t(e[i]));return n}return e},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var n=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+n+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+n];if(delete o.contentWindow["ctor-"+n],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var d=o.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=d.JSON.stringify.bind(d.JSON));for(var p=new d.Array(arguments.length),u=0;u<arguments.length;u++)p[u]=r(u<0||arguments.length<=u?void 0:arguments[u]);return a(document,window,d).apply(void 0,p)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.cleanupPageMarker.snippetName="cleanupPageMarker"
exports.cleanupElementIds=function(arg){
var s=function(){"use strict";return function(){var t=function(t,o,e){return(r=function(o){(o=o&&o[0])&&"function"==typeof o.forEach&&o.forEach((function(o){o.removeAttribute("data-applitools-selector");var e=o;if(e.getRootNode)try{for(;e;){var r=e.getRootNode();if(!r||r===t)break;(e=r.constructor&&"ShadowRoot"===r.constructor.name?r.host:r.defaultView?r.defaultView.frameElement:null)&&e.removeAttribute("data-applitools-selector")}}catch(o){}}))})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},o=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var e=function t(o){if(c.Array.isArray(o)){for(var e=new c.Array(o.length),r=0;r<o.length;r++)e[r]=t(o[r]);return e}if(o&&"object"==typeof o&&Object.getPrototypeOf(o)===Object.prototype){var n=new c.Object;for(var i in o)Object.prototype.hasOwnProperty.call(o,i)&&(n[i]=t(o[i]));return n}return o},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var n=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+n+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+n];if(delete r.contentWindow["ctor-"+n],"function"!=typeof a)throw new Error("Sandbox failed to extract function");o=!1;var c=r.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var f=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};f._stringify&&f._stringify!==JSON.stringify||(f._stringify=c.JSON.stringify.bind(c.JSON));for(var l=new c.Array(arguments.length),u=0;u<arguments.length;u++)l[u]=e(u<0||arguments.length<=u?void 0:arguments[u]);return a(document,window,c).apply(void 0,l)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw o?t:e}}}}();
return s(arg)
}
exports.cleanupElementIds.snippetName="cleanupElementIds"
exports.blurElement=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(r=function(n){var e=(void 0===n?[]:n)[0]||t.activeElement;return e&&e.blur(),e})&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r;var r},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var e=function t(n){if(d.Array.isArray(n)){for(var e=new d.Array(n.length),r=0;r<n.length;r++)e[r]=t(n[r]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var o=new d.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(o[i]=t(n[i]));return o}return n},r=window.__applitools_sandbox;r||((r=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),r.setAttribute("data-applitools-skip",""),document.head.appendChild(r),window.__applitools_sandbox=r);var o=Math.floor(4294967296*Math.random()),i=r.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",r.contentDocument.head.appendChild(i);var a=r.contentWindow["ctor-"+o];if(delete r.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var d=r.contentWindow,c=d.__EYES__APPLITOOLS__=d.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=d.JSON.stringify.bind(d.JSON));var _=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};_._stringify&&_._stringify!==JSON.stringify||(_._stringify=d.JSON.stringify.bind(d.JSON));for(var u=new d.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=e(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,d).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.blurElement.snippetName="blurElement"
exports.addPageMarker=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return n=function(t){var e=void 0===t?[]:t,r=e[0],o=e[1],n=Object.keys(o).sort(),i=n.reduce((function(t,e){return t[e]={value:r.style.getPropertyValue(e),important:Boolean(r.style.getPropertyPriority(e))},t}),{});return n.forEach((function(t){r.style.setProperty(t,"string"!=typeof o[t]&&o[t]?o[t].value:o[t],o[t]&&o[t].important?"important":"")})),i},o=function(e){var r=e[0],o=r.mask,i=r.size,a=void 0===i?1:i,p={1:"rgb(0, 0, 0)",0:"rgb(255, 255, 255)"},s=a,l=t.createElement("div");l.setAttribute("data-applitools-marker",""),l.style.setProperty("position","fixed","important"),l.style.setProperty("top","0","important"),l.style.setProperty("left","0","important"),l.style.setProperty("box-sizing","content-box","important"),l.style.setProperty("padding",s+"px","important"),l.style.setProperty("background","rgb(128, 128, 128)","important"),l.style.setProperty("z-index","2147483647","important");for(var d,y=0;y<o.length;y+=d){for(d=1;o[y]===o[y+d];)++d;var c=o[y],f=t.createElement("div");f.style.setProperty("display","block","important"),f.style.setProperty("float","left","important"),f.style.setProperty("width",d*a+"px","important"),f.style.setProperty("height",a+"px","important"),f.style.setProperty("background",p[c],"important"),l.appendChild(f)}var u={value:"none",important:!0},m=n([t.documentElement,{transform:u,"-webkit-transform":u}]),_=n([t.body,{transform:u,"-webkit-transform":u}]);return t.documentElement.setAttribute("data-applitools-original-transforms",JSON.stringify(m)),t.body.setAttribute("data-applitools-original-transforms",JSON.stringify(_)),t.body.appendChild(l),{mask:o,size:a,offset:s}},o&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o,n},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document).apply(void 0,arguments);try{var r=function t(e){if(p.Array.isArray(e)){for(var r=new p.Array(e.length),o=0;o<e.length;o++)r[o]=t(e[o]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var n=new p.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(n[i]=t(e[i]));return n}return e},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var n=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+n+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+n];if(delete o.contentWindow["ctor-"+n],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var p=o.contentWindow,s=p.__EYES__APPLITOOLS__=p.__EYES__APPLITOOLS__||{};s._stringify||(s._stringify=p.JSON.stringify.bind(p.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=p.JSON.stringify.bind(p.JSON));for(var d=new p.Array(arguments.length),y=0;y<arguments.length;y++)d[y]=r(y<0||arguments.length<=y?void 0:arguments[y]);return a(document,window,p).apply(void 0,d)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.addPageMarker.snippetName="addPageMarker"
exports.addFallbackSelectorIfNeeded=function(arg){
var s=function(){"use strict";return function(){var t=function(t,n,e){return(o=function(e){if(!e.hasAttribute("data-applitools-fallback-selector")){if(function(e){var o=e&&e[0]||null;return!(o&&("isConnected"in n.Node.prototype?o.isConnected:t.documentElement.contains?t.documentElement.contains(o):o.ownerDocument.documentElement.contains(o)))}([e]))throw new Error("The element is not connected to the DOM: "+function(t){var n=t.attributes,e=t.tagName,o=t.children.length,r=[].slice.call(n).map((function(t){return t.name+'="'+t.value+'"'})).join(" ");return"<"+e+" "+r+(o?">":"/>")}(e));e.setAttribute("data-applitools-fallback-selector",function(t){for(var n=[];t&&t.nodeType===Node.ELEMENT_NODE;)try{var e,o=t.tagName.toLowerCase(),r=[].slice.call((null==(e=t.parentNode)?void 0:e.children)||[]).indexOf(t);r>-1&&(o+=":nth-child("+(r+1)+")"),n.unshift(o),t=t.parentNode}catch(t){break}return n.length?n.join(" > "):"html"}(e))}})&&o.__esModule&&Object.prototype.hasOwnProperty.call(o,"default")?o.default:o;var o},n=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var e=function t(n){if(c.Array.isArray(n)){for(var e=new c.Array(n.length),o=0;o<n.length;o++)e[o]=t(n[o]);return e}if(n&&"object"==typeof n&&Object.getPrototypeOf(n)===Object.prototype){var r=new c.Object;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(r[i]=t(n[i]));return r}return n},o=window.__applitools_sandbox;o||((o=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),o.setAttribute("data-applitools-skip",""),document.head.appendChild(o),window.__applitools_sandbox=o);var r=Math.floor(4294967296*Math.random()),i=o.contentDocument.createElement("script");i.textContent="window['ctor-"+r+"'] = "+t.toString()+";",o.contentDocument.head.appendChild(i);var a=o.contentWindow["ctor-"+r];if(delete o.contentWindow["ctor-"+r],"function"!=typeof a)throw new Error("Sandbox failed to extract function");n=!1;var c=o.contentWindow,d=c.__EYES__APPLITOOLS__=c.__EYES__APPLITOOLS__||{};d._stringify||(d._stringify=c.JSON.stringify.bind(c.JSON));var l=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};l._stringify&&l._stringify!==JSON.stringify||(l._stringify=c.JSON.stringify.bind(c.JSON));for(var u=new c.Array(arguments.length),f=0;f<arguments.length;f++)u[f]=e(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,c).apply(void 0,u)}catch(e){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw n?t:e}}}}();
return s(arg)
}
exports.addFallbackSelectorIfNeeded.snippetName="addFallbackSelectorIfNeeded"
exports.addElementIds=function(arg){
var s=function(){"use strict";return function(){var t=function(t,e,r){return function(){var r=function(r){var n=r&&r[0]||null;return!(n&&("isConnected"in e.Node.prototype?n.isConnected:t.documentElement.contains?t.documentElement.contains(n):n.ownerDocument.documentElement.contains(n)))},n=r,o=function(t){if(!t.hasAttribute("data-applitools-fallback-selector")){if(n([t]))throw new Error("The element is not connected to the DOM: "+function(t){var e=t.attributes,r=t.tagName,n=t.children.length,o=[].slice.call(e).map((function(t){return t.name+'="'+t.value+'"'})).join(" ");return"<"+r+" "+o+(n?">":"/>")}(t));t.setAttribute("data-applitools-fallback-selector",function(t){for(var e=[];t&&t.nodeType===Node.ELEMENT_NODE;)try{var r,n=t.tagName.toLowerCase(),o=[].slice.call((null==(r=t.parentNode)?void 0:r.children)||[]).indexOf(t);o>-1&&(n+=":nth-child("+(o+1)+")"),e.unshift(n),t=t.parentNode}catch(t){break}return e.length?e.join(" > "):"html"}(t))}},i=r;function a(e,r){if(i([e])){var n=function(t){return null!=t&&t.getAttribute?t.getAttribute("data-applitools-fallback-selector"):{error:"invalid element: "+JSON.stringify(t)}}(e);if(!n)return{error:"Failed to recover from stale element"};if(n.error)return n;var l=t.querySelectorAll(n);if(!l||1!==l.length)return{error:"Failed to recover from stale element - selector found: "+n};var c=l[0];return c.setAttribute("data-applitools-selector",r),c.setAttribute("data-applitools-recovered",!0),a(c,r)}o(e);var u=e.getAttribute("data-applitools-selector"),d=u?u+" "+r:r;return e.setAttribute("data-applitools-selector",d),'[data-applitools-selector~="'+r+'"]'}return function(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}((function(e){return e.map((function(e){var r=e[0],n=e[1];return r.map((function(e){var r=function(e){for(var r=[{element:e,kind:"root"}],n=new Set([e]),o=e;o;){var i,a=o.getRootNode&&o.getRootNode();if(!a)break;if(a===t)break;if(a.constructor&&"ShadowRoot"===a.constructor.name?(o=a.host,i="shadow"):(o=a.defaultView?a.defaultView.frameElement:null,i="frame"),o){if(n.has(o))break;n.add(o),r.push({element:o,kind:i})}}return r}(e);return r.map((function(t){return{selector:a(t.element,n),kind:t.kind}}))}))}))}))}()},e=!0;if("undefined"!=typeof chrome&&chrome.runtime&&chrome.runtime.id)return t(document,window).apply(void 0,arguments);try{var r=function t(e){if(l.Array.isArray(e)){for(var r=new l.Array(e.length),n=0;n<e.length;n++)r[n]=t(e[n]);return r}if(e&&"object"==typeof e&&Object.getPrototypeOf(e)===Object.prototype){var o=new l.Object;for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(o[i]=t(e[i]));return o}return e},n=window.__applitools_sandbox;n||((n=document.createElement("iframe")).setAttribute("data-applitools-sandbox",""),n.setAttribute("data-applitools-skip",""),document.head.appendChild(n),window.__applitools_sandbox=n);var o=Math.floor(4294967296*Math.random()),i=n.contentDocument.createElement("script");i.textContent="window['ctor-"+o+"'] = "+t.toString()+";",n.contentDocument.head.appendChild(i);var a=n.contentWindow["ctor-"+o];if(delete n.contentWindow["ctor-"+o],"function"!=typeof a)throw new Error("Sandbox failed to extract function");e=!1;var l=n.contentWindow,c=l.__EYES__APPLITOOLS__=l.__EYES__APPLITOOLS__||{};c._stringify||(c._stringify=l.JSON.stringify.bind(l.JSON));var u=window.__EYES__APPLITOOLS__=window.__EYES__APPLITOOLS__||{};u._stringify&&u._stringify!==JSON.stringify||(u._stringify=l.JSON.stringify.bind(l.JSON));for(var d=new l.Array(arguments.length),f=0;f<arguments.length;f++)d[f]=r(f<0||arguments.length<=f?void 0:arguments[f]);return a(document,window,l).apply(void 0,d)}catch(r){try{return t(document,window,window).apply(void 0,arguments)}catch(t){throw e?t:r}}}}();
return s(arg)
}
exports.addElementIds.snippetName="addElementIds"

/***/ }),

/***/ "../spec-driver-browser-extension/dist/index.js":
/*!******************************************************!*\
  !*** ../spec-driver-browser-extension/dist/index.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const spec = __importStar(__webpack_require__(/*! ./spec-driver */ "../spec-driver-browser-extension/dist/spec-driver.js"));
__exportStar(__webpack_require__(/*! ./refer */ "../spec-driver-browser-extension/dist/refer.js"), exports);
__exportStar(__webpack_require__(/*! ./page-dispatch */ "../spec-driver-browser-extension/dist/page-dispatch.js"), exports);
__exportStar(__webpack_require__(/*! ./spec-driver */ "../spec-driver-browser-extension/dist/spec-driver.js"), exports);
exports["default"] = spec;


/***/ }),

/***/ "../spec-driver-browser-extension/dist/page-dispatch.js":
/*!**************************************************************!*\
  !*** ../spec-driver-browser-extension/dist/page-dispatch.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

// Page-world handlers the content script installs on `window.applitools`: resolve a snippet/poll by its
// stable id and run it in the page that owns `refer`. See OVERVIEW.md for the dispatch rationale.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeRunPoll = exports.makeRunSnippet = void 0;
// Returns an envelope instead of throwing: MV3 nulls in-page throws, losing the error signal.
function makeRunSnippet({ snippetById, refer }) {
    return function runSnippet(id, arg) {
        const fn = snippetById.get(id);
        if (!fn)
            return { status: 'error', error: { name: 'SnippetNotFound', message: String(id) } };
        try {
            // Re-ref node returns too: the result is structured-cloned back, which skips Node.toJSON.
            // Snippets are contractually SYNCHRONOUS: every @applitools/snippets export returns a value
            // synchronously. `fn` is called and its return re-ref'd without awaiting, so a Promise-returning
            // snippet would be ref'd as `{}` and drop its value. Any future async snippet must change this seam.
            return { status: 'success', value: refer.ref(fn(refer.deref(arg))) };
        }
        catch (err) {
            return { status: 'error', error: { name: err && err.name, message: err && err.message, stack: err && err.stack } };
        }
    };
}
exports.makeRunSnippet = makeRunSnippet;
// A poll returns its own JSON-string envelope, so pass it back verbatim; catch throws into that shape.
function makeRunPoll({ pollById, refer }) {
    return function runPoll(id, arg) {
        const fn = pollById.get(id);
        if (!fn)
            return JSON.stringify({ status: 'ERROR', error: 'poll fn not found: ' + id });
        try {
            return fn(refer.deref(arg));
        }
        catch (err) {
            return JSON.stringify({ status: 'ERROR', error: err && err.message });
        }
    };
}
exports.makeRunPoll = makeRunPoll;


/***/ }),

/***/ "../spec-driver-browser-extension/dist/refer.js":
/*!******************************************************!*\
  !*** ../spec-driver-browser-extension/dist/refer.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeRefer = void 0;
const utils = __importStar(__webpack_require__(/*! @applitools/utils */ "../utils/dist/browser.js"));
const REF_ID = 'applitools-ref-id';
function makeRefer({ check = (_arg) => true, validate = (_arg) => void 0, } = {}) {
    const store = new Map();
    const shorthands = new Map();
    return { isRef, get, ref, deref };
    function isRef(ref) {
        return utils.types.has(ref, REF_ID);
    }
    function get(key) {
        return shorthands.get(key);
    }
    function ref(value, key) {
        if (check(value)) {
            const refId = utils.general.guid();
            store.set(refId, value);
            const ref = { [REF_ID]: refId };
            if (key)
                shorthands.set(key, ref);
            return ref;
        }
        else if (utils.types.isArray(value)) {
            return value.map(ref);
        }
        else if (utils.types.isObject(value)) {
            return Object.entries(value).reduce((obj, [key, value]) => Object.assign(obj, { [key]: ref(value) }), {});
        }
        else {
            return value;
        }
    }
    function deref(ref) {
        if (isRef(ref)) {
            const value = store.get(ref[REF_ID]);
            validate(value);
            return value;
        }
        else if (utils.types.isArray(ref)) {
            return ref.map(deref);
        }
        else if (utils.types.isObject(ref)) {
            return Object.entries(ref).reduce((obj, [key, ref]) => Object.assign(obj, { [key]: deref(ref) }), {});
        }
        else {
            return ref;
        }
    }
}
exports.makeRefer = makeRefer;


/***/ }),

/***/ "../spec-driver-browser-extension/dist/spec-driver.js":
/*!************************************************************!*\
  !*** ../spec-driver-browser-extension/dist/spec-driver.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getUrl = exports.getTitle = exports.takeScreenshot = exports.getCookies = exports.setWindowSize = exports.getWindowSize = exports.getDriverInfo = exports.childContext = exports.parentContext = exports.mainContext = exports.findElements = exports.findElement = exports.executeBrowserCommands = exports.executeScript = exports.extractContext = exports.toSelector = exports.isStaleElementError = exports.isSelector = exports.isElement = exports.isContext = exports.isDriver = void 0;
const webextension_polyfill_1 = __importDefault(__webpack_require__(/*! webextension-polyfill */ "../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));
const utils = __importStar(__webpack_require__(/*! @applitools/utils */ "../utils/dist/browser.js"));
function isDriver(driver) {
    return utils.types.has(driver, ['windowId', 'tabId']);
}
exports.isDriver = isDriver;
function isContext(context) {
    return utils.types.has(context, ['windowId', 'tabId', 'frameId']);
}
exports.isContext = isContext;
function isElement(element) {
    return utils.types.has(element, 'applitools-ref-id');
}
exports.isElement = isElement;
function isSelector(selector) {
    return utils.types.has(selector, ['type', 'selector']);
}
exports.isSelector = isSelector;
function isStaleElementError(error) {
    if (!error)
        return false;
    error = error.originalError || error;
    return error instanceof Error && error.message === 'StaleElementReferenceError';
}
exports.isStaleElementError = isStaleElementError;
function toSelector(selector) {
    if (utils.types.isString(selector)) {
        return { type: 'css', selector: selector };
    }
    else if (utils.types.has(selector, 'selector')) {
        if (!utils.types.isString(selector.selector))
            return selector.selector;
        return {
            type: utils.types.has(selector, 'type') ? selector.type : 'css',
            selector: selector.selector,
        };
    }
    return selector;
}
exports.toSelector = toSelector;
function extractContext(driver) {
    return { ...driver, frameId: 0 };
}
exports.extractContext = extractContext;
// Re-throw an executeScript-level injection failure, preserving the original stack.
function throwInjectionError(error) {
    const err = new Error(error.message);
    err.stack = error.stack;
    throw err;
}
async function executeScript(context, script, arg) {
    touchFrame(context.tabId, context.frameId);
    // Dispatch a stamped snippet by id through the page registry: executeScript structured-clones args
    // (so the content-script deref reviver never fires), and the page returns a {status, value|error}
    // envelope because MV3 nulls in-page throws.
    const snippetName = typeof script === 'function' ? script.snippetName : undefined;
    if (snippetName) {
        const [{ result, error }] = await webextension_polyfill_1.default.scripting.executeScript({
            target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
            func: (id, arg) => window.applitools.runSnippet(id, arg),
            args: [snippetName, arg !== null && arg !== void 0 ? arg : null],
        });
        if (error)
            throwInjectionError(error);
        if (result && result.status === 'error') {
            // Rebuild the error so isStaleElementError can match on `.message`.
            const err = new Error(result.error.message);
            err.name = result.error.name;
            err.stack = result.error.stack;
            throw err;
        }
        if (!result) {
            // A falsy result is MV3 nulling an in-page throw (e.g. the registry isn't installed yet), never a
            // real return — those arrive in a truthy success envelope. Make it recoverable so withRefresh retries.
            throw new Error('StaleElementReferenceError');
        }
        if (result.status === 'success')
            return result.value;
        throw new Error(`runSnippet returned a malformed envelope: ${JSON.stringify(result)}`);
    }
    // Same dispatch for dom-snapshot polls, but the poll already returns its own JSON-string envelope, so
    // pass it back verbatim — no {status, value} wrapping.
    const pollName = typeof script === 'function' ? script.pollName : undefined;
    if (pollName) {
        const [{ result, error }] = await webextension_polyfill_1.default.scripting.executeScript({
            target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
            func: (id, arg) => window.applitools.runPoll(id, arg),
            args: [pollName, arg !== null && arg !== void 0 ? arg : null],
        });
        if (error)
            throwInjectionError(error);
        if (!result) {
            // A falsy result is MV3 nulling an in-page throw (e.g. the registry isn't installed yet), never a
            // real return — runPoll always yields a truthy JSON-string envelope. Make it recoverable so withRefresh retries.
            throw new Error('StaleElementReferenceError');
        }
        return result;
    }
    const [{ result, error }] = await webextension_polyfill_1.default.scripting.executeScript({
        target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
        func: script,
        args: [arg !== null && arg !== void 0 ? arg : null],
    });
    if (error)
        throwInjectionError(error);
    return result;
}
exports.executeScript = executeScript;
async function executeBrowserCommands(_driver, commands, logger) {
    for (const currentCommand of commands) {
        if (currentCommand.command === 'Page.addScriptToEvaluateOnNewDocument') {
            const script = currentCommand.params.source;
            webextension_polyfill_1.default.tabs.onUpdated.addListener((tabId, changeInfo, _tab) => {
                if (changeInfo.status === 'loading') {
                    webextension_polyfill_1.default.scripting.executeScript({
                        target: { tabId: tabId },
                        func: eval(script),
                    });
                }
            });
            logger === null || logger === void 0 ? void 0 : logger.debug('executeBrowserCommands');
        }
        else {
            logger === null || logger === void 0 ? void 0 : logger.debug(`Unsupported Browser command: ${currentCommand.command}`);
        }
        // Add more command handling as needed
    }
}
exports.executeBrowserCommands = executeBrowserCommands;
async function findElement(context, selector, parent) {
    const [{ result }] = await webextension_polyfill_1.default.scripting.executeScript({
        target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
        /* eslint-disable no-undef */
        func: (selector, parent) => {
            if (selector.type === 'css') {
                const root = parent ? window.refer.deref(parent) : document;
                return window.refer.ref(root.querySelector(selector.selector));
            }
            else if (selector.type === 'xpath') {
                return window.refer.ref(document.evaluate(selector.selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE).singleNodeValue);
            }
        },
        /* eslint-enable no-undef */
        args: [selector, parent || null],
    });
    return result;
}
exports.findElement = findElement;
async function findElements(context, selector, parent) {
    const [{ result }] = await webextension_polyfill_1.default.scripting.executeScript({
        target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
        /* eslint-disable no-undef */
        func: (selector, parent) => {
            if (selector.type === 'css') {
                const root = parent ? window.refer.deref(parent) : document;
                return Array.from(root.querySelectorAll(selector.selector), window.refer.ref);
            }
            else if (selector.type === 'xpath') {
                const iterator = document.evaluate(selector.selector, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE);
                const elements = [];
                for (let element = iterator.iterateNext(); element !== null; element = iterator.iterateNext()) {
                    elements.push(window.refer.ref(element));
                }
                return elements;
            }
        },
        /* eslint-enable no-undef */
        args: [selector, parent || null],
    });
    return result;
}
exports.findElements = findElements;
async function mainContext(context) {
    return { ...context, frameId: 0 };
}
exports.mainContext = mainContext;
async function parentContext(context) {
    const frames = await webextension_polyfill_1.default.webNavigation.getAllFrames({ tabId: context.tabId });
    const frame = frames.find(frame => frame.frameId === context.frameId);
    return { ...context, frameId: frame.parentFrameId };
}
exports.parentContext = parentContext;
async function childContext(context, element) {
    const childFrameId = await new Promise(async (resolve, reject) => {
        const key = utils.general.guid();
        webextension_polyfill_1.default.runtime.onMessage.addListener(handler);
        function handler(data, sender) {
            if (data.key === key) {
                resolve(sender.frameId);
                webextension_polyfill_1.default.runtime.onMessage.removeListener(handler);
            }
        }
        await webextension_polyfill_1.default.scripting.executeScript({
            target: { tabId: context.tabId, frameIds: [context.frameId || 0] },
            func: (element, key) => {
                window.refer.deref(element).contentWindow.postMessage({ key, isApplitools: true }, '*'); // eslint-disable-line no-undef
            },
            args: [element, key],
        });
        setTimeout(() => reject(new Error('No such frame')), 5000);
    });
    return { ...context, frameId: childFrameId };
}
exports.childContext = childContext;
async function getDriverInfo() {
    return { features: { canExecuteOnlyFunctionScripts: true } };
}
exports.getDriverInfo = getDriverInfo;
async function getWindowSize(driver) {
    const [{ result }] = await webextension_polyfill_1.default.scripting.executeScript({
        target: { tabId: driver.tabId, frameIds: [0] },
        func: () => ({ width: window.outerWidth, height: window.outerHeight }),
    });
    return result;
}
exports.getWindowSize = getWindowSize;
async function setWindowSize(driver, size) {
    await webextension_polyfill_1.default.windows.update(driver.windowId, {
        state: 'normal',
        left: 0,
        top: 0,
        width: size.width,
        height: size.height,
    });
}
exports.setWindowSize = setWindowSize;
async function getCookies(_driver) {
    const cookies = await webextension_polyfill_1.default.cookies.getAll({});
    return cookies.map(cookie => {
        const copy = {
            ...cookie,
            expiry: cookie.expirationDate,
            sameSite: cookie.sameSite === 'no_restriction'
                ? 'None'
                : `${cookie.sameSite[0].toUpperCase()}${cookie.sameSite.slice(1)}`,
        };
        delete copy.expirationDate;
        delete copy.hostOnly;
        delete copy.session;
        delete copy.storeId;
        return copy;
    });
}
exports.getCookies = getCookies;
const PAINT_TIMEOUT_MS = 1000;
// Chrome allows at most 2 captureVisibleTab calls per second (MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND).
const MIN_CAPTURE_INTERVAL_MS = 500;
// Frames where the driver ran a script since the last capture of the tab. A scroll always runs as
// a script in the frame it scrolls, so these are the frames that can have a pending paint.
const touchedFrames = new Map();
let forgetClosedTabs = false;
function touchFrame(tabId, frameId) {
    if (!forgetClosedTabs) {
        webextension_polyfill_1.default.tabs.onRemoved.addListener(closedTabId => touchedFrames.delete(closedTabId));
        forgetClosedTabs = true;
    }
    let frames = touchedFrames.get(tabId);
    if (!frames)
        touchedFrames.set(tabId, (frames = new Set()));
    frames.add(frameId || 0);
}
// captureVisibleTab returns the last frame the compositor produced. After a scroll or a tab switch
// that frame can still show the old state. So the top frame and every touched frame read their
// scroll position and layout, which applies a pending scroll, and then wait for two animation
// frames. This makes a stale frame less likely, but the browser does not promise it. Other frames
// are not waited for: a hidden or offscreen cross-origin frame runs no animation frames and would
// always hit the timeout. A frame that is gone or does not allow injection is skipped. The
// timeout inside the page does not help when the injection itself does not return, so the whole
// wait also stops after PAINT_TIMEOUT_MS + 500 ms.
async function waitForPaint(driver) {
    var _a;
    const frameIds = new Set([0, ...((_a = touchedFrames.get(driver.tabId)) !== null && _a !== void 0 ? _a : [])]);
    touchedFrames.delete(driver.tabId);
    let stop = () => { };
    const timeout = new Promise(resolve => (stop = resolve));
    const timer = setTimeout(() => stop(), PAINT_TIMEOUT_MS + 500);
    const waits = Promise.allSettled(Array.from(frameIds, frameId => webextension_polyfill_1.default.scripting.executeScript({
        target: { tabId: driver.tabId, frameIds: [frameId] },
        func: (timeout) => new Promise(resolve => {
            var _a;
            const scrollingElement = (_a = document.scrollingElement) !== null && _a !== void 0 ? _a : document.documentElement;
            void scrollingElement.scrollTop;
            void scrollingElement.getBoundingClientRect();
            const timer = setTimeout(resolve, timeout);
            requestAnimationFrame(() => requestAnimationFrame(() => {
                clearTimeout(timer);
                resolve();
            }));
        }),
        args: [PAINT_TIMEOUT_MS],
    })));
    await Promise.race([waits, timeout]);
    clearTimeout(timer);
}
// Captures run one at a time, also across tabs, because the limit is not per tab. A capture
// waits only for what is left of MIN_CAPTURE_INTERVAL_MS since the previous one.
let lastCaptureAt = 0;
let captureQueue = Promise.resolve();
async function takeScreenshot(driver) {
    const capture = captureQueue.then(async () => {
        const [activeTab] = await webextension_polyfill_1.default.tabs.query({ windowId: driver.windowId, active: true });
        await webextension_polyfill_1.default.tabs.update(driver.tabId, { active: true });
        const gate = utils.general.sleep(Math.max(0, lastCaptureAt + MIN_CAPTURE_INTERVAL_MS - Date.now()));
        await Promise.all([waitForPaint(driver), gate]);
        try {
            return await webextension_polyfill_1.default.tabs.captureVisibleTab(driver.windowId, { format: 'png' });
        }
        finally {
            lastCaptureAt = Date.now();
            await webextension_polyfill_1.default.tabs.update(activeTab.id, { active: true });
        }
    });
    captureQueue = capture.catch(() => undefined);
    const url = await capture;
    return url.replace(/^data:image\/png;base64,/, '');
}
exports.takeScreenshot = takeScreenshot;
async function getTitle(driver) {
    const { title } = await webextension_polyfill_1.default.tabs.get(driver.tabId);
    return title || '';
}
exports.getTitle = getTitle;
async function getUrl(driver) {
    const { url } = await webextension_polyfill_1.default.tabs.get(driver.tabId);
    return url || '';
}
exports.getUrl = getUrl;


/***/ }),

/***/ "../utils/dist/browser-process.js":
/*!****************************************!*\
  !*** ../utils/dist/browser-process.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sampleProcessTreeMemory = exports.sh = exports.executeProcess = exports.executeAndControlProcess = exports.execute = void 0;
const executionOutput = {
    stdout: '',
    stderr: 'process execution is not supported in browser environment',
    code: 1,
};
async function execute(command, options) {
    console.log('execute', { command, options });
    return executionOutput;
}
exports.execute = execute;
async function executeAndControlProcess(command, args = [], options) {
    console.log('executeAndControlProcess', { command, args, options });
    return {
        subProcess: undefined,
        exitPromise: Promise.resolve(executionOutput),
    };
}
exports.executeAndControlProcess = executeAndControlProcess;
async function executeProcess(command, args = [], options) {
    console.log('executeProcess', { command, args, options });
    return executionOutput;
}
exports.executeProcess = executeProcess;
async function sh(command, options) {
    console.log('sh', { command, options });
    return executionOutput;
}
exports.sh = sh;
// A browser cannot read OS process trees — always resolves "unknown".
// eslint-disable-next-line @typescript-eslint/no-unused-vars
async function sampleProcessTreeMemory(_rootPid, _options = {}) {
    return null;
}
exports.sampleProcessTreeMemory = sampleProcessTreeMemory;


/***/ }),

/***/ "../utils/dist/browser.js":
/*!********************************!*\
  !*** ../utils/dist/browser.js ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.process = exports.streams = exports.math = exports.queues = exports.promises = exports.geometry = exports.general = exports.guard = exports.types = void 0;
__exportStar(__webpack_require__(/*! ./utility-types */ "../utils/dist/utility-types.js"), exports);
exports.types = __importStar(__webpack_require__(/*! ./types */ "../utils/dist/types.js"));
exports.guard = __importStar(__webpack_require__(/*! ./guard */ "../utils/dist/guard.js"));
exports.general = __importStar(__webpack_require__(/*! ./general */ "../utils/dist/general.js"));
exports.geometry = __importStar(__webpack_require__(/*! ./geometry */ "../utils/dist/geometry.js"));
exports.promises = __importStar(__webpack_require__(/*! ./promises */ "../utils/dist/promises.js"));
exports.queues = __importStar(__webpack_require__(/*! ./queues */ "../utils/dist/queues.js"));
exports.math = __importStar(__webpack_require__(/*! ./math */ "../utils/dist/math.js"));
exports.streams = __importStar(__webpack_require__(/*! ./streams */ "../utils/dist/streams.js"));
exports.process = __importStar(__webpack_require__(/*! ./browser-process */ "../utils/dist/browser-process.js"));


/***/ }),

/***/ "../utils/dist/general.js":
/*!********************************!*\
  !*** ../utils/dist/general.js ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.zip = exports.dedupAndMap = exports.deepEqual = exports.pluralize = exports.extend = exports.wrap = exports.batchify = exports.clearCachify = exports.cachify = exports.absolutizeUrl = exports.removeUndefinedProps = exports.toUriEncoding = exports.toUnAnchoredUri = exports.toString = exports.toJSON = exports.sleep = exports.jwtDecode = exports.shortid = exports.guid = exports.getEnvCaseInsensitive = exports.getEnvValue = void 0;
const buffer_1 = __webpack_require__(/*! buffer */ "../../node_modules/buffer/index.js");
const types = __importStar(__webpack_require__(/*! ./types */ "../utils/dist/types.js"));
const uuid_1 = __webpack_require__(/*! ./uuid */ "../utils/dist/uuid.js");
function getEnvValue(name, type) {
    if (!process)
        return undefined;
    const value = process.env[`APPLITOOLS_${name}`];
    if (value === undefined || value === 'null')
        return undefined;
    if (type === 'boolean')
        return ['true', true, '1', 1].includes(value);
    if (type === 'number')
        return Number(value);
    return value;
}
exports.getEnvValue = getEnvValue;
/**
 * Retrieves the value of an environment variable in a case-insensitive manner.
 *
 * Traversing in order upper case, lower case and mixed case
 *
 * @param {string} key - The name of the environment variable to lookup.
 * @return {string | undefined} The value of the environment variable if found, or undefined if not found.
 */
function getEnvCaseInsensitive(key) {
    const upperKey = key.toUpperCase();
    if (process.env[upperKey]) {
        return process.env[upperKey];
    }
    const lowerKey = key.toLowerCase();
    if (process.env[lowerKey]) {
        return process.env[lowerKey];
    }
    // mixed case traversal
    const foundKey = Object.keys(process.env).find(k => k.toLowerCase() === key.toLowerCase());
    return foundKey ? process.env[foundKey] : undefined;
}
exports.getEnvCaseInsensitive = getEnvCaseInsensitive;
function guid() {
    return (0, uuid_1.uuid)();
}
exports.guid = guid;
function shortid() {
    return 'xxx'.replace(/[x]/g, () => {
        const r = (Math.random() * 36) | 0;
        return r.toString(36);
    });
}
exports.shortid = shortid;
function jwtDecode(token) {
    let payloadSeg = token.split('.')[1];
    payloadSeg += new Array(5 - (payloadSeg.length % 4)).join('=');
    payloadSeg = payloadSeg.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(buffer_1.Buffer.from(payloadSeg, 'base64').toString());
}
exports.jwtDecode = jwtDecode;
function sleep(ms) {
    if (types.isNumber(ms)) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
exports.sleep = sleep;
function toJSON(object, props) {
    if (!types.isObject(object))
        return object;
    if (types.isArray(object)) {
        return object.map(value => (value && types.isFunction(value.toJSON) ? value.toJSON() : toJSON(value)));
    }
    const original = props ? Object.values(props) : Object.keys(object);
    const keys = !props || types.isArray(props) ? original : Object.keys(props);
    return keys.reduce((plain, key, index) => {
        const value = object[original[index]];
        plain[key] = value && types.isFunction(value.toJSON) ? value.toJSON() : toJSON(value);
        return plain;
    }, {});
}
exports.toJSON = toJSON;
function toString(object) {
    return `${object.constructor.name} ${JSON.stringify(object, null, 2)}`;
}
exports.toString = toString;
function toUnAnchoredUri(url) {
    var _a;
    const [, result = url] = (_a = url.match(/(^[^#]*)/)) !== null && _a !== void 0 ? _a : [];
    return result === null || result === void 0 ? void 0 : result.replace(/\?\s*$/, '?');
}
exports.toUnAnchoredUri = toUnAnchoredUri;
function toUriEncoding(url) {
    return url.replace(/(\\[0-9a-fA-F]{1,6}\s?)/g, s => {
        return String.fromCodePoint(Number.parseInt(s.substring(1).trim(), 16));
    });
}
exports.toUriEncoding = toUriEncoding;
function removeUndefinedProps(object) {
    return Object.entries(object).reduce((object, [key, value]) => (value !== undefined ? Object.assign(object, { [key]: value }) : object), {});
}
exports.removeUndefinedProps = removeUndefinedProps;
function absolutizeUrl(url, baseUrl) {
    return new URL(url, baseUrl).href;
}
exports.absolutizeUrl = absolutizeUrl;
function cachify(func, getKey, TTL = 2 * 60 * 60 * 1000) {
    const cache = new Map();
    const cacheTimeouts = new Map();
    caches.push(cache);
    const funcWithCache = ((...args) => {
        var _a;
        const key = stringifyKey((_a = getKey === null || getKey === void 0 ? void 0 : getKey(args)) !== null && _a !== void 0 ? _a : args);
        let value = cache.get(key);
        if (!value || (cacheTimeouts.has(key) && cacheTimeouts.get(key) <= Date.now())) {
            value = func(...args);
            cache.set(key, value);
            cacheTimeouts.set(key, Date.now() + TTL);
        }
        return value;
    });
    funcWithCache.clearCache = () => cache.clear();
    funcWithCache.getCachedValues = () => Array.from(cache.values());
    funcWithCache.setCachedValue = (key, value) => cache.set(stringifyKey(key), value);
    return funcWithCache;
    function stringifyKey(key) {
        key = types.isPlainObject(key)
            ? Object.fromEntries(Object.entries(key).sort(([key1], [key2]) => (key1 > key2 ? 1 : -1)))
            : key;
        return JSON.stringify(key, (_key, value) => (typeof value === 'function' ? value.toString() : value));
    }
}
exports.cachify = cachify;
const caches = [];
function clearCachify() {
    caches.forEach(cache => cache.clear());
}
exports.clearCachify = clearCachify;
function batchify(func, { timeout, maxPending }) {
    const pendingInputs = new Map();
    let throttleTimer = false;
    return function (input) {
        return new Promise(async (resolve, reject) => {
            pendingInputs.set(input, { resolve, reject });
            if (!throttleTimer) {
                throttleTimer = setTimeout(invoke, timeout);
            }
            if (maxPending && pendingInputs.size >= maxPending) {
                invoke();
            }
        });
    };
    function invoke() {
        if (pendingInputs.size) {
            func(Array.from(pendingInputs.entries()));
            pendingInputs.clear();
            if (throttleTimer)
                clearTimeout(throttleTimer);
            throttleTimer = false;
        }
    }
}
exports.batchify = batchify;
function wrap(func, wrapper) {
    return new Proxy(func, {
        apply: (func, _this, args) => wrapper(func, ...args),
    });
}
exports.wrap = wrap;
function extend(target, extension) {
    const result = {};
    return Object.defineProperties(result, {
        ...Object.fromEntries(Object.entries(Object.getOwnPropertyDescriptors(target)).map(([key, descriptor]) => [
            key,
            types.isFunction(descriptor.value) || types.isObject(descriptor.value)
                ? descriptor
                : {
                    configurable: descriptor.configurable,
                    enumerable: descriptor.enumerable,
                    get: () => target[key],
                    set: value => (target[key] = value),
                },
        ])),
        ...Object.getOwnPropertyDescriptors(types.isFunction(extension) ? extension(result) : extension),
    });
}
exports.extend = extend;
function pluralize(object, config) {
    const count = types.isArray(object) ? object.length : object;
    const isMany = count > 1;
    let res = isMany ? 's' : '';
    if (config) {
        res = isMany ? config[0] : config[1];
    }
    return res;
}
exports.pluralize = pluralize;
function deepEqual(value1, value2) {
    return _deepEqual(value1, value2, new Set());
}
exports.deepEqual = deepEqual;
function _deepEqual(value1, value2, visitedObjects) {
    if (value1 === value2)
        return true;
    if (visitedObjects.has(value1) && visitedObjects.has(value2))
        throw new Error('circular reference');
    if (typeof value1 === 'object' && typeof value2 === 'object') {
        visitedObjects.add(value1);
        visitedObjects.add(value2);
    }
    if (types.isArray(value1) && types.isArray(value2)) {
        if (value1.length !== value2.length)
            return false;
        for (let i = 0; i < value1.length; i++) {
            if (!_deepEqual(value1[i], value2[i], visitedObjects))
                return false;
        }
        return true;
    }
    if (types.isObject(value1) && types.isObject(value2)) {
        const keys1 = Object.keys(value1);
        const keys2 = Object.keys(value2);
        if (keys1.length !== keys2.length)
            return false;
        for (const key of keys1) {
            if (!_deepEqual(value1[key], value2[key], visitedObjects))
                return false;
        }
        return true;
    }
    return false;
}
/**
 * Deduplicates an array based on a custom equality function, applies an asynchronous transformation
 * to the unique values, and maps the results back to the original array structure.
 *
 * @param items - The array of items to process.
 * @param transform - A function that receives unique items and returns transformed results.
 * @param isEqual - A function that determines whether two items are considered equal.
 * @returns A Promise resolving to an array where each item is replaced with its transformed result.
 */
async function dedupAndMap(items, transform, isEqual) {
    // Extract unique values
    const firstIndecies = items.map(value => items.findIndex(v => isEqual(v, value)));
    const uniqueValues = items.filter((_, index) => firstIndecies.indexOf(index) === index);
    // Compute results for unique values
    const results = await transform(uniqueValues);
    // Map unique values to their transformed results
    const resultMap = new WeakMap();
    uniqueValues.forEach((val, index) => resultMap.set(val, results[index]));
    return items.map((_, index) => resultMap.get(items[firstIndecies[index]]));
}
exports.dedupAndMap = dedupAndMap;
/**
 * Zips two arrays together, yielding pairs of elements from each array.
 * If the arrays are of different lengths, the shorter length is used (it's the user res)
 */
function* zip(a, b) {
    const len = Math.min(a.length, b.length);
    for (let i = 0; i < len; i++) {
        yield [a[i], b[i]];
    }
}
exports.zip = zip;


/***/ }),

/***/ "../utils/dist/geometry.js":
/*!*********************************!*\
  !*** ../utils/dist/geometry.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.padding = exports.divide = exports.equals = exports.contains = exports.isIntersected = exports.intersect = exports.offsetNegative = exports.offset = exports.scale = exports.rotate = exports.floor = exports.ceil = exports.round = exports.isEmpty = exports.region = exports.size = exports.location = void 0;
const types = __importStar(__webpack_require__(/*! ./types */ "../utils/dist/types.js"));
const guard = __importStar(__webpack_require__(/*! ./guard */ "../utils/dist/guard.js"));
function location(region) {
    return { x: region.x, y: region.y };
}
exports.location = location;
function size(region) {
    return { width: region.width, height: region.height };
}
exports.size = size;
function region(location, size) {
    if (!location)
        location = { x: 0, y: 0 };
    return { x: location.x, y: location.y, width: size.width, height: size.height };
}
exports.region = region;
function isEmpty(sizeOrRegion) {
    return sizeOrRegion.width === 0 || sizeOrRegion.height === 0;
}
exports.isEmpty = isEmpty;
function round(target) {
    const result = { ...target };
    if (types.has(target, ['x', 'y'])) {
        result.x = Math.round(target.x);
        result.y = Math.round(target.y);
    }
    if (types.has(target, ['width', 'height'])) {
        result.width = Math.round(target.width);
        result.height = Math.round(target.height);
    }
    return result;
}
exports.round = round;
function ceil(target) {
    const result = { ...target };
    if (types.has(target, ['x', 'y'])) {
        // intentionally using Math.round and not Math.ceil here, because the point is that for width and height it makes sense to use ceil, but not for x and y
        result.x = Math.round(target.x);
        result.y = Math.round(target.y);
    }
    if (types.has(target, ['width', 'height'])) {
        result.width = Math.ceil(target.width);
        result.height = Math.ceil(target.height);
    }
    return result;
}
exports.ceil = ceil;
function floor(target) {
    const result = { ...target };
    if (types.has(target, ['x', 'y'])) {
        result.x = Math.floor(target.x);
        result.y = Math.floor(target.y);
    }
    if (types.has(target, ['width', 'height'])) {
        result.width = Math.floor(target.width + (types.has(target, 'x') ? target.x - result.x : 0));
        result.height = Math.floor(target.height + (types.has(target, 'y') ? target.y - result.y : 0));
    }
    return result;
}
exports.floor = floor;
function rotate(target, degrees, size) {
    degrees = (360 + degrees) % 360;
    const result = {};
    if (types.has(target, ['width', 'height'])) {
        // rotate size
        if (degrees === 90 || degrees === 270) {
            result.width = target.height;
            result.height = target.width;
        }
        else {
            result.width = target.width;
            result.height = target.height;
        }
    }
    if (types.has(target, ['x', 'y']) && size) {
        const hasSize = types.has(target, ['width', 'height']);
        // rotate coordinate system around a target
        if (degrees === 0) {
            result.x = target.x;
            result.y = target.y;
        }
        else if (degrees === 90) {
            result.x = size.height - target.y;
            result.y = target.x;
            if (hasSize)
                result.x -= result.width;
        }
        else if (degrees === 180) {
            result.x = size.width - target.x;
            result.y = size.height - target.y;
            if (hasSize) {
                result.x -= result.width;
                result.y -= result.height;
            }
        }
        else if (degrees === 270) {
            result.x = target.y;
            result.y = size.width - target.x;
            if (hasSize)
                result.y -= result.height;
        }
    }
    return result;
}
exports.rotate = rotate;
function scale(target, scaleRatio) {
    const result = { ...target };
    if (types.has(target, ['x', 'y'])) {
        result.x = target.x * scaleRatio;
        result.y = target.y * scaleRatio;
    }
    if (types.has(target, ['width', 'height'])) {
        result.width = target.width * scaleRatio;
        result.height = target.height * scaleRatio;
    }
    return result;
}
exports.scale = scale;
function offset(target, offset) {
    const result = { ...target };
    result.x += offset.x;
    result.y += offset.y;
    return result;
}
exports.offset = offset;
function offsetNegative(target, offset) {
    const result = { ...target };
    result.x -= offset.x;
    result.y -= offset.y;
    return result;
}
exports.offsetNegative = offsetNegative;
function intersect(region1, region2) {
    if (!isIntersected(region1, region2))
        return { x: 0, y: 0, width: 0, height: 0 };
    const result = {};
    result.x = Math.max(region1.x, region2.x);
    result.y = Math.max(region1.y, region2.y);
    result.width = Math.min(region1.x + region1.width, region2.x + region2.width) - result.x;
    result.height = Math.min(region1.y + region1.height, region2.y + region2.height) - result.y;
    return result;
}
exports.intersect = intersect;
function isIntersected(region1, region2) {
    return ((region1.x <= region2.x ? region2.x < region1.x + region1.width : region1.x < region2.x + region2.width) &&
        (region1.y <= region2.y ? region2.y < region1.y + region1.height : region1.y < region2.y + region2.height));
}
exports.isIntersected = isIntersected;
function contains(region, locationOrRegion) {
    if (region.x <= locationOrRegion.x && region.y <= locationOrRegion.y) {
        if (types.has(locationOrRegion, ['width', 'height'])) {
            return (region.x + region.width >= locationOrRegion.x + locationOrRegion.width &&
                region.y + region.height >= locationOrRegion.y + locationOrRegion.height);
        }
        return true;
    }
    return false;
}
exports.contains = contains;
function equals(locationOrSizeOrRegion1, locationOrSizeOrRegion2) {
    if (types.has(locationOrSizeOrRegion1, ['x', 'y', 'width', 'height'])) {
        if (types.has(locationOrSizeOrRegion2, ['x', 'y', 'width', 'height'])) {
            return (locationOrSizeOrRegion1.x === locationOrSizeOrRegion2.x &&
                locationOrSizeOrRegion1.y === locationOrSizeOrRegion2.y &&
                locationOrSizeOrRegion1.width === locationOrSizeOrRegion2.width &&
                locationOrSizeOrRegion1.height === locationOrSizeOrRegion2.height);
        }
        return false;
    }
    if (types.has(locationOrSizeOrRegion1, ['x', 'y'])) {
        if (types.has(locationOrSizeOrRegion2, ['x', 'y'])) {
            return (locationOrSizeOrRegion1.x === locationOrSizeOrRegion2.x &&
                locationOrSizeOrRegion1.y === locationOrSizeOrRegion2.y);
        }
        return false;
    }
    if (types.has(locationOrSizeOrRegion1, ['width', 'height'])) {
        if (types.has(locationOrSizeOrRegion2, ['width', 'height'])) {
            return (locationOrSizeOrRegion1.width === locationOrSizeOrRegion2.width &&
                locationOrSizeOrRegion1.height === locationOrSizeOrRegion2.height);
        }
        return false;
    }
    return false;
}
exports.equals = equals;
function divide(region, size, padding = {}) {
    var _a, _b;
    guard.notNull(region, { name: 'region' });
    guard.notNull(size, { name: 'size' });
    guard.isNumber(size.width, { name: 'size.width', gt: 0 });
    guard.isNumber(size.height, { name: 'size.height', gt: 0 });
    (_a = padding.top) !== null && _a !== void 0 ? _a : (padding.top = 0);
    (_b = padding.bottom) !== null && _b !== void 0 ? _b : (padding.bottom = 0);
    const subRegions = [];
    const maxX = region.x + region.width;
    const maxY = region.y + region.height;
    const stepX = size.width;
    const stepY = padding.top + padding.bottom < size.height ? size.height - (padding.top + padding.bottom) : size.height;
    let currentY = region.y;
    while (currentY < maxY) {
        let nextY = Math.min(currentY + stepY, maxY);
        // first region
        if (currentY === region.y)
            nextY += padding.top;
        // last region
        else if (nextY < maxY && nextY + padding.top >= maxY)
            nextY = maxY;
        const currentHeight = nextY - currentY;
        let currentX = region.x;
        while (currentX < maxX) {
            const nextX = Math.min(currentX + stepX, maxX);
            const currentWidth = nextX - currentX;
            subRegions.push({ x: currentX, y: currentY, width: currentWidth, height: currentHeight });
            currentX = nextX;
        }
        currentY = nextY;
    }
    return subRegions;
}
exports.divide = divide;
function padding(region, padding) {
    var _a, _b, _c, _d, _e, _f;
    if (types.isNumber(padding)) {
        padding = { left: padding, right: padding, top: padding, bottom: padding };
    }
    region.x -= (_a = padding.left) !== null && _a !== void 0 ? _a : 0;
    region.width += ((_b = padding.left) !== null && _b !== void 0 ? _b : 0) + ((_c = padding.right) !== null && _c !== void 0 ? _c : 0);
    region.y -= (_d = padding.top) !== null && _d !== void 0 ? _d : 0;
    region.height += ((_e = padding.top) !== null && _e !== void 0 ? _e : 0) + ((_f = padding.bottom) !== null && _f !== void 0 ? _f : 0);
    return region;
}
exports.padding = padding;


/***/ }),

/***/ "../utils/dist/guard.js":
/*!******************************!*\
  !*** ../utils/dist/guard.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.custom = exports.instanceOf = exports.isOneOf = exports.isEnumValue = exports.isObject = exports.isArray = exports.isNumeric = exports.isAlpha = exports.isAlphanumeric = exports.isString = exports.isGreaterThenOrEqual = exports.isGreaterThen = exports.isLessThenOrEqual = exports.isLessThen = exports.isFunction = exports.isInteger = exports.isNumber = exports.isBoolean = exports.notNull = void 0;
const types = __importStar(__webpack_require__(/*! ./types */ "../utils/dist/types.js"));
function notNull(value, { name }) {
    if (types.isNull(value)) {
        throw new Error(`IllegalArgument: ${name} is not allowed to be null or undefined`);
    }
}
exports.notNull = notNull;
function isBoolean(value, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !types.isBoolean(value)) {
        throw new Error(`IllegalType: ${name} must be of type boolean. Received ${value}`);
    }
}
exports.isBoolean = isBoolean;
function isNumber(value, { name, strict = true, lt, lte, gt, gte }) {
    if ((strict || !types.isNull(value)) && !types.isNumber(value)) {
        throw new Error(`IllegalArgument: ${name} must be of type number. Received ${value}`);
    }
    if (!types.isNull(lt))
        isLessThen(value, lt, { name });
    else if (!types.isNull(lte))
        isLessThenOrEqual(value, lte, { name });
    else if (!types.isNull(gt))
        isGreaterThen(value, gt, { name });
    else if (!types.isNull(gte))
        isGreaterThenOrEqual(value, gte, { name });
}
exports.isNumber = isNumber;
function isInteger(value, { name, strict = true, lt, lte, gt, gte }) {
    if ((strict || !types.isNull(value)) && !types.isInteger(value)) {
        throw new Error(`IllegalArgument: ${name} must be an integer of type number. Received ${value}`);
    }
    if (!types.isNull(lt))
        isLessThen(value, lt, { name });
    else if (!types.isNull(lte))
        isLessThenOrEqual(value, lte, { name });
    else if (!types.isNull(gt))
        isGreaterThen(value, gt, { name });
    else if (!types.isNull(gte))
        isGreaterThenOrEqual(value, gte, { name });
}
exports.isInteger = isInteger;
// eslint-disable-next-line @typescript-eslint/ban-types
function isFunction(value, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !types.isFunction(value)) {
        throw new Error(`IllegalArgument: ${name} must be of type function. Received ${value}`);
    }
}
exports.isFunction = isFunction;
function isLessThen(value, limit, { name }) {
    if (!(value < limit)) {
        throw new Error(`IllegalArgument: ${name} must be < ${limit}. Received ${value}`);
    }
}
exports.isLessThen = isLessThen;
function isLessThenOrEqual(value, limit, { name }) {
    if (!(value <= limit)) {
        throw new Error(`IllegalArgument: ${name} must be <= ${limit}. Received ${value}`);
    }
}
exports.isLessThenOrEqual = isLessThenOrEqual;
function isGreaterThen(value, limit, { name }) {
    if (!(value > limit)) {
        throw new Error(`IllegalArgument: ${name} must be > ${limit}. Received ${value}`);
    }
}
exports.isGreaterThen = isGreaterThen;
function isGreaterThenOrEqual(value, limit, { name }) {
    if (!(value >= limit)) {
        throw new Error(`IllegalArgument: ${name} must be >= ${limit}. Received ${value}`);
    }
}
exports.isGreaterThenOrEqual = isGreaterThenOrEqual;
function isString(value, { name, strict = true, alpha, numeric }) {
    if ((strict || !types.isNull(value)) && !types.isString(value)) {
        throw new Error(`IllegalArgument: ${name} must be of type string. Received ${value}`);
    }
    if (alpha && numeric)
        isAlphanumeric(value, { name });
    else if (alpha)
        isAlpha(value, { name });
    else if (numeric)
        isNumeric(value, { name });
}
exports.isString = isString;
function isAlphanumeric(value, { name }) {
    if (!/^[a-z0-9]+$/i.test(value)) {
        throw new Error(`IllegalArgument: ${name} must be an alphanumeric string. Received ${value}`);
    }
}
exports.isAlphanumeric = isAlphanumeric;
function isAlpha(value, { name }) {
    if (!/^[a-z]+$/i.test(value)) {
        throw new Error(`IllegalArgument: ${name} must be an alphabetic string. Received ${value}`);
    }
}
exports.isAlpha = isAlpha;
function isNumeric(value, { name }) {
    if (!/^[0-9]+$/.test(value)) {
        throw new Error(`IllegalArgument: ${name} must be a numeric sring. Received ${value}`);
    }
}
exports.isNumeric = isNumeric;
function isArray(value, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !types.isArray(value)) {
        throw new Error(`IllegalArgument: ${name} must be of type array. Received ${value}`);
    }
}
exports.isArray = isArray;
function isObject(value, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !types.isObject(value)) {
        throw new Error(`IllegalArgument: ${name} must be of type object. Received ${value}`);
    }
}
exports.isObject = isObject;
function isEnumValue(value, enumeration, { name, strict = true }) {
    const values = new Set(Object.values(enumeration));
    if ((strict || !types.isNull(value)) && !values.has(value)) {
        const list = Array.from(values, value => JSON.stringify(value)).join(', ');
        throw new Error(`IllegalArgument: ${name} must be one of [${list}]. Received ${value}`);
    }
}
exports.isEnumValue = isEnumValue;
function isOneOf(value, values, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !values.includes(value)) {
        const list = values.map(value => JSON.stringify(value)).join(', ');
        throw new Error(`IllegalArgument: ${name} must be one of [${list}]. Received ${value}`);
    }
}
exports.isOneOf = isOneOf;
function instanceOf(value, ctor, { name, strict = true }) {
    if ((strict || !types.isNull(value)) && !types.instanceOf(value, ctor)) {
        throw new Error(`IllegalType: ${name} must be an instance of ${ctor.name}`);
    }
}
exports.instanceOf = instanceOf;
function custom(value, check, { name, strict = true, message }) {
    if ((strict || !types.isNull(value)) && !check(value)) {
        throw new Error(`IllegalType: ${name} ${message || 'is wrong type'}`);
    }
}
exports.custom = custom;


/***/ }),

/***/ "../utils/dist/math.js":
/*!*****************************!*\
  !*** ../utils/dist/math.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.multiplier = void 0;
// find a smallest integer multiplier for number to produce an integer result with some allowed error
function multiplier(number, error = 0) {
    let remaining = number;
    const coefficients = [];
    while (true) {
        const integer = Math.floor(remaining);
        remaining = 1 / (remaining - integer);
        coefficients.push(integer);
        const [, denominator] = coefficients.reduceRight(([numerator, denominator], coefficient) => [denominator + numerator * coefficient, numerator], [1, 0]);
        const multiplied = number * denominator;
        if (Math.abs(multiplied - Math.round(multiplied)) < error)
            return denominator;
    }
}
exports.multiplier = multiplier;


/***/ }),

/***/ "../utils/dist/promises.js":
/*!*********************************!*\
  !*** ../utils/dist/promises.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeControlledPromise = void 0;
function makeControlledPromise() {
    let promise;
    let resolve;
    let reject;
    let result;
    function getPromise() {
        if (!promise) {
            promise = new Promise((...args) => ([resolve, reject] = args));
            if (result) {
                if (result.status === 'fulfilled')
                    resolve(result.value);
                else
                    reject(result.reason);
            }
        }
        return promise;
    }
    return {
        then(onFulfilled, onRejected) {
            return getPromise().then(onFulfilled, onRejected);
        },
        catch(onRejected) {
            return getPromise().catch(onRejected);
        },
        finally(onFinally) {
            return getPromise().finally(onFinally);
        },
        get [Symbol.toStringTag]() {
            return 'ControlledPromise';
        },
        get settled() {
            return !!result;
        },
        resolve(value) {
            if (resolve)
                resolve(value);
            else
                result !== null && result !== void 0 ? result : (result = { status: 'fulfilled', value });
        },
        reject(reason) {
            if (reject)
                reject(reason);
            else
                result !== null && result !== void 0 ? result : (result = { status: 'rejected', reason });
        },
    };
}
exports.makeControlledPromise = makeControlledPromise;


/***/ }),

/***/ "../utils/dist/queues.js":
/*!*******************************!*\
  !*** ../utils/dist/queues.js ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeCorkableQueue = void 0;
const promises = __importStar(__webpack_require__(/*! ./promises */ "../utils/dist/promises.js"));
const types = __importStar(__webpack_require__(/*! ./types */ "../utils/dist/types.js"));
const pause = Symbol('queue pause');
function makeCorkableQueue(options) {
    const handles = new Map();
    let corked = false;
    return {
        get corked() {
            return corked;
        },
        pause,
        run,
        cancel,
        cork,
        uncork,
    };
    async function run(task) {
        const handle = {
            running: false,
            async start() {
                if (handle.running)
                    return;
                handle.running = true;
                handle.controller = options.makeAbortController();
                try {
                    const result = await task(handle.controller.signal);
                    if (handle.running && result !== pause) {
                        handles.delete(task);
                        handle.promise.resolve(result);
                    }
                }
                catch (error) {
                    if (handle.running || !types.instanceOf(error, 'AbortError'))
                        handle.promise.reject(error);
                }
                finally {
                    return handle.promise;
                }
            },
            abort() {
                if (!handle.running)
                    return;
                handle.running = false;
                handle.controller.abort();
            },
            promise: promises.makeControlledPromise(),
        };
        handles.set(task, handle);
        if (!corked)
            handle.start();
        return handle.promise;
    }
    function cancel(task) {
        const handle = handles.get(task);
        if (!(handle === null || handle === void 0 ? void 0 : handle.running))
            return;
        handle.abort();
        handles.delete(task);
    }
    function cork() {
        if (corked)
            return;
        corked = true;
        Array.from(handles.values())
            .slice(1)
            .forEach(handle => handle.abort());
    }
    function uncork() {
        if (!corked)
            return;
        corked = false;
        handles.forEach(handle => handle.start());
    }
}
exports.makeCorkableQueue = makeCorkableQueue;


/***/ }),

/***/ "../utils/dist/streams.js":
/*!********************************!*\
  !*** ../utils/dist/streams.js ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.persist = exports.toJSON = exports.toBuffer = void 0;
const stream_1 = __webpack_require__(/*! stream */ "?ee5a");
const buffer_1 = __webpack_require__(/*! buffer */ "../../node_modules/buffer/index.js");
const general = __importStar(__webpack_require__(/*! ./general */ "../utils/dist/general.js"));
async function toBuffer(stream) {
    return new Promise((resolve, reject) => {
        let ended = false;
        const chunks = [];
        stream.on('data', onData);
        stream.on('end', onEnd);
        stream.on('error', onEnd);
        stream.on('aborted', onAbort);
        stream.on('pause', onPause);
        stream.on('close', onCleanup);
        function onData(chunk) {
            chunks.push(chunk);
        }
        function onEnd(err) {
            if (err)
                return reject(err);
            ended = true;
            resolve(buffer_1.Buffer.concat(chunks));
        }
        function onAbort() {
            if (!ended)
                reject(new Error('Cannot collect message data due to it being closed before ended'));
        }
        function onPause() {
            stream.resume();
        }
        function onCleanup() {
            stream.off('data', onData);
            stream.off('end', onEnd);
            stream.off('error', onEnd);
            stream.off('aborted', onAbort);
            stream.off('pause', onPause);
            stream.off('close', onCleanup);
        }
    });
}
exports.toBuffer = toBuffer;
async function toJSON(stream) {
    const buffer = await toBuffer(stream);
    return JSON.parse(buffer.toString('utf8'));
}
exports.toJSON = toJSON;
function persist(stream) {
    const clone = stream.pipe(new stream_1.PassThrough());
    let buffer;
    clone.pipe = general.wrap(clone.pipe.bind(clone), (pipe, destination, options) => {
        if (!buffer) {
            buffer = toBuffer(clone);
            return pipe(destination, options);
        }
        void buffer.then(buffer => {
            destination.write(buffer);
            if ((options === null || options === void 0 ? void 0 : options.end) !== false)
                destination.end();
        });
        return destination;
    });
    return clone;
}
exports.persist = persist;


/***/ }),

/***/ "../utils/dist/types.js":
/*!******************************!*\
  !*** ../utils/dist/types.js ***!
  \******************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

/* eslint {"@typescript-eslint/ban-types": ["error", {"types": {"Function": false}}]} */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.instanceOf = exports.has = exports.isEnumValue = exports.isFunction = exports.isEmpty = exports.isPlainObject = exports.isObject = exports.isArray = exports.isUint8Array = exports.isAnyArrayBuffer = exports.isInteger = exports.isNumber = exports.isHttpUrl = exports.isBase64 = exports.isString = exports.isBoolean = exports.isNull = exports.isDefined = exports.isNotDefined = void 0;
function isNotDefined(value) {
    return (isNull(value) ||
        (isString(value) ? value === '' || value.toLowerCase() === 'null' || value.toLowerCase() === 'undefined' : false));
}
exports.isNotDefined = isNotDefined;
function isDefined(value) {
    return !isNotDefined(value);
}
exports.isDefined = isDefined;
function isNull(value) {
    return value == null;
}
exports.isNull = isNull;
function isBoolean(value) {
    return typeof value === 'boolean' || value instanceof Boolean;
}
exports.isBoolean = isBoolean;
function isString(value) {
    return Object.prototype.toString.call(value) === '[object String]';
}
exports.isString = isString;
function isBase64(value) {
    return isString(value) && /^[A-Za-z0-9+/]*={0,2}$/.test(value);
}
exports.isBase64 = isBase64;
function isHttpUrl(value) {
    try {
        const url = new URL(value);
        return url.protocol === 'http:' || url.protocol === 'https:';
    }
    catch {
        return false;
    }
}
exports.isHttpUrl = isHttpUrl;
function isNumber(value) {
    return typeof value === 'number' || value instanceof Number;
}
exports.isNumber = isNumber;
function isInteger(value) {
    return isNumber(value) && Number.isInteger(value);
}
exports.isInteger = isInteger;
function isAnyArrayBuffer(value) {
    return !!value && (value[Symbol.toStringTag] === 'ArrayBuffer' || value[Symbol.toStringTag] === 'SharedArrayBuffer');
}
exports.isAnyArrayBuffer = isAnyArrayBuffer;
function isUint8Array(value) {
    return !!value && value[Symbol.toStringTag] === 'Uint8Array';
}
exports.isUint8Array = isUint8Array;
function isArray(value) {
    return Array.isArray(value);
}
exports.isArray = isArray;
function isObject(value) {
    return typeof value === 'object' && value !== null;
}
exports.isObject = isObject;
function isPlainObject(value) {
    return isObject(value) && (!value.constructor || value.constructor.name === 'Object');
}
exports.isPlainObject = isPlainObject;
function isEmpty(value) {
    if (!value)
        return true;
    if (isObject(value))
        return Object.keys(value).length === 0;
    return value.length === 0;
}
exports.isEmpty = isEmpty;
function isFunction(value, key) {
    if (key && has(value, key))
        return typeof value[key] === 'function';
    return typeof value === 'function';
}
exports.isFunction = isFunction;
function isEnumValue(value, enumeration) {
    const values = new Set(Object.values(enumeration));
    return values.has(value);
}
exports.isEnumValue = isEnumValue;
function has(value, keys) {
    if (!isObject(value))
        return false;
    if (!isArray(keys))
        keys = [keys];
    for (const key of keys) {
        if (!(key in value))
            return false;
    }
    return true;
}
exports.has = has;
function instanceOf(value, ctorOrName) {
    if (!isObject(value) && !isFunction(value))
        return false;
    if (!isString(ctorOrName))
        return value instanceof ctorOrName;
    let proto1 = Object.getPrototypeOf(value);
    while (proto1) {
        if (proto1.constructor.name === ctorOrName)
            return true;
        proto1 = Object.getPrototypeOf(proto1);
    }
    /*
      in webdriverIO, the constructor is not always the same as the prototype's constructor.
      if you want to make this research, you can import {browser} from '@wdio/global', and see that:
      * isObject(browser) === false
      * isFunction(browser) === true
      * typeof browser === 'function'
      * String(browser) === '[object Object]'
      * browser.constructor.name === 'bound Browser'
      * JSON.stringify(browser) === undefined
      * browser.__proto__.constructor.name === 'Browser'
      * Object.getPrototypeOf(browser) is a function - "function () { [native code] }"
  
      It's too weird for me right now. If you see this comment and you understand what's going on, I'm eager to learn from you - please contact me.
    */
    if ('__proto__' in value) {
        let proto2 = value.__proto__;
        while (proto2) {
            if (proto2.constructor.name === ctorOrName)
                return true;
            proto2 = proto2.__proto__;
        }
    }
    return false;
}
exports.instanceOf = instanceOf;


/***/ }),

/***/ "../utils/dist/utility-types.js":
/*!**************************************!*\
  !*** ../utils/dist/utility-types.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));


/***/ }),

/***/ "../utils/dist/uuid.js":
/*!*****************************!*\
  !*** ../utils/dist/uuid.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.uuid = void 0;
const isNode = () => typeof process !== 'undefined' && process.versions != null && process.versions.node != null;
const isWebCryptoAvailable = () => typeof window !== 'undefined' && window.crypto != null && typeof window.crypto.randomUUID === 'function';
const generateNodeUUID = () => {
    // We use a dynamic require('crypto') here to ensure this code doesn't break
    // when bundled for a browser environment, which does not have a 'crypto' module.
    // A static, top-level `import crypto from 'crypto'` would cause bundler errors.
    const cryptoModule = 'crypto';
    const crypto = __webpack_require__("../utils/dist sync recursive")(cryptoModule);
    // Use the modern, fast method if available (Node.js >= 14.17.0)
    if (typeof crypto.randomUUID === 'function') {
        return crypto.randomUUID();
    }
    // Fallback for older Node.js versions using the still-secure randomBytes.
    const bytes = crypto.randomBytes(16);
    // Set the version to 4 as per RFC 4122
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    // Set the variant to RFC 4122
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = bytes.toString('hex');
    return [
        hex.substring(0, 8),
        hex.substring(8, 12),
        hex.substring(12, 16),
        hex.substring(16, 20),
        hex.substring(20),
    ].join('-');
};
const generateFallbackUUID = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};
/**
 * Generates a UUID v4 string (cryptographically secure if possible).
 */
const uuid = () => {
    if (isNode())
        return generateNodeUUID();
    if (isWebCryptoAvailable())
        return window.crypto.randomUUID();
    return generateFallbackUUID();
};
exports.uuid = uuid;


/***/ }),

/***/ "../utils/dist sync recursive":
/*!***************************!*\
  !*** ../utils/dist/ sync ***!
  \***************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "../utils/dist sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "?ee5a":
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/***/ (() => {

/* (ignored) */

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
var _applitools_snippets__WEBPACK_IMPORTED_MODULE_2___namespace_cache;
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "../../node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @applitools/spec-driver-browser-extension */ "../spec-driver-browser-extension/dist/index.js");
/* harmony import */ var _applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _applitools_snippets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @applitools/snippets */ "../snippets/dist/index.js");
/* harmony import */ var _applitools_dom_snapshot_dist_processPagePollCjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @applitools/dom-snapshot/dist/processPagePollCjs */ "../dom-snapshot/dist/processPagePollCjs.js");
/* harmony import */ var _applitools_dom_snapshot_dist_processPagePollCjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_applitools_dom_snapshot_dist_processPagePollCjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _applitools_dom_snapshot_dist_pollResultCjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @applitools/dom-snapshot/dist/pollResultCjs */ "../dom-snapshot/dist/pollResultCjs.js");
/* harmony import */ var _applitools_dom_snapshot_dist_pollResultCjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_applitools_dom_snapshot_dist_pollResultCjs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _messenger__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./messenger */ "./src/messenger.js");
/* harmony import */ var _marker__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./marker */ "./src/marker.js");



// Browser-safe poll bundles, not the package root — the root pulls in Node-only fs helpers.





const apiScript = document.createElement('script')
apiScript.src = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.getURL('api.js')
window.document.body.appendChild(apiScript)

window.refer = (0,_applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1__.makeRefer)({
  check: element => element instanceof Node,
  validate: element => {
    if (!element || !element.isConnected) {
      throw new Error('StaleElementReferenceError')
    }
  },
})

Node.toJSON = function () {
  return window.refer.ref(this)
}

const originalParse = JSON.parse.bind(JSON)
JSON.parse = function (string, reviver) {
  return originalParse(string, (key, value) => {
    if (window.refer.isRef(value)) return window.refer.deref(value)
    return reviver ? reviver(key, value) : value
  })
}

// The worker can't pass a function across the realm boundary, so it dispatches snippets/polls by the
// export-name id eyes-browser stamps on them; these handlers deref the ref args and run them in-page.
window.applitools = window.applitools || {}
const snippetById = new Map(Object.entries(/*#__PURE__*/ (_applitools_snippets__WEBPACK_IMPORTED_MODULE_2___namespace_cache || (_applitools_snippets__WEBPACK_IMPORTED_MODULE_2___namespace_cache = __webpack_require__.t(_applitools_snippets__WEBPACK_IMPORTED_MODULE_2__, 2)))).filter(([, fn]) => typeof fn === 'function'))
window.applitools.runSnippet = (0,_applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1__.makeRunSnippet)({snippetById, refer: window.refer})
const pollById = new Map([
  ['processPagePoll', (_applitools_dom_snapshot_dist_processPagePollCjs__WEBPACK_IMPORTED_MODULE_3___default())],
  ['pollResult', (_applitools_dom_snapshot_dist_pollResultCjs__WEBPACK_IMPORTED_MODULE_4___default())],
])
window.applitools.runPoll = (0,_applitools_spec_driver_browser_extension__WEBPACK_IMPORTED_MODULE_1__.makeRunPoll)({pollById, refer: window.refer})

const unmark = (0,_marker__WEBPACK_IMPORTED_MODULE_6__.makeUnmark)({refer: window.refer})

// These messengers are required because user API cannot directly communicate with background script
const apiMessenger = (0,_messenger__WEBPACK_IMPORTED_MODULE_5__.makeMessenger)({
  onMessage: fn => window.addEventListener('applitools-message', ({detail}) => fn(unmark(detail))),
  sendMessage: detail => window.dispatchEvent(new CustomEvent('applitools-message', {detail})),
})
const frameMessenger = (0,_messenger__WEBPACK_IMPORTED_MODULE_5__.makeMessenger)({
  onMessage: fn => window.addEventListener('message', ({data}) => data.isApplitools && fn(data)),
  sendMessage: data => window.postMessage({...data, isApplitools: true}, '*'),
})
const backgroundMessenger = (0,_messenger__WEBPACK_IMPORTED_MODULE_5__.makeMessenger)({
  onMessage: fn => webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.onMessage.addListener(message => fn(message)),
  sendMessage: message => webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.sendMessage(message),
})

// NOTE: Listen for commands from page/api script.
apiMessenger.command(async (name, payload) => backgroundMessenger.request(name, payload))

// NOTE: Listen for one single command triggered from childContext in spec driver
// This is a workaround to get frameId of cross origin iframe
frameMessenger.on('*', (_, type) => backgroundMessenger.emit(type))

// NOTE: Listen for events initiated by the background script
backgroundMessenger.on('*', async (payload, name) => apiMessenger.emit(name, payload))

setInterval(() => backgroundMessenger.request('Extension.heartbeat'), 5000)

})();

var __webpack_export_target__ = this;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;